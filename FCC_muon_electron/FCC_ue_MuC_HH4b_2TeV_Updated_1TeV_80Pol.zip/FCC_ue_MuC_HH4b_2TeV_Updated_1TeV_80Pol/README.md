# FCC-ue / muon-collider HH -> 4b — original 1 TeV configurations, +80% right-handed mu+ (v3.1.3)

**25 October 2026.** This package is derived DIRECTLY from
`FCC_ue_MuC_HH4b_2TeV_Updated_2TeV_80Pol.zip` (v3.1.2), NOT from a separate codebase.
**Only the incoming beam energies change relative to that +80% parent package.**
Polarization remains **MG5 `polbeam1=+80`, `polbeam2=0`**, i.e. +80% right-handed
positive muons and an unpolarized second beam.

**No 1 TeV polarized cross sections or real MG5 events have been generated in this archive.**
Offline checks validate configuration, synthetic kinematics, the unchanged analysis,
and the correspondence to the parent package; MG5 itself must be checked on CERN.

## 1. Exact beam configuration (beam 1 is always mu+)

| Input | FCC-ue (mu+ e-) | Muon collider (mu+ mu-) |
|---|---|---|
| Incoming PDG IDs | `[-13, 11]` | `[-13, 13]` |
| Beam 1 along +z | **mu+ at 2000 GeV** | **mu+ at 500 GeV** |
| Beam 2 along -z | **e- at 120 GeV** | **mu- at 500 GeV** |
| sqrt(s), massless beams | **979.795897 GeV** | **1000.000000 GeV** |
| COM -> lab boost rapidity | **+1.406705** | 0 |
| `polbeam1` | **+80** (RH mu+) | **+80** (RH mu+) |
| `polbeam2` | **0** (e- unpolarized) | **0** (mu- unpolarized) |
| Four b acceptance | abs(eta_lab) < 5 | Same |
| Pair mass rule | two disjoint b-bbar masses in [110, 130] GeV | Same |
| Minimum pT or DeltaR | none | none |

This reproduces the **original approximately 1 TeV** benchmark rather than the newer
1.913/2.000 TeV beam configuration. The two colliders do NOT have identical sqrt(s):
FCC-ue has ~0.979796 TeV; MuC has 1.000 TeV. Do not claim both equal exactly 1 TeV.

### Controlled change from the supplied 2 TeV +80% package

- `configuration.json`: beam energies `[5000,183] -> [2000,120]` (FCC-ue),
  `[1000,1000] -> [500,500]` (muon collider). Package metadata and energy descriptions
  were also updated. **`polarization_percent: [80.0, 0.0]` is unchanged.**
- All `.mg5` cards and production/analysis scripts are **byte-for-byte identical**
  to the parent package, including `configure_run.py`, `run_workflow.py`, the
  headless-`DISPLAY` fix, coupling-order limits, Higgs decay normalization and cuts.
- `tests/test_suite.py` updates the hardcoded beam and synthetic LHE fixtures and
  adds explicit parent-to-child and per-component beam/polarization comparisons.
- README, reference snapshot, empty-results template and validation documentation
  are updated to reflect the original 1 TeV configurations.

**This update does NOT introduce ZZ fusion, integration/unweighting tuning,
new cuts, new polarization assumptions or new physics results.**

## 2. Four requested outputs; eight internal flavor components

| Output label | Process definition | Internal components |
|---|---|---|
| mue_HH | mu+ e- -> nu_e anti-nu_mu HH, followed by HH -> 4b | 1 |
| mue_4b | mu+ e- -> nu_e anti-nu_mu b bbar b bbar | 1 |
| mumu_HH | mu+ mu- -> sum_i nu_i anti-nu_i HH, followed by HH -> 4b | 3 |
| mumu_4b | mu+ mu- -> sum_i nu_i anti-nu_i b bbar b bbar | 3 |

Each flavor is integrated separately so its normalization, statistics and uncertainty
can be audited. The three orthogonal neutrino final states are summed as cross sections,
not amplitudes. Missing components are never silently treated as zero.

The stable-HH production cards use `QCD=0 QED=4`. The direct-4b cards use
`QCD=2 QED=6`. In MG5 single `=` supplies amplitude-order **upper bounds**, not exact
orders (`==`). These explicit bounds retain the tree electroweak and QCD-mediated
contributions for this SM final state, rather than relying on MG5's automatic leading
coupling-order preference. No Higgs exclusion, required internal Higgs, VBF-only
selection, or resonant subtraction is imposed on the direct-4b amplitude.

**The direct-4b rate is NOT a pure background.** It includes HH resonances, singly
resonant Higgs contributions, non-Higgs amplitudes and their allowed interference.
Do not add the separate NWA HH signal to it. Subtracting the NWA result is not a
unique gauge-invariant definition of a background-only cross section.

## 3. Exact acceptance and pairing algorithm

For two b partons b1,b2 and two antipartons a1,a2, the only two opposite-charge,
nonoverlapping assignments are:

    A = (b1,a1) + (b2,a2)
    B = (b1,a2) + (b2,a1)

The event passes if all four have `abs(eta_lab) < 5` AND either assignment has BOTH
masses in the closed interval [110,130] GeV. Each event counts once, even if both
assignments pass. A parton may not be reused in two candidates.

No “correct Higgs parent” is assigned to direct-4b events. This is an existence test
on measured parton four-vectors. The full matrix element need not admit a unique
Higgs-pair history. The rule does not require all four opposite-charge combinations,
or all six arbitrary pairs, to lie in the window.

At parton level, b versus bbar is known from PDG IDs +5 and -5. Detector b-tagging
alone is not charge identification: a charge-blind four-b-jet analysis would have
three unordered jet partitions and needs a separate selection definition. That is
not the observable implemented here.

A best-distance pairing diagnostic using sum((m-125)^2) is also reported, but **does
not define the primary acceptance**. It is not always equivalent to the existence
rule. No invented detector mass resolution is needed.

### Laboratory frame and generator cuts

Incoming LHE four-vectors are checked against the configured PDGs, invariant energy,
orientation and beam energies. Already-laboratory events are not boosted again. If
an otherwise consistent sample is stored in the COM frame, all four-vectors are
boosted to the specified laboratory. Massive bottom pseudorapidity is evaluated as
`asinh(pz/pT)`; it is not approximated by adding the COM rapidity to eta.

**All registered generation cuts are disabled using the installed MG5 run-card schema.**
This includes hidden cuts, missing-pT cuts, sorted jet cuts and PDG-specific cuts.
Eta and the two-pair mass window are applied only in the LHE analysis. In particular,
`mmbb=110, mmbbmax=130` is NOT a valid replacement for the disjoint-pair test.

This strategy is simple and auditable, but not guaranteed to be efficient for the
rare accepted region of an uncut 2->6 continuum. If selected statistics or integration
convergence are inadequate, the same exact pairing predicate should be ported into
an independently validated integration-level cut. This version does not pretend to
contain such a production-optimized integrator.

## 4. Higgs decays and an important normalization correction

HH production is generated with two stable on-shell scalars. Each H is decayed
isotropically into a massive b and bbar, conserving four-momentum. The NWA signal is

    sigma_fid(HH -> 4b) = sigma(nu nu HH) * B_card(H -> bbbar)^2 * A_4b.

The true on-shell decay pairs have mass mH=125 GeV, so the wide [110,130] window does
not itself remove ideal NWA signal events. The bottom-parton eta acceptance remains
nontrivial. This is not a finite-width/showered/detector signal simulation.

**Correction to the earlier packages:** their signal used B=0.582 independently of
the bottom Yukawa and Higgs total width in the direct-4b matrix element. That can
create inconsistent normalization between the two reported quantities.

The primary v3 signal instead derives its branching factor from the SAME actual
SM parameter card used for the direct process:

    Gamma_LO(H -> bbbar)
      = 3 GF ymb^2 mH / (4 pi sqrt(2)) * (1 - 4 mb^2/mH^2)^(3/2)
    B_card = Gamma_LO(H -> bbbar) / Gamma_H.

Here `ymb` is the SM UFO's Yukawa mass input; `mb` is the kinematic bottom mass.
They are conceptually distinct. All masses, Yukawas and widths are recorded.

For illustration, the published default SM restriction card checked during this
audit has mb=ymb=4.7 GeV, mH=125 GeV, GF=1.16639e-5 GeV^-2, and
Gamma_H=0.00638233934 GeV. These inputs imply **B_card ≈ 0.844640**, NOT 0.582.
This is a consequence of that tree-model/fixed-width input convention, **not a claim
that the precision Standard Model branching fraction is 84%**.

`reference_only_sigma_fb`, using B=0.582, is supplied separately for the signal
components. It NEVER replaces the model-consistent four-rate table. Before quoting
precision-phenomenology results, explicitly choose and document the common Higgs
Yukawa/width scheme. A custom common `PARAM_CARD` can be supplied, but it must respect
the restricted `sm` model and be used for every component. The scripts do not silently
retune a Yukawa or width merely to force a desired branching fraction.

## 5. Other baseline conventions

- Tree-level matrix elements in restricted `sm`; initial e/mu masses and Yukawas are
  zero, diagonal CKM. No claim of retaining tiny lepton-Yukawa contributions.
- mH=125 GeV and nonzero kinematic mb=4.7 GeV are required for this baseline.
- No pT or separation regulator is introduced. Finite mb regulates the final-bottom
  collinear limit; numerical enhancements and convergence still require attention.
- Monochromatic beams with +80% right-handed mu+ polarization and unpolarized second beam; no ISR/beamstrahlung/lepton PDFs.
- Fixed renormalization reference scale mu_R=125 GeV, an explicit adopted convention.
- No shower, hadronization, jet clustering, detector effects, b-tag efficiencies,
  luminosity factor, event-yield calculation or distribution production.
- LO four massive partons are called “b candidates”; they are not a resolved-jet prediction.

## 6. Run on an existing MadGraph installation

Requires Python 3.9+ compatible with your installed MadGraph5_aMC, a complete MG5
installation and a working Fortran build toolchain. No NumPy, ROOT, LHAPDF or pip
installation is needed for these helper scripts. Do not rebuild a working environment.
No code in this package downloads or installs software.

First run local tests:

```bash
unzip FCC_ue_MuC_HH4b_2TeV_Updated_1TeV_80Pol.zip
cd FCC_ue_MuC_HH4b_2TeV_Updated_1TeV_80Pol
bash run_tests.sh
```

Set the path to an existing MG5 executable and run:

```bash
MG5=/absolute/path/to/MG5_aMC/bin/mg5_aMC \
NEVENTS=10000 NDECAYS=50 \
bash run_all.sh
```

More events improve selection statistics; they are not by themselves a proof of
phase-space integration convergence. `NEVENTS` is PER FLAVOR COMPONENT. Eight
internal runs feed four totals. `NDECAYS` is the number of trial HH decays per
production event, not an increase in independent hard-event statistics.

For an initial source-generation/configuration check without physics integration:

```bash
MG5=/absolute/path/to/MG5_aMC/bin/mg5_aMC \
bash run_all.sh --only mue_HH --prepare-only
```

For a single requested group (all three flavors for a muon-collider group):

```bash
MG5=/absolute/path/to/MG5_aMC/bin/mg5_aMC \
bash run_all.sh --only mumu_4b
```

For an independent statistics/convergence comparison, use a different seed and a
NEW output directory:

```bash
MG5=/absolute/path/to/MG5_aMC/bin/mg5_aMC \
NEVENTS=30000 NDECAYS=100 SEED=2302026 \
WORK=/absolute/path/to/a/new/nonexistent/run_directory \
bash run_all.sh
```

Default output is a new timestamped `work/run_...` directory. An explicitly existing
WORK directory is rejected. Process cards do not use destructive `output -f`.
Partial results, logs and MG debug files are preserved on failure.
`PYTHON=/path/to/python` selects the interpreter for the existing environment.
`PARAM_CARD=/absolute/path/to/common_param_card.dat` is an optional advanced override.
A parameter card cannot restore interactions that the `sm` restriction already removed.

## 7. Results, errors and reproducibility

Each run stores effective configuration, source-script checksums, the MG version,
process/run/parameter cards, full generator and analysis logs, component JSON reports,
and four-row `results.csv`/`results.json` summaries. The reports are in fb (1 pb=1000 fb).
All eight component errors are explicit; distinct neutrino-flavor integrals are combined
in quadrature under the independent-run assumption.

For a component, A=sum(w_i f_i)/sum(w_i), where f_i is a binary pass for direct 4b
or the accepted fraction of decay trials for an HH hard event. The selection MC
standard error uses a positive-weight ratio estimator with the **hard event as the
statistical cluster**. Integration normalization error and acceptance-sampling error
are shown separately. Their quadrature is an approximate diagnostic: covariance
between integration and event generation is neglected. No scale, model, branching,
finite-width or detector systematic uncertainty is included.

For zero selected direct-4b events, the primary rate is **null**, not a claimed zero.
For equal-weight events an exact one-sided 95% binomial acceptance upper bound is
reported, conditional on the generated normalization. It is not a replacement for
a converged cross-section measurement. A missing flavor also makes a total incomplete.
Negative-weight/NLO samples, unexpected final states, ambiguous files, truncated LHE,
wrong beams and incompatible model parameters cause explicit errors.

## 8. Validation status and what remains

See `VALIDATION_REPORT.md` and `validation/unit_tests.log` for the executed local tests.
The synthetic fixtures used by tests are mathematical/software checks, never physics
predictions. They are created in temporary directories and are not delivered as events.

Before sending numbers to CERN: check real MG5 process generation and diagram content,
all saved parameters/cuts, integration warnings and unweighting efficiency; inspect
accepted counts; repeat with independent seeds and increased statistics; compare
signal decay sampling; document the Higgs normalization and reference scale. Retain
the labels “LO, parton-level, +80% right-handed mu+, second beam unpolarized, no ISR/shower/detector” and the different
actual sqrt(s) values. Do not describe the full 4b rate as background only.

## 9. Contents and references

- `configuration.json`, `docs/CONFIRMED_COLLIDER_CONFIGURATIONS.md`: exact setup and status.
- `cards/*.mg5`, `processes.py`: eight flavor-resolved process cards and their four totals.
- `configure_run.py`: full MG5-schema cut reset, model checks and audit output.
- `physics.py`, `lhe_io.py`, `analyze_lhe.py`: explicit kinematics, LHE input, cuts and errors.
- `run_all.sh`, `run_workflow.py`, `collect_results.py`: safe execution and four-row summaries.
- `tests/`, `run_tests.sh`, `VALIDATION_REPORT.md`: reproducible offline validation.
- `RESULTS_NOT_YET_COMPUTED.csv`: deliberately empty numerical template, not results.
- `docs/CHANGELOG.md`, `docs/SOURCES.json`, `SHA256SUMS.txt`: audit trail and references.

Primary source provenance is recorded in `docs/SOURCES.json`. Sources were used to
check MG5 syntax/schema, default SM inputs, the scalar partial-width convention and
the LHE structure. They do not certify this package's real MG5 execution.

## 10. Inherited CERN headless DISPLAY diagnostic (v3.1.1)

MadGraph5_aMC v3.6.4 on LXPLUS can print `Error: no DISPLAY environment variable specified`
when preparing plots/web pages during a successful event run. The earlier v3.1.0
workflow treated that exact line as a fatal log error even though the MG5 command
returned exit code 0, successfully integrated, and generated events. The v3.1.1
scanner excludes **only** this exact diagnostic, while still rejecting any nonzero
exit status, real ERROR/FATAL/CRITICAL messages, truncated/missing LHE inputs and
subsequent analysis errors. No beam, process, scale, decay, or kinematic settings
were changed by this bug fix.

Actual physics convergence has **not** been verified by the offline tests.

## 11. Original 1 TeV / +80%-polarization execution on CERN

From the extracted new package directory (NOT the old unpolarized directory):

```bash
export MG5=/eos/user/h/hakhanpo/MG5_aMC_v3_6_4/bin/mg5_aMC
bash run_tests.sh
bash run_all.sh --only mue_HH --prepare-only --nevents 30000 --decays 100 --seed 2302026
```

The `--prepare-only` command writes a NEW `work/run_...` folder. Inspect the printed path, then check the generated `mue_HH/Cards/run_card.dat`:

```bash
RUN=$(ls -dt work/run_* | head -1)
grep -nEi 'polbeam1|polbeam2|ebeam1|ebeam2|scale' "$RUN/mue_HH/Cards/run_card.dat"
python3 -m json.tool "$RUN/mue_HH/configuration_audit.json" | grep -A 4 -B 2 'polbeam'
```

**Required:** `polbeam1 = 80`, `polbeam2 = 0`, `ebeam1 = 2000`, `ebeam2 = 120`, and the normal shared model/cuts. The adapter's read-back audit already raises a fatal error on a mismatch. For the muon collider, check beam energies **500 and 500** on another prepared channel.

Perform a small **real-MG5** pilot for the fast `mue_HH` process before a full rerun:

```bash
bash run_all.sh --only mue_HH --nevents 3000 --decays 50 --seed 2302026
```

Check its generator cross section against the physics sanity expectation of approximately 1.8 times the unpolarized charged-current `mue_HH` production cross section (high-energy massless lepton limit), and check the generated event target and fiducial acceptance. This ratio is a **validation expectation**, not a computed polarized result.

Only after the pilot checks pass, perform the full calculation. For the requested 30k events per component and 100 decay trials per HH hard event:

```bash
bash run_all.sh --nevents 30000 --decays 100 --seed 2303026
```

This runs all 8 flavor components, automatically forms four totals, and creates a new separate results directory. Check card values in **all eight components**. The previous unpolarized `mumu_4b_e` and `mumu_4b_tau` had event-generation shortfalls (2407 and 6388 vs 30000); the polarization-only package **does not** introduce unrelated integration/unweighting tuning. Examine those channels especially carefully and report if the requested event count is missed. This is a controlled comparison, not a convergence guarantee. For long CPU-heavy tasks, follow CERN batch/compute-node use guidance rather than burdening the LXPLUS login node.

The old unpolarized directory and its numerical results are never edited. To compare unpolarized/polarized predictions, use separately generated reports with the same Higgs BR convention and selection. A 80% polarized run cannot be reconstructed by changing labels in the old CSV. All four reported before-cut HH -> 4b rates must include the **same** model-card BR(H->bbbar)^2 once, and the after-cut values multiply those rates by the new acceptance.

## 12. Simultaneous 1 TeV and 2 TeV CERN execution

The 1 TeV and 2 TeV packages have **different top-level directories** and use
non-destructive, timestamp-plus-random `work/run_*` directories by default.
Keep them separate, and use different `--seed` values to avoid unnecessary random
stream overlap. They can share the same preinstalled MG5 executable, but the
full runs are CPU/IO intensive: prefer separate CERN batch/compute-node jobs
rather than two large runs on an LXPLUS login node. Never point both at the
same `--work` path. There is no automatic dependency between their runs.

From **this extracted 1 TeV package directory**:

```bash
export MG5=/eos/user/h/hakhanpo/MG5_aMC_v3_6_4/bin/mg5_aMC
bash run_tests.sh
bash run_all.sh --only mue_HH --prepare-only --nevents 30000 --decays 100 --seed 1302026
```

Validate the generated `mue_HH/Cards/run_card.dat` entries
`ebeam1=2000`, `ebeam2=120`, `polbeam1=80`, `polbeam2=0`.
Check `mumu_HH_mu` in a separate `--prepare-only` run for
`ebeam1=500`, `ebeam2=500`, `polbeam1=80`, `polbeam2=0`.
`configuration_audit.json` checks the saved MG5 card round trip.
Run a small real-MG5 pilot only after both card audits succeed. Full production:

```bash
bash run_all.sh --nevents 30000 --decays 100 --seed 1303026
```

For comparison, run the existing 2 TeV +80% package in its OWN directory
with its existing 5000/183 and 1000/1000 beam settings and a different
seed (e.g. `--seed 2303026`). Do not copy its generated process directories,
run cards, events or results into this archive.

If using `--work`, supply a previously nonexistent directory for each run.
The original MuC continuum e/tau unweighting shortfalls may recur; check the
actual generated event counts and independent-seed convergence before publication.
