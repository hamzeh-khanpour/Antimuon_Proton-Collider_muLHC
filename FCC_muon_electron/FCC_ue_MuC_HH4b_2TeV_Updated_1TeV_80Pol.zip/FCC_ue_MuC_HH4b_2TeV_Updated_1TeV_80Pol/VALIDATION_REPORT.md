# Validation report — original 1 TeV and +80% RH mu+ (v3.1.3)

**Date:** 2026-10-25. This is a controlled beam-energy derivative of v3.1.2-80Pol.
No polarized physical cross sections have been calculated locally. The production
scripts and eight MG5 cards are unchanged and identified by SHA256 in the build audit.

## Scope of the offline audit

- Both collider beam PDGs, lab directions, energies and sqrt(s) verified.
- +80% right-handed incoming mu+ implemented as `polbeam1=80`, second beam 0.
- Exact eight-component run settings verified against the configuration.
- Only beam energies (plus descriptive metadata) differ from the parent package.
- Synthetic LHE kinematics and lab boosts retested at the restored FCC-ue energy.
- All mathematical selection/pairing, decay normalization, uncertainty-handling,
  negative/invalid input safeguards and mocked workflow tests rerun.
- Python syntax, shell syntax, zip validity and file checksums checked.

**Not executed locally:** actual MG5_aMC v3.6.4 `--prepare-only`, generated Fortran
integration, unweighting, full HH/4b physics runs or independent-seed convergence.
The real installed MG5 run-card serializer and actual LHE beams MUST be audited
on CERN before any scientific use. The inherited known undergeneration in two MuC
continuum flavors is NOT modified by this energy-only update.

**Offline unit/regression tests: 67 passed** (recorded 25 October 2026).

The test log is `validation/1tev_80pol_unit_tests.log`.
The archive-specific hash/difference manifest is
`docs/ONE_TEV_80POL_BUILD_AUDIT.json`.
