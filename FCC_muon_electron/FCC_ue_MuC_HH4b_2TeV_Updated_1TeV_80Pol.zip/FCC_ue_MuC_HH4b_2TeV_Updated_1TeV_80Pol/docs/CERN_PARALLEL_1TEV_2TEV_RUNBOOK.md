# CERN LXPLUS — separate 1 TeV and 2 TeV +80% jobs

**Physics unchanged other than the explicitly different beam energies**.
The 1 TeV archive was built from the 2 TeV +80% archive: same MG5 source cards,
analysis, Higgs decay convention, no-pT selection and right-handed mu+ polarization.

## Exact expected MG5 run-card values

| Package, group | `ebeam1` | `ebeam2` | `polbeam1` | `polbeam2` |
|---|---:|---:|---:|---:|
| 1 TeV `mue_*` | 2000 | 120 | +80 | 0 |
| 1 TeV `mumu_*` | 500 | 500 | +80 | 0 |
| 2 TeV `mue_*` | 5000 | 183 | +80 | 0 |
| 2 TeV `mumu_*` | 1000 | 1000 | +80 | 0 |

Both folders are independent. Keep the original 2 TeV ZIP unchanged; extract the
new 1 TeV ZIP alongside it. Avoid integrating large workloads on a shared LXPLUS
login node; submit the two full calculations to separate compute/batch slots.

## On CERN: prepare and audit 1 TeV configurations first

```bash
cd /eos/user/h/hakhanpo/MG5_aMC_v3_6_4
unzip FCC_ue_MuC_HH4b_2TeV_Updated_1TeV_80Pol.zip
cd FCC_ue_MuC_HH4b_2TeV_Updated_1TeV_80Pol
export MG5=/eos/user/h/hakhanpo/MG5_aMC_v3_6_4/bin/mg5_aMC
bash run_tests.sh

bash run_all.sh --only mue_HH --prepare-only --nevents 30000 --decays 100 --seed 1302026 --work work/prepare_mue_1TeV_80Pol
bash run_all.sh --only mumu_HH_mu --prepare-only --nevents 30000 --decays 100 --seed 1302126 --work work/prepare_mumu_1TeV_80Pol

grep -nE 'polbeam1|polbeam2|ebeam1|ebeam2' work/prepare_mue_1TeV_80Pol/mue_HH/Cards/run_card.dat
grep -nE 'polbeam1|polbeam2|ebeam1|ebeam2' work/prepare_mumu_1TeV_80Pol/mumu_HH_mu/Cards/run_card.dat
```

**The MG5 adapter already reparses each saved card and fails if requested values
are not preserved.** The manual checks above make the inputs visible to you.
The `--work` directory must NOT exist before its command is invoked; reuse a new
path if a preparation attempt already created one. Check the `manifest.json` and
`configuration_audit.json` too.

Optional separate single-component small real-MG5 pilot:

```bash
bash run_all.sh --only mue_HH --nevents 3000 --decays 50 --seed 1302226
```

## Production runs (on suitable CERN compute resources)

From inside the **1 TeV** extracted package:

```bash
bash run_all.sh --nevents 30000 --decays 100 --seed 1303026
```

From inside the **existing 2 TeV** +80% extracted package, in a separate shell / job:

```bash
bash run_all.sh --nevents 30000 --decays 100 --seed 2303026
```

Each invocation creates a separate `work/run_YYYY..._ID` folder **within its own
package**, so no results are overwritten. The two processes can share the MG5
installation, but do not share work directories. Avoid simultaneous heavy jobs
on the LXPLUS login node itself.

## After the runs

For each `work/run_*` directory, verify its archived `configuration.json`, all
8 component `Cards/run_card.dat`, `configuration_audit.json`, generated event
counts, full `logs/`, `manifest.json`, and `results.csv`.
Do not treat preliminary MC errors as proof of convergence; earlier 2 TeV
unpolarized `mumu_4b_e` and `mumu_4b_tau` runs had event shortfalls.
Do not mix the 1 TeV and 2 TeV cross sections when combining flavor channels.
