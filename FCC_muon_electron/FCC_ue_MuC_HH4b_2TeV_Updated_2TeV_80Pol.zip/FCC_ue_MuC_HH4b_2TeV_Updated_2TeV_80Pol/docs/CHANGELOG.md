# v3.1.2-80Pol — 25 October 2026 — polarization-only study

- **ONLY PHYSICS INPUT CHANGE:** positive-muon beam-1 polarization from 0% to +80% (right-handed) for both FCC-ue and muon-collider processes. Beam-2 remains unpolarized (0%).
- The MG5 RunCardLO adapter now reads `polarization_percent` from the config instead of hardcoding `[0,0]`, validates the values, writes `polbeam1=80`, `polbeam2=0`, and round-trip verifies the actual MG5 card as before.
- All eight `.mg5` process cards and all other physics/mathematical processing sources are **byte-for-byte unchanged** from v3.1.1. No ZZ-fusion process is included.
- Added baseline-comparison regression tests and documentation only; **no polarized numerical predictions** are represented as calculated.
- Previous CERN unpolarized run had event-generation shortfalls in `mumu_4b_e` and `mumu_4b_tau`. No integration tuning is added, to isolate the polarization effect.

---

# v3.1.1 headless MG5 log-scanner fix — 24 October 2026

- User-reported CERN MG5_aMC 3.6.4 run produced 30,000 `mue_HH` events and
  inclusive cross section 0.0003845 +/- 6.112e-07 pb, but the Python workflow
  stopped on `Error: no DISPLAY environment variable specified` despite process exit 0.
- Add narrowly scoped exact-string allowlist in `run_workflow.fatal_log`; preserve
  all other fatal checks, nonzero exit codes, LHE validation and physics selections.
- Add regression test covering benign display message, genuine failures, and
  nonidentical display-related errors.
- No changes to any of the eight process cards, beam energies, physics/decay
  normalization, runtime cuts or scale settings. The reported cross section is
  an inclusive preliminary production result, not a completed fiducial result.

# v3.1.0 energy-only update — 24 October 2026

- FCC-ue beams updated to 5000 GeV mu+ and 183 GeV e-; muon collider to 1000+1000 GeV.
- 56 offline regression tests updated to use the new beam energies and rerun.
- MadGraph process definitions, physics model, generator-cut logic, acceptance,
  pairing rule and result-combination algorithms remain unchanged.
- Prior v3.0.0 outputs and reports remain archived unchanged in the uploaded original ZIP.
- This update does not contain new-energy physical cross sections and has NOT run MG5.

---

# v3.0.0 audit changes — 23 October 2026

This package supersedes `FCC_ue_MuC_HH4b_1TeV_Starter.zip` and
`FCC_ue_MuC_HH4b_2TeVx120GeV_NoPt.zip`. Prior archives have not been modified.

## Physics definitions retained

The mu-e beam energies remain 2000 and 120 GeV. The mu-mu baseline remains
500 and 500 GeV. There is no pT or DeltaR cut. Every final bottom must satisfy
abs(eta_lab)<5. Either of the two disjoint opposite-charge assignments may pass,
provided both candidate masses are in [110,130] GeV. The direct-4b calculation
is not changed into a Higgs-subtracted background.

## Corrections and clarifications

1. **Confirmation status:** the mu-mu symmetric energy split, unpolarized beams,
   laboratory-frame convention, both-candidate window, and neutrino-flavor sum
   are now explicitly labeled as adopted conventions rather than quoted confirmations.
2. **Branching normalization:** the primary NWA signal now uses the tree partial
   width divided by the total width from the actual common parameter card. The old
   independent 0.582 factor is only a separate reference result. This can materially
   change a number, so it is prominently documented rather than silently patched.
3. **No hidden cuts:** a narrow text substitution was replaced by an audit of all
   cuts registered in the installed MG5 schema. Generation cuts are disabled;
   eta and the two-pair requirement are imposed in analysis only.
4. **Flavor bookkeeping:** eight independent flavor components produce the same four
   requested totals. A missing flavor makes a total incomplete, not smaller by fiat.
5. **Frames:** the incoming LHE momenta now determine whether a lab boost is needed.
   Incoming species, orientation, invariant energy and outgoing momentum conservation
   are checked. A lab sample cannot accidentally receive the boost twice.
6. **Statistics:** integration and selection MC errors are separate. HH decay trials
   are clustered by the hard production event. Approximate combined errors and their
   covariance limitation are stated. Zero selected events are not reported as a
   measured zero; a conditional binomial upper bound is provided when applicable.
7. **Robust input:** plain/gzipped LHE, event attributes, Fortran exponents, truncation,
   process IDs, masses, final-state content and positive LO weights are checked.
8. **Safe execution:** new run directories, no destructive process overwrite,
   process-artifact checks, detection of fatal MG messages even with exit code zero,
   exact fresh LHE selection, hashes, configuration audits and logs.
9. **No secondary stages:** active shower/MadSpin/detector/reweight/MA5 cards in a
   freshly exported process are archived under `.disabled_by_baseline` rather than run.
10. **More validation:** 56 offline tests, including an explicitly mocked end-to-end
    workflow. This does not replace real MG5 process generation or integration.

## Deliberately not implemented or claimed

No integration-level custom pairing cut, no experimental charge-blind jet algorithm,
no detector mass smearing, no best-chi2 selection as the default, no diagram-subtracted
background, no polarization assumption beyond unpolarized beams, no ISR, no shower,
no numerical cross sections, and no real-MadGraph compatibility/convergence certification.
