#!/usr/bin/env python3
"""Use the installed MG5 run-card schema to disable ALL registered cuts.
Final eta and disjoint-pair requirements are deliberately applied in analysis.
Actual MG5 integration of this adapter must be tested on the user's installation.
"""
import argparse
import json
import math
from pathlib import Path
import shutil
import sys
from physics import model_inputs
from processes import COMPONENTS

ROOT=Path(__file__).resolve().parent


def settings_for(config,component,nevents,seed):
    beams=config['beam_setups'][COMPONENTS[component]['beam']]
    scale=config['physics_conventions']['renormalization_scale_GeV']
    return dict(nevents=nevents,iseed=seed,lpp1=0,lpp2=0,
        ebeam1=beams['energies_GeV'][0],ebeam2=beams['energies_GeV'][1],
        polbeam1=0.,polbeam2=0.,maxjetflavor=4,
        ptj=0.,ptb=0.,ptheavy=0.,ptl=0.,misset=0.,etab=-1.,etaj=-1.,
        drbb=0.,drjj=0.,mmbb=0.,mmbbmax=-1.,mmjj=0.,mmjjmax=-1.,
        ickkw=0,xqcut=0.,ktdurham=-1.,ptlund=-1.,
        cut_decays=False,auto_ptj_mjj=False,
        fixed_ren_scale=True,scale=scale,dsqrt_q2fact1=scale,dsqrt_q2fact2=scale,
        fixed_fac_scale1=True,fixed_fac_scale2=True,
        use_syst=False,event_norm='average',boost_event=False,
        custom_fcts=[],pdlabel='none',
        req_acc=config['runtime']['integration_accuracy_target'])


def neutralize_registered_cuts(card):
    """Mirror the schema's own conventions but handle booleans explicitly."""
    if not getattr(card,'cuts_parameter',None):
        raise ValueError('Installed MG5 exposes no cut registry; refusing a partial patch')
    changes={}
    for name in card.cuts_parameter:
        old=card[name]
        if isinstance(old,bool):
            new=False
        elif isinstance(old,dict):
            new={}
        elif isinstance(old,(int,float)):
            if 'min' in name:
                new=0
            elif 'max' in name or 'eta' in name:
                new=-1
            else:
                new=0
        else:
            raise ValueError('Unknown cut type; requires audit: '+name)
        card[name]=new
        changes[name]={'before':old,'after':card[name]}
    return changes


def prepare(process_dir,mg_root,component,config,nevents,seed,custom_card=None):
    if nevents < 2 or nevents > 1000000 or not 0 < seed < 30081**2:
        raise ValueError('Need 2<=NEVENTS<=1000000 and 0<seed<30081^2')
    sys.path.insert(0,str(mg_root))
    from madgraph.various.banner import RunCardLO
    proc=Path(process_dir)
    path=proc/'Cards'/'run_card.dat'
    param=proc/'Cards'/'param_card.dat'
    if not path.is_file() or not param.is_file():
        raise ValueError('Generated process lacks run_card.dat or param_card.dat')
    shutil.copy2(path,proc/'Cards'/'run_card.before_package.dat')
    shutil.copy2(param,proc/'Cards'/'param_card.before_package.dat')
    if custom_card:
        shutil.copy2(custom_card,param)
    inputs=model_inputs(param)
    for pdg in (5,25):
        value=inputs['all_slha_inputs'][f'mass:{pdg}']
        expected=config['required_model_values'][f'mass_{pdg}_GeV']
        if not math.isclose(value,expected,rel_tol=1.e-10,abs_tol=1.e-10):
            raise ValueError(f'Baseline requires MASS {pdg}={expected}, found {value}')
    for block,pdg in [('mass',4),('mass',11),('mass',13),('yukawa',4),('yukawa',11),('yukawa',13),
                      ('wolfenstein',1),('wolfenstein',2),('wolfenstein',3),('wolfenstein',4)]:
        if inputs['all_slha_inputs'].get(f'{block}:{pdg}',0.) != 0:
            raise ValueError(f'{block} {pdg} is removed by the default sm restriction; a param-card edit cannot restore it')
    # Fresh output only: archive active secondary-stage cards instead of running them.
    disabled=[]
    for filename in ('pythia_card.dat','pythia8_card.dat','madspin_card.dat',
                     'delphes_card.dat','shower_card.dat','reweight_card.dat',
                     'madanalysis5_parton_card.dat','madanalysis5_hadron_card.dat'):
        active=proc/'Cards'/filename
        if active.exists():
            target=active.with_name(filename+'.disabled_by_baseline')
            if target.exists():
                raise ValueError('Refusing to overwrite an existing archived card: '+str(target))
            active.rename(target)
            disabled.append(filename)
    run=RunCardLO(str(path))
    changes=neutralize_registered_cuts(run)
    settings=settings_for(config,component,nevents,seed)
    # Some released versions use a single fixed_fact_scale field.
    if 'fixed_fact_scale' in run:
        settings['fixed_fact_scale']=True
    optional={'boost_event','custom_fcts','req_acc','auto_ptj_mjj',
              'fixed_fac_scale1','fixed_fac_scale2','ptlund'}
    applied={}
    unsupported=[]
    for key,value in settings.items():
        if key not in run:
            if key not in optional:
                raise ValueError('Required run-card option unsupported by this MG5: '+key)
            unsupported.append(key)
            continue
        if key=='pdlabel':
            # lpp=0 is decisive. Older releases may not implement pdlabel='none'.
            try:
                run[key]=value
            except Exception:
                run[key]='nn23lo1'
                value='nn23lo1'
        else:
            run[key]=value
        applied[key]=run[key]
    # Save full schema, including hidden fields, not a hand-patched short card.
    run.write(str(path),write_hidden=True)
    after=RunCardLO(str(path))
    for key,value in applied.items():
        if after[key] != value:
            raise ValueError('Run-card round-trip changed setting '+key)
    for key,entry in changes.items():
        expected=applied.get(key,entry['after'])
        if after[key] != expected:
            raise ValueError('A disabled generation cut changed on read-back: '+key)
    audit={'component':component,'model_inputs':inputs,'all_cut_changes':changes,
           'settings':applied,'optional_keys_absent':unsupported,'secondary_stage_cards_disabled':disabled,
           'analysis_cuts_only':config['selection'],
           'note':'No generator eta/mass/pT/DeltaR selection; final cuts are evaluated on LHE four-vectors.'}
    (proc/'configuration_audit.json').write_text(json.dumps(audit,indent=2,allow_nan=False)+'\n')
    return audit


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('process_dir',type=Path)
    p.add_argument('--mg-root',type=Path,required=True)
    p.add_argument('--component',choices=COMPONENTS,required=True)
    p.add_argument('--config',type=Path,default=ROOT/'configuration.json')
    p.add_argument('--nevents',type=int,required=True)
    p.add_argument('--seed',type=int,required=True)
    p.add_argument('--param-card',type=Path)
    a=p.parse_args()
    try:
        audit=prepare(a.process_dir,a.mg_root,a.component,json.loads(a.config.read_text()),a.nevents,a.seed,a.param_card)
        print('All registered generation cuts disabled; beam settings and full card audited.')
        print('Model-consistent BR(H->bbbar):',audit['model_inputs']['br_hbb_model'])
    except Exception as exc:
        p.exit(2,'ERROR: '+str(exc)+'\n')


if __name__=='__main__':
    main()
