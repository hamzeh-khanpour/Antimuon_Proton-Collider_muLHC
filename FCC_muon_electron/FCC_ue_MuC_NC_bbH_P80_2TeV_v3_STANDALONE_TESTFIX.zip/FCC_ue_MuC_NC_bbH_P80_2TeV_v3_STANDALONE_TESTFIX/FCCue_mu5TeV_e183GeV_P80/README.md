# FCCue_mu5TeV_e183GeV_P80 — polarized NC associated-Higgs

This is a **new, separate** package. It does not change any CC or unpolarized NC calculations.

## Physics
- MG5: `mu+ e- > mu+ e- b b~ h QCD=2 QED=6`.
- Beam1 `mu+` = 5000 GeV, beam2 e- = 183 GeV.
- `polbeam1=+80`, `polbeam2=0` (positive = right-handed polarization in MG5 run cards).
- `lpp1=lpp2=0`. No ISR, shower, detector. Default restricted SM, `mb=4.7 GeV` and `mH=125 GeV`.
- No generator-level cut on b-quark pT, for comparability with earlier results. `ptl=1 GeV` on both outgoing charged leptons to regulate photon exchange.
- Offline selection: 4 massive bottom partons, |eta_b|<5 and a disjoint opposite-sign pairing with each m_bb in [110,130] GeV. There is no b pT threshold.
- H -> bb by 100 isotropic decay trials per generated on-shell H, normalized by the **same model-card BR** as earlier runs; cross sections labeled preliminary.
- This inclusive on-shell bbH sample can contain internal H -> bb poles, i.e., overlap with HH; it is **not** an exclusive single-Higgs, nonresonant background. Do not sum it with HH or full 4b.
- In mu+mu- collisions the inclusive hard process is **not** a pure ZZ-fusion-only amplitude; s-channel contributions are allowed.

## Workflow on LXPLUS
```bash
BASE=/eos/user/h/hakhanpo/MG5_aMC_v3_6_4
cd "$BASE/FCC_ue_MuC_NC_bbH_P80_2TeV_v2_REVIEWED/FCCue_mu5TeV_e183GeV_P80"
export MG5="$BASE/bin/mg5_aMC"
bash run_all.sh --only mue_NC_bbH --nevents 30000 --decays 100 --seed 2708026 --prepare-only
# Check generated run-card, subprocess diagrams and model BR using:
# python3 check_prepared.py "<exact NEW WORK DIRECTORY from above>"
# Do not proceed unless this returns PREPARATION AUDIT PASS.
bash run_all.sh --only mue_NC_bbH --nevents 30000 --decays 100 --seed 2708026
```
The second command **starts a separate fresh generation and integration**, not a resume of prepare-only.

Prefer batch submission for long-running studies. Do not run multiple 16-core jobs concurrently on shared LXPLUS login nodes.

## Status
Offline code checks only: no actual CERN MadGraph run is included in this ZIP.
