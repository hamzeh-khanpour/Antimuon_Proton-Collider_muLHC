#!/usr/bin/env python3
"""One polarized NC bbH process for FCCue_mu5TeV_e183GeV_P80; contains possible HH poles."""
from pathlib import Path
GROUPS = ('mue_NC_bbH',)
COMPONENTS = {
  'mue_NC_bbH': dict(group='mue_NC_bbH',beam='mue',mode='bbh',
                      final_lepton_pdgs=(11, -13),br_power=1,
                      process='mu+ e- > mu+ e- b b~ h QCD=2 QED=6')
}
def card_text(name):
    if name not in COMPONENTS: raise ValueError('Unknown component: '+name)
    return '\n'.join([
        '# Polarized NC associated-Higgs benchmark, mu+ is beam 1',
        '# Incoming mu+ polarization +80%; beam 2 unpolarized; see run card',
        'set automatic_html_opening False',
        'set group_subprocesses False',
        'import model sm',
        'generate '+COMPONENTS[name]['process'],
        'output '+name,
        'quit', ''])
def write_cards(folder):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    for name in COMPONENTS:
        (folder/(name+'.mg5')).write_text(card_text(name))
if __name__=='__main__': write_cards(Path(__file__).parent/'cards')
