# Current CERN status and v3 standalone handoff (28 October 2026)

The complete v3 standalone is based on the genuine v2 reviewed ZIP, with byte-identical
physics scripts and corrected isolated synthetic tests. Do not use the earlier v3 upgrade kit.

Two +80% polarized NC bbH processes:
- FCC-ue: 5000 GeV mu+ beam1 + 183 GeV e- beam2 -> mu+ e- bbH, QCD=2 QED=6.
  v2 real CERN prepare-only work run_20261028T090446Z_f5082f78; 86 diagrams.
- MuC: 1000 GeV mu+ beam1 + 1000 GeV mu- beam2 -> mu+ mu- bbH, QCD=2 QED=6.
  v2 real CERN prepare-only work run_20261028T090613Z_4bb2f868; 172 diagrams.

Both: polbeam1=80, polbeam2=0; no b pT generator/analysis cut, ptl=1 GeV
on outgoing charged leptons; |eta_b|<5, two disjoint opposite-sign bb masses
110-130 GeV, 30000 events requested, 100 isotropic Hbb trials per event,
BR derived from LO model inputs. No shower/detector. NN precision not claimed.

Original v2 synthetic test printed two PASS lines then suffered Python segmentation
fault on CERN. The v3 runner isolates each test in its own Python process; locally
passes, CERN clean exit not yet verified. Both original v2 prepare-only directories
exist, and neither has been independently audited using check_prepared.py in user logs.

Follow README_FIRST.md for transfer/install and CERN validation. Do not run production
until synthetic suite exits 0 and BOTH independent preflight audits pass. A new
v3 production run always creates a new work directory; old results are untouched.
