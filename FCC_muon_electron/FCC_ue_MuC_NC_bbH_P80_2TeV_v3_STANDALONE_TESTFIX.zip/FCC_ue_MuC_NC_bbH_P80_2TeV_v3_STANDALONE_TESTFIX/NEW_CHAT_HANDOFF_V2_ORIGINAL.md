# Copy this into a new ChatGPT conversation

We are continuing the CERN FCC-ue / 2 TeV MuC charged-lepton neutral-current associated-Higgs study. The user wants to run **two polarized NC bbH processes** with **no bottom-quark pT cut**. The previous charged-current (CC) samples with outgoing neutrinos are distinct final states; the earlier complete CC-4b calculations did include allowed Higgs diagrams within the CC channel, but did not include these NC outgoing-charged-lepton processes.

## Two new processes

1. FCC-ue: `generate mu+ e- > mu+ e- b b~ h QCD=2 QED=6`, followed by H->bb in offline analysis. Beam1 mu+ 5000 GeV, beam2 e- 183 GeV, sqrt(s) 1913.11265 GeV, polarizations (polbeam1, polbeam2)=(80,0).
2. Muon collider: `generate mu+ mu- > mu+ mu- b b~ h QCD=2 QED=6`, followed by H->bb in offline analysis. Beam1 mu+ 1000 GeV, beam2 mu- 1000 GeV, sqrt(s)=2000 GeV, polarizations (80,0).

Both: MG5 3.6.4 at `/eos/user/h/hakhanpo/MG5_aMC_v3_6_4`; default restricted SM; no beam radiation/shower/detector. Exactly 30000 requested unweighted events and 100 independent isotropic scalar H->bb decay trials per hard event, multiplied by model-card BR(Hbb) (prior model: 0.8446400227319534; verify new cards). Generator requires `ptl=1 GeV` for BOTH outgoing charged leptons; `ptb=0`, `ptj=0`. Fiducial selection `|eta_b|<5` and two disjoint bb opposite-charge pair masses each within [110,130] GeV, with no minimum bottom-quark pT, no jet clustering.

The on-shell bbH sample may contain HH resonances, so do not simply add to HH or complete 4b. The MuC process is not a pure ZZ-fusion-only process. All results should be labeled preliminary and not convergence-validated.

## Reviewed package

Use **FCC_ue_MuC_NC_bbH_P80_2TeV_v2_REVIEWED.zip**, not the superseded v1 package. This reviewed package corrects one MuC metadata typo (outgoing leptons correctly mu+mu-) and adds end-to-end synthetic LHE tests. Scientific source scripts otherwise retain the prior validated functionality, with the specified beam polarization and final-state adapters. No actual MadGraph integration of the two new setups has been performed yet.

## Install commands (Windows PowerShell)

```powershell
scp "$env:USERPROFILE\Downloads\FCC_ue_MuC_NC_bbH_P80_2TeV_v2_REVIEWED.zip" hakhanpo@lxplus.cern.ch:/eos/user/h/hakhanpo/MG5_aMC_v3_6_4/
```

## Install and test on CERN LXPLUS

```bash
BASE=/eos/user/h/hakhanpo/MG5_aMC_v3_6_4
cd "$BASE"
unzip -q FCC_ue_MuC_NC_bbH_P80_2TeV_v2_REVIEWED.zip
cd "$BASE/FCC_ue_MuC_NC_bbH_P80_2TeV_v2_REVIEWED"
bash run_tests.sh
export MG5="$BASE/bin/mg5_aMC"
```

## First prepare-only preflight: FCC-ue

```bash
cd "$BASE/FCC_ue_MuC_NC_bbH_P80_2TeV_v2_REVIEWED/FCCue_mu5TeV_e183GeV_P80"
bash run_all.sh \
  --only mue_NC_bbH \
  --nevents 30000 \
  --decays 100 \
  --seed 2708026 \
  --prepare-only
```

Take the EXACT `NEW WORK DIRECTORY` from the command output and run:

```bash
python3 check_prepared.py "<EXACT NEW WORK DIRECTORY>"
```

Audit must print `PREPARATION AUDIT PASS`; check the generated `Cards/run_card.dat` shows 5000/183 GeV, polbeam1=80/polbeam2=0, ptl=1 GeV, ptb=0 GeV; inspect the MadGraph generated diagram count.

## Second prepare-only preflight: MuC

```bash
cd "$BASE/FCC_ue_MuC_NC_bbH_P80_2TeV_v2_REVIEWED/MuC_2TeV_Pmuplus80"
bash run_all.sh \
  --only mumu_NC_bbH \
  --nevents 30000 \
  --decays 100 \
  --seed 2709026 \
  --prepare-only
```

Again inspect the EXACT `NEW WORK DIRECTORY`:

```bash
python3 check_prepared.py "<EXACT NEW WORK DIRECTORY>"
```

Check 1000/1000 GeV, polbeam1=80/polbeam2=0, ptl=1 GeV, ptb=0 GeV, and output diagrams.

## Only after BOTH preparation audits pass: start actual runs

FCC-ue:

```bash
cd "$BASE/FCC_ue_MuC_NC_bbH_P80_2TeV_v2_REVIEWED/FCCue_mu5TeV_e183GeV_P80"
bash run_all.sh --only mue_NC_bbH --nevents 30000 --decays 100 --seed 2708026
```

Muon collider:

```bash
cd "$BASE/FCC_ue_MuC_NC_bbH_P80_2TeV_v2_REVIEWED/MuC_2TeV_Pmuplus80"
bash run_all.sh --only mumu_NC_bbH --nevents 30000 --decays 100 --seed 2709026
```

Each command creates its own NEW work directory; the prepare-only run does NOT automatically resume, and the old results are left untouched. Large integrations should be submitted to CERN's batch resources or allocated worker nodes rather than running 16-worker jobs concurrently on shared LXPLUS login nodes.

## After completed runs

In the relevant scenario directory, inspect `work/<new run>/results.csv`, `reports/<component>.json` and `manifest.json`. Collect results via the included `pack_results.py`:

```bash
python3 pack_results.py --runs "<EXACT COMPLETED WORK DIRECTORY>" --out "$HOME/FCC_ue_P80_NC_bbH_results.zip"
```

For MuC choose a different output name, e.g. `MuC_2TeV_P80_NC_bbH_results.zip`. Verify ZIP with `unzip -t`, download via Windows `scp`, upload for scientific review. Do not quote a result as precision until independent-seed/convergence checks.
