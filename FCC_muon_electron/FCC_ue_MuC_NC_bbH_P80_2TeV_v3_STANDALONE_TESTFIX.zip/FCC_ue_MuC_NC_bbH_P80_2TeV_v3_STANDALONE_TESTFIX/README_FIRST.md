# CERN FCC-ue / MuC polarized NC bbH — complete standalone v3 TESTFIX

Date: 28 October 2026. Based on the user's genuine 71 KB v2 reviewed ZIP.

**IMPORTANT: This is a test-runner fix and validation upgrade, NOT a changed physics prediction.**
All original v2 physics-critical scenario files are byte-identical, including both configurations,
process definitions, MadGraph cards, configure_run.py, physics.py, lhe_io.py, analyze_lhe.py,
run_workflow.py and other analysis scripts. Scenario `package_version` metadata retains the
v2 source provenance by design. Only the root test-runner and top-level instructions are changed;
read-only audit tools are added. A full MG5 integration was NOT performed here.

## CERN status reported 28 October 2026

- FCC-ue prepare-only: `mu+ e- > mu+ e- b b~ h QCD=2 QED=6`, 86 diagrams generated.
- MuC prepare-only: `mu+ mu- > mu+ mu- b b~ h QCD=2 QED=6`, 172 diagrams generated.
- Both run-card audit statements printed during process preparation.
- The old synthetic runner printed PASS for both scenarios but crashed with segmentation fault
  at process shutdown on CERN. This standalone v3 replaces it with separate Python interpreters.
- **The standalone v3 has passed local synthetic tests, but a clean CERN test exit remains unverified.**
- Neither numerical integration has yet been reported as completed.

## Physics baseline (unchanged)

FCC-ue: E(mu+) = 5000 GeV, E(e-) = 183 GeV, sqrt(s)=1913.11 GeV.
MuC: E(mu+) = E(mu-) = 1000 GeV, sqrt(s)=2000 GeV.
Beam polarization = (polbeam1,polbeam2)=(80,0), with beam1 mu+.
SM model; `QCD=2 QED=6` (amplitude-level upper bounds); `ptb=0`, `ptj=0`, `ptl=1` GeV on
both final charged leptons; selection |eta_b|<5 and one disjoint opposite-sign bbar pairing
with both masses in [110,130] GeV; no minimum bottom pT, no b-jet clustering.
30,000 requested unweighted production events and 100 isotropic H->bb daughter-decay trials
per hard event; one model-consistent LO Hbb branching factor.
The on-shell bbH sample can overlap HH; it is not additive to HH or full 4b predictions.

## Transfer from Windows PowerShell

```powershell
scp "$env:USERPROFILE\Downloads\FCC_ue_MuC_NC_bbH_P80_2TeV_v3_STANDALONE_TESTFIX.zip" hakhanpo@lxplus.cern.ch:/eos/user/h/hakhanpo/MG5_aMC_v3_6_4/
ssh -o ServerAliveInterval=10 hakhanpo@lxplus.cern.ch
```

## Install and test on CERN (no reinstallation of v2)

```bash
BASE=/eos/user/h/hakhanpo/MG5_aMC_v3_6_4
cd "$BASE"
unzip -n FCC_ue_MuC_NC_bbH_P80_2TeV_v3_STANDALONE_TESTFIX.zip
ROOT="$BASE/FCC_ue_MuC_NC_bbH_P80_2TeV_v3_STANDALONE_TESTFIX"
export MG5="$BASE/bin/mg5_aMC"
bash "$ROOT/run_tests.sh"
echo "SYNTHETIC TEST EXIT CODE: $?"
# Exit must be zero; no segfault.
bash "$ROOT/audit_existing_v2_preparations.sh" "$BASE"
echo "PREPARATION AUDIT EXIT CODE: $?"
# Exit must be zero, and each scenario must pass both read-only audits.
```

No original v2 workflow, results, or existing MG5 process directories are modified by
these tests. The second command checks the exact two previously printed prepare-only
work directory paths from 28 Oct 2026; it does NOT run MG5.

## Only after both validation commands exit 0

Use CERN batch resources for computationally heavy production, and verify adequate
scratch space, shared filesystem access, requested CPUs and CERN job-walltime settings.
The original workflow below generates a NEW standalone-v3 work directory and does NOT
resume the old v2 preparation:

```bash
cd "$ROOT/FCCue_mu5TeV_e183GeV_P80"
bash run_all.sh --only mue_NC_bbH --nevents 30000 --decays 100 --seed 2708026

cd "$ROOT/MuC_2TeV_Pmuplus80"
bash run_all.sh --only mumu_NC_bbH --nevents 30000 --decays 100 --seed 2709026
```

Do not launch both 16-core jobs on shared LXPLUS login nodes. Even after production,
check the LHE event counts, `results.csv`, `reports/*.json`, integration errors, and
independent-seed numerical convergence before quoting final cross sections.

## What changed from v2?

- `synthetic_lhe_smoke_test.py`: **only one scenario per interpreter**; no manipulation
  of Python's `sys.modules`. Original synthetic physics assertions retained.
- `run_tests.sh`: calls smoke tests separately, stops on any nonzero exit.
- `audit_existing_v2_preparations.sh` and `validation/audit_existing_preparation.py`:
  new read-only secondary audits of two prior CERN prepare-only work directories.
- Upgraded root README, review report and handoff; original v2 versions archived as
  `*_V2_ORIGINAL.md`.
- `V3_SOURCE_PROVENANCE.json`: hashes of original physics files and replacements.

This is not a claimed fix of any MG5 integration error; it addresses the Python test-runner
risk exposed by the CERN logs. A clean CERN test exit is still a mandatory validation gate.
