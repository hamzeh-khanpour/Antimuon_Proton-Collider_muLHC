# FCC-ue / MuC polarized NC associated-Higgs study (+80% incoming mu+)

This package extends **only the missing charged-lepton NC bbH associated-Higgs channel** to the two requested high-energy polarized benchmarks. It preserves the original, completed CC and unpolarized NC results.

## What is new—and what is not

Earlier charged-current samples had final-state neutrinos and the full CC 4b matrix element; they did not include the **different NC external state** with outgoing mu+ e- (or outgoing mu+ mu- at MuC). The earlier full CC 4b amplitude may contain CC Higgs-associated topologies within its coupling-order limit. It must not be described as excluding *all* single-Higgs effects.

The process `mu+ e- > mu+ e- b b~ h` (or its muon-collider analogue) is inclusive with respect to its allowed diagrams and can include resonant HH with one H -> bb. Thus, the separately generated bbH and HH samples are **not additive**. The full 4b amplitude and its interference require a separate, numerically convergence-validated study.

## Two independent workflows

- `FCCue_mu5TeV_e183GeV_P80`: Ee=183 GeV, E(mu+)=5000 GeV, sqrt(s)~1.913 TeV, P(mu+)=+80%, P(e-)=0.
- `MuC_2TeV_Pmuplus80`: E(mu+)=E(mu-)=1000 GeV, sqrt(s)=2 TeV, P(mu+)=+80%, P(mu-)=0.

**Caution:** The MuC process is an inclusive NC mu+mu- -> mu+mu- bbH process, not a pure ZZ-fusion-only process.

Selection: |eta_b|<5 and two disjoint opposite-sign bb mass windows [110,130] GeV, with no b-quark pT cut. A regulator pT(scattered charged lepton)>1 GeV is applied at generation, as in the original NC study. Optionally imposing 5 GeV on bottom quarks changes the fiducial definition and requires consistent configuration and analysis changes; **not implemented silently**.

## Transfer from Windows PowerShell

```powershell
scp "$env:USERPROFILE\Downloads\FCC_ue_MuC_NC_bbH_P80_2TeV_v2_REVIEWED.zip" hakhanpo@lxplus.cern.ch:/eos/user/h/hakhanpo/MG5_aMC_v3_6_4/
```

## Install on CERN LXPLUS

```bash
BASE=/eos/user/h/hakhanpo/MG5_aMC_v3_6_4
cd "$BASE"
unzip -q FCC_ue_MuC_NC_bbH_P80_2TeV_v2_REVIEWED.zip
cd "$BASE/FCC_ue_MuC_NC_bbH_P80_2TeV_v2_REVIEWED"
bash run_tests.sh  # includes synthetic LHE end-to-end checks
```

## Prepare both runs (generates source/cards but does NOT integrate)

```bash
export MG5="$BASE/bin/mg5_aMC"
cd "$BASE/FCC_ue_MuC_NC_bbH_P80_2TeV_v2_REVIEWED/FCCue_mu5TeV_e183GeV_P80"
bash run_all.sh --only mue_NC_bbH --nevents 30000 --decays 100 --seed 2708026 --prepare-only
cd "$BASE/FCC_ue_MuC_NC_bbH_P80_2TeV_v2_REVIEWED/MuC_2TeV_Pmuplus80"
bash run_all.sh --only mumu_NC_bbH --nevents 30000 --decays 100 --seed 2709026 --prepare-only
```

After each prepare-only command, verify the generated files from the EXACT `NEW WORK DIRECTORY` printed by the workflow:

```bash
# Run inside that scenario directory, using the actual printed work path.
python3 check_prepared.py "<NEW WORK DIRECTORY>"
```

Confirm `PREPARATION AUDIT PASS` and inspect `Cards/run_card.dat`: `ebeam1`, `ebeam2`, `polbeam1=80`, `polbeam2=0`, `ptb=0`, `ptl=1`. The check also verifies the model-card branching ratio and reports MadGraph diagram counts.

**Only then** remove `--prepare-only` from each scenario command to start the full (new, independently saved) integration. Do not confuse this with resuming the preparation run. These will create *new independent* run directories.

## Reproducibility and limitations

- The source code is derived from the previously CERN-tested NC continuum package; adaptation and unit checks performed here.
- There has been **no real MadGraph integration or CERN run** of these two new setup configurations in this environment. Always perform the CERN prepare-only gate first.
- Old CC samples can have associated-Higgs topologies, but the additional NC charged-lepton process was not included.
- No pT(b)>5 GeV cut applied (earlier benchmark kept comparable). For costly full4b/continuum runs, a 5 GeV generator cut can help, but requires an explicitly distinct fiducial selection.

## Review notes (2026-10-28)

- Corrected MuC descriptive `pt_cut_applies_to`: both final mu+ and mu- (not e-); actual MuC MadGraph process and analyzer were already correct.
- Expanded offline checks to cover the LHE reader, final-state PDG validation, lab-frame boost for asymmetric FCC-ue energies, isotropic H->bb decays, and fiducial b-pair selection with synthetic events.
- The package **cannot** validate MG5 compilation/integration here; the prepare-only audit on CERN is mandatory before long production runs.
- Event generation applies **no minimum b pT cut**, but does apply the 1 GeV scattered-charged-lepton cut. The latter means the 'before b cuts' cross section is not an unrestricted inclusive NC result.
- Synthetic LHE tests are internal software tests, **not** a physical Monte Carlo prediction or independent convergence check.
