# Review report — standalone v3, 28 October 2026

The attached genuine v2 ZIP passed CRC tests (33 source/documentation files), and its
Python synthetic smoke test passed locally with exit code 0. The v2 CERN logs report
successful MG5 3.6.4 process preparation (86 FCC-ue and 172 MuC diagrams), but the
v2 synthetic runner segfaulted after printing both PASS lines.

The v2 test runner combines two dynamic Python module environments within one interpreter
and then deletes new modules from `sys.modules`. Cause of CERN segfault not proven.

In this v3 standalone, synthetic tests run in two separate Python interpreter processes,
with no sys.modules deletion and a module-origin guard. **No physics-critical script,
beam configuration, selection cut, process card or integration setting changed**.
Both local synthetic tests and static syntax compile passed. CERN rerun still needed.

The historical correction `pt_cut_applies_to=mu+ and mu-` in MuC config is present.
At CERN, independently audit both original prepared work directories before production.
The audit reads the requested events (30000), decay trials (100), expected seeds,
polarizations (80,0), actual run-card values including scale (125 GeV), processes,
log diagram counts, and the no-b-pT baseline without regenerating anything.

Important physics qualifications: on-shell bbH can include internally resonant HH;
the bbH sample cannot be added to independent HH/full4b samples. No b-tagging,
showering, detector or convergence validation. The Hbb branching factor
0.8446400227 derives from the model-card LO inputs and total Higgs width;
this is not the modern precision-SM BR. Before-bottom-cuts rates retain pTl=1 GeV.
