# Scientific and software review — 28 October 2026

## Scope
Reviewed the source package derived from the CERN-tested neutral-current bbH/continuum code. These are **two new polarized on-shell associated-bbH production samples**, not a rerun of charged-current 4b, not the Higgs-excluded continuum, and not a pure VBF/ZZ-only restriction.

## Benchmarks

| | FCC-ue | Muon collider |
|---|---|---|
| Parton process | `mu+ e- > mu+ e- b b~ h QCD=2 QED=6` | `mu+ mu- > mu+ mu- b b~ h QCD=2 QED=6` |
| Beam1 (mu+) | 5000 GeV | 1000 GeV |
| Beam2 (e- or mu-) | 183 GeV | 1000 GeV |
| sqrt(s) | 1913.11265 GeV | 2000 GeV |
| `polbeam1,polbeam2` | `80,0` | `80,0` |
| `lpp1,lpp2` | `0,0` | `0,0` |
| `ptb,ptj` | `0,0` | `0,0` |
| `ptl` on both final leptons | 1 GeV | 1 GeV |
| 4b acceptance | |eta_b| < 5 and two disjoint opposite-charge bb pairs with both invariant masses 110–130 GeV | same |
| Production events | 30,000 | 30,000 |
| Scalar H->bb trials per production event | 100 | 100 |
| Branching factor | `BR_model(H->bb)` once | same |

## Verified code details

- `physics.py`, `lhe_io.py`, `run_workflow.py`, and `collect_results.py` are byte-identical to the earlier CERN-tested continuum package v3.
- `configure_run.py` differs in the required polarization assignment: it reads `[+80,0]` from the scenario configuration instead of forcing unpolarized beams.
- `analyze_lhe.py` differs only in reading the expected final charged leptons from the scenario process specification rather than assuming mu+e-.
- The standard `run_tests.sh` successfully checks both configurations and component names.
- Added an actual synthetic-LHE end-to-end analysis test for both scenarios: verifies outgoing-PDG selection, 3 artificial events per scenario, a simulated H->bb decay, branching factor, and COM-to-lab boost for asymmetric FCC-ue. A deliberately wrong e- in the MuC final state is rejected.
- Default `sm` card in the earlier completed CERN NC bbH archive yields `m_b=4.7 GeV`, `m_H=125 GeV`, and `BR_model(H->bb)=0.8446400227319534`. The new run independently rechecks the new model card; no fixed external precision-SM BR is substituted.
- Scientific metadata typo fixed: the MuC outgoing leptons are `mu+ and mu-`, not `mu+ and e-`. This was documentation only; MG5 process and analyzer already matched the correct final state.
- The on-shell associated-Higgs sample can contain an internally resonant second Higgs in the directly generated bb pair. It may overlap an independently generated HH sample and is **not additive** to it or to full 4b.
- The absence of a **b-quark** pT cut is verified in both generator settings (`ptb=0`) and fiducial-analysis configuration (`min_pt_GeV=0`). The 1 GeV cut on scattered charged leptons is still present and makes the reported *before-b-cut* cross section regulated, not fully inclusive.

## Limitations and mandatory CERN gate

**No real MG5 run of these two new configurations has been performed locally.** Offline tests cannot determine actual MG5 diagrams, compilation success, runtime, accuracy of MC integration, or whether the installed version honors every card field.

On CERN, run `--prepare-only`, then call `python3 check_prepared.py "<exact NEW WORK DIRECTORY>"` from the corresponding scenario directory. Inspect `Cards/run_card.dat` to verify energies and polarization. Proceed to production only if this audit passes.

Even a successful production run remains `ESTIMATE_NOT_CONVERGENCE_VALIDATED`; it requires independent-seed/statistical convergence and, where relevant, study of resonances and coupling-order completeness before precision claims.
