#!/usr/bin/env bash
set -euo pipefail
BASE="${1:-/eos/user/h/hakhanpo/MG5_aMC_v3_6_4}"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OLD="$BASE/FCC_ue_MuC_NC_bbH_P80_2TeV_v2_REVIEWED"
FCC_RUN="$OLD/FCCue_mu5TeV_e183GeV_P80/work/run_20261028T090446Z_f5082f78"
MUC_RUN="$OLD/MuC_2TeV_Pmuplus80/work/run_20261028T090613Z_4bb2f868"

echo '========== FCC-ue existing v2 MG5 audit =========='
python3 "$ROOT/FCCue_mu5TeV_e183GeV_P80/check_prepared.py" "$FCC_RUN"
python3 "$ROOT/validation/audit_existing_preparation.py" fcc "$FCC_RUN"

echo '========== MuC existing v2 MG5 audit =========='
python3 "$ROOT/MuC_2TeV_Pmuplus80/check_prepared.py" "$MUC_RUN"
python3 "$ROOT/validation/audit_existing_preparation.py" muc "$MUC_RUN"

echo 'BOTH PREPARATION AUDITS PASSED (no MG5 processes regenerated)'
