#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
for d in FCCue_mu5TeV_e183GeV_P80 MuC_2TeV_Pmuplus80; do
  python3 -m compileall -q "$ROOT/$d"
  (cd "$ROOT/$d" && python3 - <<'PYTEST'
import json
from pathlib import Path
from processes import COMPONENTS
from configure_run import settings_for
conf=json.loads(Path('configuration.json').read_text())
assert len(COMPONENTS)==1
name=next(iter(COMPONENTS))
s=settings_for(conf,name,30000,12345)
assert s['polbeam1']==80 and s['polbeam2']==0
assert s['lpp1']==0 and s['lpp2']==0
assert s['ptl']==1 and s['ptb']==0
assert tuple(conf['beam_setups'][COMPONENTS[name]['beam']]['pdgs']) == ((-13,11) if name=='mue_NC_bbH' else (-13,13))
assert 'mu+ e-' in COMPONENTS[name]['process'] if name=='mue_NC_bbH' else 'mu+ mu-' in COMPONENTS[name]['process']
assert 'final_lepton_pdgs' in Path('analyze_lhe.py').read_text()
print('PASS', name, 'polarization',s['polbeam1'],s['polbeam2'],'beams',s['ebeam1'],s['ebeam2'])
PYTEST
  )
done

echo "===== Synthetic LHE end-to-end tests ====="
# Each scenario is tested in its own Python interpreter: no sys.modules manipulation.
python3 "$ROOT/synthetic_lhe_smoke_test.py" --scenario FCCue_mu5TeV_e183GeV_P80
python3 "$ROOT/synthetic_lhe_smoke_test.py" --scenario MuC_2TeV_Pmuplus80
printf '%s\n' 'ALL ISOLATED SYNTHETIC TESTS PASSED (exit 0)'
