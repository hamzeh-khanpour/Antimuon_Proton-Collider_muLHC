#!/usr/bin/env python3
"""Synthetic LHE physics/analysis smoke test for both polarized NC bbH scenarios.

These are artificial kinematics, NOT MadGraph predictions. Exercise the
LHE reader, beam identity/boost, outgoing lepton identity, b masses,
spin-0 H decay, opposite-sign mass windows and branching normalization.
"""
import json
import math
from pathlib import Path
import sys
import tempfile

ROOT = Path(__file__).resolve().parent


def particle(pid, status, px, py, pz, energy, mass):
    return (f'{pid} {status} 0 0 0 0 '
            f'{px:.13e} {py:.13e} {pz:.13e} '
            f'{energy:.13e} {mass:.13e} 0 9\n')


def fake_event(beam_pdgs, sroot, wrong_lepton=False):
    e_in = sroot / 2.
    e_l = (sroot - 250.) / 2.
    p_b = math.sqrt(62.5 ** 2 - 4.7 ** 2)
    lep2 = 11 if wrong_lepton else beam_pdgs[1]
    particles = [
        particle(beam_pdgs[0], -1, 0, 0, +e_in, e_in, 0),
        particle(beam_pdgs[1], -1, 0, 0, -e_in, e_in, 0),
        particle(beam_pdgs[0], 1, e_l, 0, 0, e_l, 0),
        particle(lep2, 1, -e_l, 0, 0, e_l, 0),
        particle(5, 1, +p_b, 0, 0, 62.5, 4.7),
        particle(-5, 1, -p_b, 0, 0, 62.5, 4.7),
        particle(25, 1, 0, 0, 0, 125.0, 125.0),
    ]
    return '<event>\n7 1 1.0 0 0 0\n' + ''.join(particles) + '</event>\n'


def fake_lhe(beam_pdgs, e1, e2, wrong_lepton=False):
    sroot = 2. * math.sqrt(e1*e2)
    init = (f'{beam_pdgs[0]} {beam_pdgs[1]} {e1:.12e} {e2:.12e} '
            '0 0 0 0 3 1\n 1.000000e-05 1.000000e-08 1.000000e+00 1\n')
    return ('<LesHouchesEvents version="3.0">\n<header></header>\n<init>\n'
            + init + '</init>\n'
            + ''.join(fake_event(beam_pdgs, sroot, wrong_lepton) for _ in range(3))
            + '</LesHouchesEvents>\n')


PARAM = '''BLOCK MASS\n 5 4.7\n 25 125.0\nBLOCK YUKAWA\n 5 4.7\nBLOCK SMINPUTS\n 2 1.16639e-5\nDECAY 25 0.006382339\n'''


def test_one(scenario):
    """Run one scenario only. Caller uses one interpreter per scenario."""
    scenario = Path(scenario).resolve()
    if scenario.parent != ROOT or scenario.name not in (
            'FCCue_mu5TeV_e183GeV_P80', 'MuC_2TeV_Pmuplus80'):
        raise ValueError('Unexpected scenario path')
    sys.path.insert(0, str(scenario))
    import analyze_lhe
    import processes
    conf = json.loads((scenario/'configuration.json').read_text())
    assert len(processes.COMPONENTS) == 1
    name = next(iter(processes.COMPONENTS))
    spec = processes.COMPONENTS[name]
    beam = conf['beam_setups'][spec['beam']]
    assert sorted(spec['final_lepton_pdgs']) == sorted(beam['pdgs'])
    assert conf['selection']['min_pt_GeV'] == 0
    assert conf['scattered_lepton_cuts']['minimum_pt_GeV'] == 1
    e1,e2 = beam['energies_GeV']
    with tempfile.TemporaryDirectory() as d:
        d = Path(d)
        pc = d/'param_card.dat'; pc.write_text(PARAM)
        lhe = d/'test.lhe'; lhe.write_text(fake_lhe(beam['pdgs'],e1,e2))
        result = analyze_lhe.analyze(lhe,name,pc,conf,decays=100,seed=12001)
        assert result['n_events'] == 3
        assert result['br_power'] == 1
        assert result['n_on_shell_higgs'] == 1
        assert result['fiducial_xsec_fb'] > 0
        assert abs(result['model_inputs']['br_hbb_model']-0.8446400227319534)<1.e-10
        assert result['events_reframed_to_lab'] == (3 if e1!=e2 else 0)
        # Deliberately corrupt final lepton identity in the MuC sample.
        if name == 'mumu_NC_bbH':
            lhe.write_text(fake_lhe(beam['pdgs'], e1,e2, wrong_lepton=True))
            try:
                analyze_lhe.analyze(lhe,name,pc,conf,decays=4,seed=12001)
            except ValueError as e:
                assert 'Unexpected final state' in str(e)
            else:
                raise AssertionError('wrong mu- -> e- final state was accepted')
    print(f'PASS synthetic LHE for {name}: 3 events, 1 Higgs, BR={result["model_inputs"]["br_hbb_model"]:.10f}; lab-reframed={result["events_reframed_to_lab"]}')
    # Guard against importing modules from the other scenario or local site packages.
    assert Path(analyze_lhe.__file__).resolve().parent == scenario
    assert Path(processes.__file__).resolve().parent == scenario


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--scenario', required=True,
                        choices=('FCCue_mu5TeV_e183GeV_P80', 'MuC_2TeV_Pmuplus80'))
    args = parser.parse_args()
    test_one(ROOT / args.scenario)
