#!/usr/bin/env python3
"""Read-only secondary audit of existing v2 CERN prepare-only work directories.

Does not generate diagrams, integrate, modify run cards, or modify old runs.
Requires original scenario check_prepared.py to pass separately.
"""
import argparse
import json
import math
import re
from pathlib import Path
import sys

EXPECTED = {
  'fcc': {'process':'mue_NC_bbH','beams':(5000.,183.),'seed':2708026,
          'n_diagrams':86,'beam_pdgs':[-13,11]},
  'muc': {'process':'mumu_NC_bbH','beams':(1000.,1000.),'seed':2709026,
          'n_diagrams':172,'beam_pdgs':[-13,13]},
}


def parse_card(path):
    values={}
    for ln in path.read_text().splitlines():
        payload=ln.split('!',1)[0].split('#',1)[0]
        if '=' not in payload:
            continue
        raw,key=payload.split('=',1)
        key=key.strip().lower()
        if key in values:
            raise ValueError('Duplicate run-card setting '+key)
        values[key]=raw.strip()
    return values


def num(raw):
    return float(raw.replace('D','E').replace('d','e'))


def check(which,work):
    ex=EXPECTED[which]
    cfg=json.loads((work/'configuration.json').read_text())
    man=json.loads((work/'manifest.json').read_text())
    comp=ex['process']
    proc=work/comp
    name='mue' if which=='fcc' else 'mumu'
    if man['components'] != [comp]:
        raise ValueError('Unexpected manifest components')
    if not man.get('prepare_only') or man.get('overall_status')!='PREPARED_ONLY':
        raise ValueError('Run is not a completed prepare-only workflow')
    if man['execution'].get(comp) != 'PREPARED_NOT_INTEGRATED':
        raise ValueError('Manifest process status is not PREPARED_NOT_INTEGRATED')
    if cfg['beam_setups'][name]['pdgs'] != ex['beam_pdgs']:
        raise ValueError('Beam PDG mismatch')
    if cfg['beam_setups'][name]['energies_GeV'] != list(ex['beams']):
        raise ValueError('Beam-energy config mismatch')
    if cfg['physics_conventions']['polarization_percent'] != [80.,0.]:
        raise ValueError('Polarization config mismatch')
    if cfg['runtime']['nevents_per_component'] != 30000 or cfg['runtime']['decays_per_hh_event']!=100:
        raise ValueError('Expected 30000 production events / 100 decay trials')
    if cfg['runtime']['seed'] != ex['seed']:
        raise ValueError('Run seed mismatch')
    cuts=cfg['selection']
    if (cuts['eta_abs_max'] != 5.0 or cuts['mass_window_GeV'] != [110.,130.]
         or cuts['min_pt_GeV'] != 0 or cuts['min_deltaR'] != 0
         or cuts['pairing'] != 'any_valid_disjoint_opposite_charge'
         or cuts['frame'] != 'laboratory'):
        raise ValueError('Unexpected fiducial selection')
    process_text=(work/'cards'/f'{comp}.mg5').read_text()
    expected_process=(
      'generate mu+ e- > mu+ e- b b~ h QCD=2 QED=6' if which=='fcc'
      else 'generate mu+ mu- > mu+ mu- b b~ h QCD=2 QED=6')
    if expected_process not in process_text:
        raise ValueError('Wrong MadGraph process')
    log=(work/'logs'/f'{comp}_generate.log').read_text()
    diag=[int(x) for x in re.findall(r'Process has (\d+) diagrams',log)]
    if not diag or max(diag)!=ex['n_diagrams']:
        raise ValueError('Unexpected diagram count: '+str(diag))
    card=parse_card(proc/'Cards'/'run_card.dat')
    wanted={
      'lpp1':0,'lpp2':0,'ebeam1':ex['beams'][0],'ebeam2':ex['beams'][1],
      'polbeam1':80,'polbeam2':0,'ptl':1,'ptb':0,'ptj':0,
      'nevents':30000,'iseed':ex['seed'],'etab':-1,'drbb':0,'mmbb':0,
      'ickkw':0,'scale':125,
    }
    for key,expected in wanted.items():
        if key not in card:
            raise ValueError('Missing card key '+key)
        actual=num(card[key])
        if not math.isfinite(actual) or not math.isclose(actual, expected, rel_tol=1e-7,abs_tol=1e-8):
            raise ValueError('Card mismatch '+key+': '+str(actual)+' expected '+str(expected))
    print('SECONDARY AUDIT PASS:',which,work)
    print('  diagrams:',max(diag),' beams:',ex['beams'],' polarizations:(80,0)',
          ' events:30000',' decays:100',' ptb:0',' ptl:1',' scale:125')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('scenario',choices=sorted(EXPECTED))
    p.add_argument('directory',type=Path)
    a=p.parse_args()
    try:
        check(a.scenario,a.directory.resolve())
    except (OSError,ValueError,KeyError,TypeError) as exc:
        p.exit(2,'SECONDARY AUDIT FAILED: '+str(exc)+'\n')

if __name__=='__main__':
    main()
