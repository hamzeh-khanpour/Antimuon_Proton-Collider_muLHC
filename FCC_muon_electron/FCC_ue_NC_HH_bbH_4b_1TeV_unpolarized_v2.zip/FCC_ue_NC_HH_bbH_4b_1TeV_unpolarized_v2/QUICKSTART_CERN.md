# Quick start — 3 unpolarized FCC-ue NC channels (1 TeV benchmark)

**Beam 1:** mu+ 2000 GeV, P=0%; **beam 2:** e- 120 GeV, P=0%.  
**Generator cut:** both final leptons `pT>1 GeV`.  
**Analysis cuts:** all four `|eta_b|<5` and two disjoint bbbar masses 110–130 GeV; no b pT cut.

## Windows PowerShell (upload ZIP)

```powershell
scp "$env:USERPROFILE\Downloads\FCC_ue_NC_HH_bbH_4b_1TeV_unpolarized_v2.zip" hakhanpo@lxplus.cern.ch:~/
```

## CERN LXPLUS (install, validate, prepare)

```bash
cd /eos/user/h/hakhanpo/MG5_aMC_v3_6_4
unzip ~/FCC_ue_NC_HH_bbH_4b_1TeV_unpolarized_v2.zip
cd FCC_ue_NC_HH_bbH_4b_1TeV_unpolarized_v2
export MG5=/eos/user/h/hakhanpo/MG5_aMC_v3_6_4/bin/mg5_aMC
sha256sum -c SHA256SUMS.txt
bash run_tests.sh
bash run_all.sh --only mue_NC_HH  --nevents 30000 --decays 100 --seed 2703026 --prepare-only
bash run_all.sh --only mue_NC_bbH --nevents 30000 --decays 100 --seed 2703026 --prepare-only
bash run_all.sh --only mue_NC_4b  --nevents 30000 --decays 100 --seed 2703026 --prepare-only
```

**After each preparation:** copy its printed `NEW WORK DIRECTORY` and run:

```bash
python3 check_prepared.py /ABSOLUTE/PATH/TO/NEW_WORK_DIRECTORY
```

## Run all three independently in HTCondor (recommended)

```bash
bash batch/make_condor_jobs.sh
cat "$HOME/FCC_ue_NC_1TeV_unpolarized_BATCH/jobs.sub"
condor_submit "$HOME/FCC_ue_NC_1TeV_unpolarized_BATCH/jobs.sub"
condor_q "$USER"
```

**Not an automatic launch:** inspect the submit file first. CERN batch worker EOS access and quota may require site adjustments. See `batch/README.md`.

## Alternative: run each from a compute node

```bash
bash run_all.sh --only mue_NC_HH  --nevents 30000 --decays 100 --seed 2703026
bash run_all.sh --only mue_NC_bbH --nevents 30000 --decays 100 --seed 2703026
bash run_all.sh --only mue_NC_4b  --nevents 30000 --decays 100 --seed 2703026
```

Each creates a different `work/run_*` directory. Each `results.csv` contains three rows; only the selected one is complete in an individual run.

## Merge and package (after all three finish)

```bash
PKG=/eos/user/h/hakhanpo/MG5_aMC_v3_6_4/FCC_ue_NC_HH_bbH_4b_1TeV_unpolarized_v2
cd "$PKG"
RHH="$PKG/work/REPLACE_HH_RUN"
RBBH="$PKG/work/REPLACE_BBH_RUN"
R4B="$PKG/work/REPLACE_4B_RUN"
MERGED="$PKG/work/merged_$(date -u +%Y%m%dT%H%M%SZ)"
python3 merge_results.py --runs "$RHH" "$RBBH" "$R4B" --out "$MERGED"
cat "$MERGED/results.csv"
python3 pack_results.py --runs "$RHH" "$RBBH" "$R4B" "$MERGED" \
  --out "$HOME/FCC_ue_NC_HH_bbH_4b_1TeV_unpolarized_RESULTS.zip"
```

The package deliberately **does not contain physical numerical results**. These are obtained only after MG5 runs on CERN. The HH and bbH rates are **not** to be added to the complete NC4b rate; the complete amplitude already overlaps with both resonant contributions.
