# CERN run package — FCC-ue unpolarized NC HH, bbH and complete 4b

**Version:** v2.0 (26 October 2026)  
**Status:** offline-tested package, **not** an actual MG5 production result.  
**Collision benchmark:** `mu+ (2000 GeV)` on `e- (120 GeV)` (fixed beams), `sqrt(s)=979.795897 GeV`, `polbeam1=0`, `polbeam2=0`.

This package implements **three independent calculations** with the **same full charged-lepton final-state topology** after Higgs decays. It does **not** redo the previously completed neutrino (CC) channels.

| ID (`--only`) | MG5 production process | Final b count | Interpretation | BR power |
|---|---|---|---|---|
| `mue_NC_HH` | `mu+ e- > mu+ e- h h QCD=0 QED=4` | 4 after two H decays | **NC HH signal** | **2** |
| `mue_NC_bbH` | `mu+ e- > mu+ e- b b~ h QCD=2 QED=6` | 4 after one H decay | associated **single-Higgs** contribution | **1** |
| `mue_NC_4b` | `mu+ e- > mu+ e- b b~ b b~ QCD=2 QED=6` | directly 4 | **complete NC 4b**, incl. allowed resonances and their coherent interference | **0** |

`QCD=2 QED=6` means **QCD<=2 and QED<=6** in MG5's process syntax. The complete process is the full tree-level matrix element *within these bounds*, not a calculation with a separately defined signal removed.

**DO NOT ADD** the first two cross sections to the third. The full NC 4b final state overlaps with the resonant contributions and their interference. Equally, do not subtract the on-shell signal from the full amplitude and label the difference a gauge-independent pure background.

## Cut and normalization conventions

**Common final-state bottom-quark analysis selection (same as original CC study):**

1. Exactly two b and two bbar final partons (including Higgs-decay products).
2. Every b/bbar must have `abs(eta_lab)<5` (strict).
3. Two *disjoint*, opposite-charge b-bbar pairs, with **both** masses in `[110, 130] GeV`; either of the two assignments may pass; count an accepted event only once.
4. No b-parton minimum pT cut and no jet clustering, parton shower, b-tagging or detector simulation.

**Mandatory additional NC generator-level regulator:**

`ptl=1.0 GeV` on **each outgoing e- and mu+**. Without finite lepton pT/angle regularization, massless t-channel photon contributions can be singular or strongly forward-enhanced. This is **NOT** a standard lost-lepton background or fully inclusive cross section. The parameter can materially alter the rate; investigate lepton acceptance and vary the regulator before making a physics claim.

**Be precise when presenting a cross-section table:** The column labeled `sigma_before_bcuts_fb` is the cross section **AFTER the outgoing-lepton pT regulator** and BEFORE our offline b eta/invariant-mass selection. It is **not** uncut with respect to the scattered leptons.

**Higgs decays and widths:** Higgs bosons are generated on-shell by MG5 and decayed isotropically to massive b/bbar at four-vector level; 100 independent *pairs of Higgs decays per HH production event* for NC-HH, 100 single-H decays for bbH, one direct selection per full4b event. This is a scalar narrow-width approximation and does not model off-shell/interference effects within the resonant approximations. Normalize using the **actual** `sm/restrict_default.dat` model card via `BR(H->bb)` for bbH, `BR(H->bb)^2` for HH, and **NO BR** for complete 4b. Our earlier card yielded `BR≈0.844640`, not the higher-order SM reference `≈0.582`. Production normalization plus acceptance are estimated with approximate MC uncertainties; no scale/theory/detector errors are included.

## 1. Upload and install on CERN

From **Windows PowerShell** (after saving the ZIP in Downloads):

```powershell
scp "$env:USERPROFILE\Downloads\FCC_ue_NC_HH_bbH_4b_1TeV_unpolarized_v2.zip" hakhanpo@lxplus.cern.ch:~/
```

Connect to LXPLUS and extract **beside the previous packages**, not over them:

```bash
ssh hakhanpo@lxplus.cern.ch  # only if not yet connected
cd /eos/user/h/hakhanpo/MG5_aMC_v3_6_4
unzip ~/FCC_ue_NC_HH_bbH_4b_1TeV_unpolarized_v2.zip
cd FCC_ue_NC_HH_bbH_4b_1TeV_unpolarized_v2
export MG5=/eos/user/h/hakhanpo/MG5_aMC_v3_6_4/bin/mg5_aMC
```

**Verify source hashes:**

```bash
sha256sum -c SHA256SUMS.txt
bash run_tests.sh
```

## 2. Mandatory MG5 preparation and physics-card inspection

These commands DO invoke MG5 to generate matrix elements and write cards, but **do not** perform the expensive numerical integration:

```bash
bash run_all.sh --only mue_NC_HH  --nevents 30000 --decays 100 --seed 2703026 --prepare-only
bash run_all.sh --only mue_NC_bbH --nevents 30000 --decays 100 --seed 2703026 --prepare-only
bash run_all.sh --only mue_NC_4b  --nevents 30000 --decays 100 --seed 2703026 --prepare-only
```

Each creates its own unique `work/run_...` directory and prints `NEW WORK DIRECTORY`. Confirm that each created a `Cards/run_card.dat`, a `Cards/param_card.dat` and a `configuration_audit.json` in its channel folder. Check *each* card, e.g.:

```bash
RUN=/eos/user/h/hakhanpo/MG5_aMC_v3_6_4/FCC_ue_NC_HH_bbH_4b_1TeV_unpolarized_v2/work/REPLACE_WITH_PRINTED_RUN_ID
C=mue_NC_HH

grep -Ei 'lpp1|lpp2|ebeam1|ebeam2|polbeam1|polbeam2|ptl|ptb|ptj|etab|sde_strategy' "$RUN/$C/Cards/run_card.dat"
cat "$RUN/$C/configuration_audit.json" | head -80
```

Required values: `lpp1=lpp2=0`, `ebeam1=2000`, `ebeam2=120`, `polbeam1=polbeam2=0`, `ptl=1`, `ptb=ptj=0`, `etab=-1`, `sde_strategy=2`. No cuts on b partons at generation, only the explicit pT cut on scattered leptons.

After each preparation you can also run the independent preflight checker on its printed work directory:

```bash
python3 check_prepared.py "$RUN"
```

**STOP and inspect logs if any MG5 process fails to generate diagrams or the card audit fails.** We have not run MG5 in the execution environment used to prepare this ZIP.

## 3. Production on CERN: recommended HTCondor jobs

**Prefer CERN HTCondor, not a heavy run inside an LXPLUS login session.** Long integrations previously stopped after SSH disconnections; independent batch jobs isolate failures so completed results are preserved.

The package has an optional job-file preparer that creates **three separate** HTCondor jobs in your AFS `$HOME`, with scientific outputs under the package's EOS `work/` directory. It **does not submit** them automatically.

```bash
# From the package root after a successful --prepare-only check:
export MG5=/eos/user/h/hakhanpo/MG5_aMC_v3_6_4/bin/mg5_aMC
bash batch/make_condor_jobs.sh
cat "$HOME/FCC_ue_NC_1TeV_unpolarized_BATCH/jobs.sub"
# Only after reviewing requested resources and CERN policy:
condor_submit "$HOME/FCC_ue_NC_1TeV_unpolarized_BATCH/jobs.sub"
condor_q "$USER"
```

The generated sample requests **16 CPUs, 16 GB memory and a 1-day (`tomorrow`) job flavour** per job. These are planning defaults, not guarantees; adapt to your actual MG5 `nb_core` and CERN entitlements. Batch worker access to EOS and to your MG5 Python installation must be verified at execution time. If the site's batch submission rules differ, use CERN's official instructions before submission. A new `run_...` work directory is created for each channel without overwriting the others.

### Alternative: one sequential command on a designated compute node

```bash
bash run_all.sh --nevents 30000 --decays 100 --seed 2703026
```

This runs all three channels sequentially, with three separate independent seed offsets and a combined `results.csv` when complete. Be aware that an interruption before channel 3 leaves a **partial run**, not a resumable checkpoint. A detached `tmux` session mitigates ordinary SSH drops but does not replace batch scheduling.

### Alternative: one channel at a time

```bash
bash run_all.sh --only mue_NC_HH  --nevents 30000 --decays 100 --seed 2703026
bash run_all.sh --only mue_NC_bbH --nevents 30000 --decays 100 --seed 2703026
bash run_all.sh --only mue_NC_4b  --nevents 30000 --decays 100 --seed 2703026
```

**Important:** Running each `--only` invocation as a separate shell command creates **three separate run directories**. Their individual `results.csv` files will mark the other channels `NOT_RUN`, which is expected.

## 4. Merge reports from three distinct runs (without rerunning MG5)

After all three channels have `reports/<channel>.json`, use their exact **NEW WORK DIRECTORY** paths:

```bash
PKG=/eos/user/h/hakhanpo/MG5_aMC_v3_6_4/FCC_ue_NC_HH_bbH_4b_1TeV_unpolarized_v2
cd "$PKG"
RHH="$PKG/work/REPLACE_WITH_HH_RUN"
RBBH="$PKG/work/REPLACE_WITH_BBH_RUN"
R4B="$PKG/work/REPLACE_WITH_4B_RUN"
MERGED="$PKG/work/merged_NC_1TeV_$(date -u +%Y%m%dT%H%M%SZ)"
python3 merge_results.py --runs "$RHH" "$RBBH" "$R4B" --out "$MERGED"
cat "$MERGED/results.csv"
```

`merge_results.py` rejects missing reports, duplicated channels, missing run-card provenance, and inconsistent physics/model/cuts/polarization. It collects one row **per independent process**; it never adds the three rates together. Original runs are not modified.

## 5. Archive results and transfer for external review

Use the package's safe handoff ZIP tool. It includes small `results.csv`, JSON reports, logs, run cards, param cards, the config audit and SHA-256 manifest — **no huge LHE events or compiled MG5 binaries**.

```bash
OUT="$HOME/FCC_ue_NC_HH_bbH_4b_1TeV_unpolarized_RESULTS.zip"
python3 pack_results.py --runs "$RHH" "$RBBH" "$R4B" "$MERGED" --out "$OUT"
unzip -t "$OUT" | tail -3
ls -lh "$OUT"
```

Download from **Windows PowerShell** (not LXPLUS):

```powershell
scp "hakhanpo@lxplus.cern.ch:~/FCC_ue_NC_HH_bbH_4b_1TeV_unpolarized_RESULTS.zip" "$env:USERPROFILE\Downloads\"
```

## Output format and interpretation

For each channel, the pipeline generates:

- `reports/<channel>.json`: cross section, event count, acceptance, model BR, BR exponent, fiducial cross section, separate normalization/selection MC errors, the audit of the actual run card.
- `results.csv` and `results.json`: **three rows**, corresponding to NC-HH, NC-bbH and complete NC4b, with `sigma_before_bcuts_fb`, `sigma_fb` and approximate `mc_error_quadrature_approx_fb`.
- `manifest.json`, `configuration.json`, `configuration_audit.json`, `logs/*`: complete provenance and diagnostics.

The generated sample may contain **fewer than the requested 30,000 events**, especially for difficult NC full4b channels. This produces a warning and the available estimate, rather than silently treating missing events as a zero rate. No numerical convergence claim is made. Report finite selected-event statistics carefully; if zero events pass, the primary fiducial cross section is left `null`, not quoted as measured zero.

## Scientific cautions

- Physical comparison to the earlier CC neutrino sample requires detector/reconstruction treatment of the two scattered charged leptons; no CC–NC amplitude interference is possible because the **full final states differ**.
- NC-HH and NC-bbH on-shell rates are overlapping contributions to NC full4b, not additive backgrounds.
- The full NC4b calculation includes interference among diagrams allowed at `QCD<=2, QED<=6`; the on-shell approximations omit off-shell effects and interference.
- The `ptl=1 GeV` scattered-lepton regulator is **provisional** and can have a strong effect. State it in any paper/email table.
- `BR(Hbb)` derived from the original model card differs from precision-SM reference values. Do not quietly substitute `0.582` while retaining the same model width/couplings.
- LO, fixed scale at 125 GeV, no ISR, beamstrahlung, parton shower, hadronization, tagging or detector response. Quoted errors represent only approximate MC components and neglect integration–selection covariance.
