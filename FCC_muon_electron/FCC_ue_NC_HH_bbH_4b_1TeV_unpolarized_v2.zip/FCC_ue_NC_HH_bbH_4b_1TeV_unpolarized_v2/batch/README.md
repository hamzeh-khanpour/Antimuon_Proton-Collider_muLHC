# Optional CERN HTCondor 3-job deployment

This is a **helper**, not an automatic submission. On LXPLUS after the `--prepare-only` checks:

```bash
cd /eos/user/h/hakhanpo/MG5_aMC_v3_6_4/FCC_ue_NC_HH_bbH_4b_1TeV_unpolarized_v2
export MG5=/eos/user/h/hakhanpo/MG5_aMC_v3_6_4/bin/mg5_aMC
bash batch/make_condor_jobs.sh
cat "$HOME/FCC_ue_NC_1TeV_unpolarized_BATCH/jobs.sub"
condor_submit "$HOME/FCC_ue_NC_1TeV_unpolarized_BATCH/jobs.sub"
condor_q "$USER"
```

The generated submit file queues each of the three components **once**, with a unique work directory created by `run_all.sh`. Scientific files are written under EOS. Small scheduler stdout/stderr/log files are written to AFS `$HOME`, which avoids unsupported scheduler-log paths on EOS. `request_cpus=16` is chosen to match the number of MadGraph workers seen in the earlier user's CERN run, but check your actual `me5_configuration.txt` and adapt this request if needed; the helper does not modify MG5's internal worker count. Resources are defaults, not validated for your local CERN entitlements or worker access to EOS. CERN HTCondor may have site-specific requirements; adjust before actual use.

This script intentionally refuses to overwrite an existing `~/FCC_ue_NC_1TeV_unpolarized_BATCH/` directory; change its path if making a subsequent submission. It does not automatically retry partially completed integrations and must not be submitted twice blindly.
