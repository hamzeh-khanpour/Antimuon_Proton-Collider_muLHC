#!/usr/bin/env python3
"""Read-only resonance and fiducial diagnostic for FCC-ue NC MadGraph LHE events.

Usage:
    python3 NC4b_Resonance_Diagnostics.py \
        --full /path/to/mue_NC_4b/Events/run_01/unweighted_events.lhe.gz \
        --bbh /path/to/mue_NC_bbH/Events/run_01/unweighted_events.lhe.gz \
        --out /path/to/nc_resonance_diagnostics.json

Does not modify generator files. Requires only Python 3 standard library.
"""
import argparse
import gzip
import json
import math
from pathlib import Path

THRESHOLDS = [0.01, 0.05, 0.1, 0.5, 1.0, 2.0, 5.0, 10.0]
M_H = 125.0

def iter_events(path):
    opener = gzip.open if str(path).endswith('.gz') else open
    with opener(path, 'rt', encoding='utf-8', errors='replace') as stream:
        inside = False
        header = None
        particles = []
        for raw in stream:
            line = raw.strip()
            if not inside:
                if line.startswith('<event'):
                    inside = True
                    header = None
                    particles = []
                continue
            if line.startswith('</event'):
                if header is not None and len(particles) == header:
                    yield particles
                else:
                    raise RuntimeError('Malformed LHE event (particle count mismatch)')
                inside = False
                continue
            if not line or line.startswith('#') or line.startswith('<'):
                continue
            f = line.split()
            if header is None:
                header = int(f[0])
            elif len(particles) < header:
                if len(f) < 10:
                    raise RuntimeError('Malformed LHE particle row: ' + line)
                particles.append({
                    'pid': int(f[0]), 'status': int(f[1]),
                    'px': float(f[6]), 'py': float(f[7]),
                    'pz': float(f[8]), 'E': float(f[9]),
                })

def invariant_mass(a,b):
    e=a['E']+b['E']
    px=a['px']+b['px']; py=a['py']+b['py']; pz=a['pz']+b['pz']
    return math.sqrt(max(0.0,e*e-px*px-py*py-pz*pz))

def abs_eta(p):
    pt=math.hypot(p['px'],p['py'])
    return abs(math.asinh(p['pz']/pt)) if pt else float('inf')

def full_diagnostics(path):
    r={'file':str(path),'mode':'full_4b','events_total':0,'events_with_four_final_b':0,
       'events_all_b_eta_lt5':0,'events_passing_two_mass_windows_and_eta':0,
       'events_any_os_pair_within_threshold_GeV':{str(t):0 for t in THRESHOLDS},
       'events_two_disjoint_os_pairs_within_threshold_GeV':{str(t):0 for t in THRESHOLDS},
       'events_two_disjoint_os_pairs_within_threshold_and_eta_GeV':{str(t):0 for t in THRESHOLDS},
       'events_two_disjoint_pairs_in_110_130_before_eta':0}
    for event in iter_events(path):
        r['events_total']+=1
        b=[p for p in event if p['pid']==5 and p['status']==1]
        ab=[p for p in event if p['pid']==-5 and p['status']==1]
        if len(b)!=2 or len(ab)!=2:
            continue
        r['events_with_four_final_b']+=1
        eta_pass=all(abs_eta(p)<5 for p in b+ab)
        if eta_pass:r['events_all_b_eta_lt5']+=1
        m=[[invariant_mass(x,y) for y in ab] for x in b]
        pairing_masses=[(m[0][0],m[1][1]),(m[0][1],m[1][0])]
        best_single=min(abs(x-M_H) for row in m for x in row)
        best_double=min(max(abs(x-M_H),abs(y-M_H)) for x,y in pairing_masses)
        window=any(110<=x<=130 and 110<=y<=130 for x,y in pairing_masses)
        if window:r['events_two_disjoint_pairs_in_110_130_before_eta']+=1
        if window and eta_pass:r['events_passing_two_mass_windows_and_eta']+=1
        for t in THRESHOLDS:
            k=str(t)
            if best_single<=t:r['events_any_os_pair_within_threshold_GeV'][k]+=1
            if best_double<=t:
                r['events_two_disjoint_os_pairs_within_threshold_GeV'][k]+=1
                if eta_pass:r['events_two_disjoint_os_pairs_within_threshold_and_eta_GeV'][k]+=1
    r['fiducial_acceptance_independent']=r['events_passing_two_mass_windows_and_eta']/max(1,r['events_total'])
    return r

def bbh_diagnostics(path):
    r={'file':str(path),'mode':'bbH_production','events_total':0,
       'events_with_two_prompt_b_and_one_H':0,
       'events_prompt_bb_in_110_130':0,
       'events_prompt_bb_eta_lt5_and_mass_window':0,
       'events_prompt_bb_near_H_GeV':{str(t):0 for t in THRESHOLDS}}
    for event in iter_events(path):
        r['events_total']+=1
        b=[p for p in event if p['pid']==5 and p['status']==1]
        ab=[p for p in event if p['pid']==-5 and p['status']==1]
        h=[p for p in event if p['pid']==25 and p['status']==1]
        if len(b)!=1 or len(ab)!=1 or len(h)!=1:continue
        r['events_with_two_prompt_b_and_one_H']+=1
        m=invariant_mass(b[0],ab[0])
        if 110<=m<=130:
            r['events_prompt_bb_in_110_130']+=1
            if abs_eta(b[0])<5 and abs_eta(ab[0])<5:
                r['events_prompt_bb_eta_lt5_and_mass_window']+=1
        for t in THRESHOLDS:
            if abs(m-M_H)<=t:r['events_prompt_bb_near_H_GeV'][str(t)]+=1
    return r

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--full',required=True)
    ap.add_argument('--bbh')
    ap.add_argument('--out',required=True)
    args=ap.parse_args()
    r={'note':'Unweighted event counts, not corrected Higgs branching ratios. Diagnostic only.',
       'full': full_diagnostics(args.full)}
    if args.bbh:r['bbH']=bbh_diagnostics(args.bbh)
    text=json.dumps(r,indent=2,sort_keys=True)
    Path(args.out).write_text(text+'\n')
    print(text)
    full=r['full']
    if full['events_total']==30000:
        print('\nCHECK: expected archived number passing full 4b cuts: 442; observed:',
              full['events_passing_two_mass_windows_and_eta'])

if __name__=='__main__':main()
