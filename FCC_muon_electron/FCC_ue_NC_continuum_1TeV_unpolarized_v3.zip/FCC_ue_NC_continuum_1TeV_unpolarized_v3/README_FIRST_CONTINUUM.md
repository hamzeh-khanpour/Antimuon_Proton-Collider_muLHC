# FCC-ue NC Higgs-excluded 4b continuum: reproducible CERN MG5 pilot

## Scientific question
Benchmark: mu+ 2000 GeV, e- 120 GeV, polbeam1=polbeam2=0,
SM model restricted_default, unpolarized sqrt(s) = 979.795897 GeV.
Generator: exactly the same beam card, regulator pTl=1 GeV on both final charged
leptons, same model and coupling limits as prior three completed NC channels.
Selection (after generation, lab frame): 4 massive b partons with |eta_b|<5;
EITHER opposite-charge disjoint pairing has BOTH pair masses 110-130 GeV.
No b-parton pT or DeltaR cut, no shower/jet clustering/detector.

The new component is **mue_NC_continuum**, with MadGraph command:

    generate mu+ e- > mu+ e- b b~ b b~ / h QCD=2 QED=6

'/ h' removes EVERY diagram with an internal Higgs. It is a practical *Higgs-excluded
diagram subset*, NOT a unique physical gauge-invariant resonant-background decomposition.
Gauge cancellations or interference with omitted amplitudes may affect its value.
Do not claim the difference between this and a full 4b calculation is solely
an HH or bbH contribution. No new cross section has been computed here.

## Safety, provenance, and preparation
This package is independently versioned; NEVER overwrite the earlier v2 package
or its `work/` results. `--only mue_NC_continuum` is required to avoid rerunning
the previous three processes. A new work/run_... directory is created on each invocation.
An output with 0 accepted events is reported as an upper limit, not a cross-section=0.

On lxplus after copying ZIP to BASE and extracting there:

    BASE=/eos/user/h/hakhanpo/MG5_aMC_v3_6_4
    cd "$BASE"
    unzip -q FCC_ue_NC_continuum_1TeV_unpolarized_v3.zip
    cd FCC_ue_NC_continuum_1TeV_unpolarized_v3
    export MG5="$BASE/bin/mg5_aMC"
    bash run_tests.sh

**Recommended CPU policy**: Submit computationally demanding jobs to CERN HTCondor,
not the LXPLUS login host. The optional Condor preparer in `batch/` is a template,
not a guaranteed site-approved configuration. Inspect and adapt resources/environment
before submission.

Preflight: process generation + full card auditing, with NO integration:

    bash run_all.sh --only mue_NC_continuum --nevents 5000 --decays 1 \
        --seed 2706026 --prepare-only

Pilot: generates a fresh process and starts numerical integration (heavy!):

    bash run_all.sh --only mue_NC_continuum --nevents 5000 --decays 1 \
        --seed 2706026

For the final result, use >=30000 events with a new independent seed,
assess acceptance effective statistics, vary the lepton pT generator regulator,
and ideally check gauge sensitivity of the diagram selection before calling
it a physical continuum cross section. The original 4b run with 30k events had
442 accepted events, and a Higgs-excluded sample may have lower acceptance.

## Phase 0: investigate the completed full-4b sample (fast and read-only)

Before another expensive integration, check the resonance structure of the
already generated 30k-event complete-4b LHE sample. After unpacking the new
package on CERN:

    bash check_existing_full4b_resonances.sh

This produces `$HOME/FCC_ue_NC_existing_full4b_resonances.json` and prints
counts including the independent reproduction of 442 accepted events. Upload
that JSON for interpretation. This does **not** calculate a continuum-only
cross section; it diagnoses the full four-bottom resonance sampling.

## Outputs and handoff
Each successful run contains results.csv, reports/mue_NC_continuum.json,
logs/{generate,configure,run,analysis}.log, run cards, and manifest.json.
Results.csv also contains NOT_RUN rows for the other three channels (normal).
Create a small shareable archive by inserting your actual RUN directory:

    python3 pack_results.py --runs "$RUN" \
        --out "$HOME/FCC_ue_NC_continuum_pilot_review.zip"

The archive excludes LHE files. Preserve the LHE output on EOS for diagnostic
checks. The installed MG5 version 3.6.4 has not been run here; all tests are
offline synthetic checks and do NOT validate real integration or gauge invariance.

## Why a separate run is required
The previous complete-4b output contains events sampled from the coherent total
amplitude. Counting 442 selected events does NOT project out a Higgs-free
amplitude component, and subtracting independently computed HH and bbH narrow-width
cross sections from the full rate is not a valid continuum extraction.
