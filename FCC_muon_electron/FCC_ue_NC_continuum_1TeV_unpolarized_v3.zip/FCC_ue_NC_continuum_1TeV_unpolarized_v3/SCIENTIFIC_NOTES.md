# Scientific specification — neutral-current three-channel extension

## Motivation and comparison to earlier CC study

The previous FCC-ue calculation generated `mu+ e- > ve vm~ HH` followed by `HH -> 4b`, and `mu+ e- > ve vm~ b b~ b b~`. Those two original **neutrino** channels remain separate and unmodified. Krzysztof specifically asked whether `mu+ e- > mu+ e- b b~ H` with `H -> bb` was included. It was **not**: it produces final-state scattered charged leptons rather than neutrinos. Such charged-lepton events can contribute to a four-b-tag sample if those leptons escape experimental identification, but there is no quantum interference between different complete final states `nu_e anti-nu_mu 4b` and `mu+ e- 4b`.

The requested new unpolarized benchmark is `E_mu+ = 2000 GeV`, `E_e- = 120 GeV`, `sqrt(s)=979.795897 GeV`, `P_mu+=P_e-=0`. We include:

- `mue_NC_HH`: `mu+ e- > mu+ e- h h QCD=0 QED=4` — NC double-Higgs signal.
- `mue_NC_bbH`: `mu+ e- > mu+ e- b b~ h QCD=2 QED=6` — associated single-Higgs contribution.
- `mue_NC_4b`: `mu+ e- > mu+ e- b b~ b b~ QCD=2 QED=6` — all tree-level diagrams permitted by these coupling-order ceilings.

## Correct mathematics and normalization

For model-card `B=BR(H->bb)` and our fiducial b-quark acceptance `A` (including the 110–130 GeV pair mass windows), define:

```
sigma_NC_HH_before_4b_cuts = sigma(mu e -> mu e HH; pTl>1 GeV) * B^2
sigma_NC_bbH_before_4b_cuts = sigma(mu e -> mu e bbH; pTl>1 GeV) * B
sigma_NC_4b_before_4b_cuts = sigma(mu e -> mu e 4b; pTl>1 GeV)

sigma_after = sigma_before_4b_cuts * A
```

The first two use isotropic decay of a scalar on shell; they do not implement quantum interference or spin correlation with the production final state (for a scalar isotropy is appropriate). The full 4b result has all final-state bottom partons explicitly in the LO matrix element. Never multiply the full 4b number by `B`, and never multiply any **after-cuts** HH or bbH rate by `B` again.

`QCD=2 QED=6` are inclusive diagram-order ceilings in MadGraph (`<=`), not exact fixed-order requirements. The complete 4b matrix element includes resonance contributions and their interference as dictated by those constraints; the separately computed on-shell HH and bbH numbers cannot be added to it or simply subtracted from it to isolate an independent background. Also, a complete detector-level Higgs sample would need a treatment of off-shellness and combinatorial interference beyond this LO exercise.

## Selection cuts and unavoidable NC regulator

- Four b/bbar partons: `|eta_b(lab)|<5`, strict.
- Opposite-charge b bbar paired twice in disjoint ways; accept if **either** pairing has both reconstructed masses in `[110,130] GeV`. Count the event once.
- No bottom-parton pT or jet angular cuts. All cuts above applied **after** production (and scalar decays) at LHE level.
- Additional NC regulator: at MG generation **both outgoing e- and mu+ have `pT > 1 GeV`** (`ptl=1`). This is not a detector selection; the forward photon t-channel singularity/strong enhancement in massless lepton limit requires a finite definition. Thus all “before cuts” NC numbers are **before b selection but already after lepton-pT cut**.
- Parameter-card b mass `4.7 GeV` (massive), Higgs mass `125 GeV`; `B` is derived from the actual model-card width/Yukawa/GF and is typically `~0.844640`, not the SM higher-order reference `~0.582`.

## How we assess quality

1. All three process cards produce diagrams in CERN MG5 (`--prepare-only`, inspect logs).
2. All three actual `run_card.dat` files pass the independent analyzer audit for energies, beam IDs, polarizations, the lepton regulator and absence of b generation cuts.
3. Generator outputs valid positive-weight LHE samples with verified beam IDs, four-momentum conservation, final-state PDGs and on-shell masses.
4. Analysis confirms BR powers `2,1,0`, lab-frame selection and independent event clustering for multiple Higgs decays.
5. Each numerical cross section and the MC uncertainty comes from **CERN output**, not the packaged tests. The offline fixture cross section `0.01 pb` is synthetic and must **never** appear as an actual FCC-ue prediction.
6. Nonconvergent and undergenerated channels remain labeled preliminary. A real physics conclusion requires independent seeds and at least a scattered-lepton pT-cut stability study.

## Reference previous unpolarized 1 TeV CC data (not computed by this package)

| Original FCC-ue CC channel | Before b cuts (fb) | After b cuts (fb) |
|---|---:|---:|
| `nu_e anti-nu_mu HH -> nu_e anti-nu_mu 4b` | 0.04958061 | 0.04912449 |
| Complete `nu_e anti-nu_mu 4b` | 0.86610580 | 0.05355421 |

These are **only reference** values from the previous calculation. No new CC cross sections are generated here.
