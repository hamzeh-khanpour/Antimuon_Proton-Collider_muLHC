# Validation record — v2.0 (2026-10-26)

## Scope

This package is a targeted extension of the previous CERN workflow, with original streaming LHE reader, massive-b kinematics, lab boost, Higgs scalar decay, 4b-pairing logic, run-card normalization and report collection. Adds independent `mue_NC_HH` component (QCD=0, QED=4) to the existing NC associated Higgs and complete NC4b definitions. The two existing NC definitions were retained.

## Offline checks passed

- Syntax checking (`compileall`) of every Python module.
- Eleven synthetic LHE / configuration / integration tests (`bash run_tests.sh`):
  1. All three exact final-state process cards and BR exponents 2,1,0.
  2. Generator settings for 2000/120 GeV beams, `polbeam1=polbeam2=0`, `ptl=1`, disabled b generation cuts and `sde_strategy=2`.
  3. Independent run-card parser acceptance and rejection of wrong polarization or lepton regulator.
  4. Asymmetric laboratory boost, two valid opposite-sign pairings counted at most once.
  5. Isotropic scalar daughter four-momentum conservation and massive b mass.
  6. Correct analysis for HH (two H decays), bbH (one H decay), direct4b (zero BR factors); event-level correlated-decay clustering and cross-section normalization.
  7. Rejection of wrong final-state charged leptons or incorrect regulator.
  8. Rejection of a mixed 0%/+80% report merge.
  9. Non-destructive merge of separate channel reports, rejection of missing/duplicate channels, and small ZIP handoff with no LHE.
  10. Prepared-run preflight checker verifies diagram counts, actual run cards, model inputs, and rejects misconfigured polarization.
  11. Schema-aware generator-cut neutralizer leaves inactive `dparameter` alone and clears b cuts.
- Verified that the `verify_run_card` parser reads a genuine CERN-produced **previous** 1 TeV MG5 v3.6.4 run card when its known 80% polarization and zero lepton regulator are supplied as expected values. This is *not* a successful new NC generator test, but it establishes format compatibility for the run-card parser.
- Smoke-tested the optional HTCondor helper using a temporary AFS-like HOME and fake MG5 file, checking syntax of its three job entries. This is **not** a genuine `condor_submit` submission.

## Not validated offline

- No MadGraph5 executable/model installation was available in this artifact-building environment. Therefore, **MG5 diagram generation, 2->4/2->5/2->6 compilations, any numerical survey/refinement, runtime, event-output schema and physical convergence remain untested** on this new package. First run each component with `--prepare-only` on the target CERN MG5 v3.6.4, inspect process-generation logs and run-card audits, then run on computing resources.
- NC rates can be very sensitive to the scattered-lepton cutoff. `ptl=1 GeV` is a provisional regulator, not a physical detector acceptance and not the same as the no-lepton cut used previously in the CC sample.
- All estimates are LO parton-level with approximate MC errors only. Differential, detector or inter-sample systematic uncertainties are not provided.

## Required CERN quality gates

1. `bash run_tests.sh` passes on LXPLUS.
2. All three `--prepare-only` commands complete, three process directories have `Cards/param_card.dat`, `Cards/run_card.dat`, and `configuration_audit.json`; each MG5 log reports a nonzero number of diagrams.
3. `run_card.dat` values meet the fixed 2000/120 GeV, 0/0 polarization, `ptl=1` and no b generation cuts.
4. Successful `generate_events` returns an LHE file and output analysis reports for each component. Any warning about event shortfall or insufficient selected events is retained explicitly.
5. The collected `results.csv` has three independent rows, not an incorrectly summed rate.
