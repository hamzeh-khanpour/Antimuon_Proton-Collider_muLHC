# Optional CERN HTCondor deployment: Higgs-excluded continuum pilot

Read `../README_FIRST_CONTINUUM.md`. This helper prepares a **single**
`mue_NC_continuum` pilot batch job (5000 events, seed 2706026). It does not
submit automatically, nor does it resume a partially completed MG5 integration.

On LXPLUS after extracting the new v3 archive under BASE:

```bash
BASE=/eos/user/h/hakhanpo/MG5_aMC_v3_6_4
cd "$BASE/FCC_ue_NC_continuum_1TeV_unpolarized_v3"
export MG5="$BASE/bin/mg5_aMC"
bash batch/make_condor_jobs.sh
cat "$HOME/FCC_ue_NC_continuum_1TeV_BATCH/jobs.sub"
# Inspect and adapt the queue, resources and environment before submission.
condor_submit "$HOME/FCC_ue_NC_continuum_1TeV_BATCH/jobs.sub"
condor_q "$USER"
```

The scheduler `stdout/stderr/log` are written in `$HOME` (AFS), while the
MG5 process outputs are written under the package's `work/` on EOS. The
helper requests 16 CPUs, 16 GB RAM, 8 GB scratch and a `tomorrow` queue
flavour; these **are not validated for your specific CERN batch environment**.
Check local CERN policy, EOS access from batch workers, and the installed
MG5 worker configuration before submission. Long 2-to-6 integrations should
run on batch rather than shared LXPLUS login nodes.

A fresh work directory is allocated on every run. Never rerun/submit the
same pilot blindly if the first job is incomplete.
