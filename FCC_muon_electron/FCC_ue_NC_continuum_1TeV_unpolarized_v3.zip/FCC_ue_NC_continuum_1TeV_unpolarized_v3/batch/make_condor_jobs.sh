#!/usr/bin/env bash
# Optional CERN HTCondor preparer. Does not submit a job automatically.
set -euo pipefail
PKG="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
: "${HOME:?Set HOME on LXPLUS}"
BATCH_DIR="$HOME/FCC_ue_NC_continuum_1TeV_BATCH"
MG5="${MG5:-/eos/user/h/hakhanpo/MG5_aMC_v3_6_4/bin/mg5_aMC}"

# Keep batch files on AFS (HOME), output scientific files in EOS package work/.
if [ -e "$BATCH_DIR" ]; then
    echo "Batch directory already exists; refusing to overwrite: $BATCH_DIR" >&2
    exit 2
fi
if [ ! -f "$PKG/run_all.sh" ]; then echo "Missing workflow package: $PKG" >&2; exit 2; fi
if [ ! -f "$MG5" ]; then echo "MG5 executable does not exist: $MG5" >&2; exit 2; fi
mkdir -p "$BATCH_DIR/logs"
cat > "$BATCH_DIR/worker.sh" <<EOF
#!/usr/bin/env bash
set -euo pipefail
CHANNEL="\${1:?Channel must be provided}"
case "\$CHANNEL" in
  mue_NC_continuum) ;;
  *) echo "Unknown channel \$CHANNEL" >&2; exit 2 ;;
esac
export MG5="$MG5"
PKG="$PKG"
test -f "\$MG5" || { echo 'MG5 is unavailable on this worker' >&2; exit 2; }
test -f "\$PKG/run_all.sh" || { echo 'EOS package path unavailable on this worker' >&2; exit 2; }
cd "\$PKG"
exec bash ./run_all.sh --only "\$CHANNEL" --nevents 5000 --decays 1 --seed 2706026
EOF
chmod 700 "$BATCH_DIR/worker.sh"
cat > "$BATCH_DIR/jobs.sub" <<EOF
universe = vanilla
executable = $BATCH_DIR/worker.sh
arguments = \$(channel)
output = $BATCH_DIR/logs/\$(channel).\$(ClusterId).out
error = $BATCH_DIR/logs/\$(channel).\$(ClusterId).err
log = $BATCH_DIR/logs/htcondor.\$(ClusterId).log
getenv = True
should_transfer_files = NO
request_cpus = 16
request_memory = 16 GB
request_disk = 8 GB
+JobFlavour = "tomorrow"
queue channel from (
  mue_NC_continuum
)
EOF
printf '\nBatch job files prepared (NOT submitted): %s\n' "$BATCH_DIR"
printf 'Inspect and submit when ready:\n  cat "%s"\n  condor_submit "%s"\n' "$BATCH_DIR/jobs.sub" "$BATCH_DIR/jobs.sub"
printf 'Monitor: condor_q "$USER"\n'
