#!/usr/bin/env bash
# Read-only: uses the previously completed LHE files, does not launch MG5.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE="${BASE:-/eos/user/h/hakhanpo/MG5_aMC_v3_6_4}"
PKG="$BASE/FCC_ue_NC_HH_bbH_4b_1TeV_unpolarized_v2"
BBH="$PKG/work/run_20261026T150929Z_d3048c53/mue_NC_bbH/Events/run_01/unweighted_events.lhe.gz"
FULL="$PKG/work/run_20261026T151014Z_445f5378/mue_NC_4b/Events/run_01/unweighted_events.lhe.gz"
OUT="${1:-$HOME/FCC_ue_NC_existing_full4b_resonances.json}"
for f in "$BBH" "$FULL"; do
  test -s "$f" || { echo "ERROR: expected LHE file missing: $f" >&2; exit 2; }
done
if test -e "$OUT"; then
  echo "ERROR: refusing overwrite of existing output: $OUT" >&2
  exit 2
fi
python3 "$ROOT/NC4b_Resonance_Diagnostics.py" \
  --full "$FULL" --bbh "$BBH" --out "$OUT"
echo "Diagnostic JSON: $OUT"
