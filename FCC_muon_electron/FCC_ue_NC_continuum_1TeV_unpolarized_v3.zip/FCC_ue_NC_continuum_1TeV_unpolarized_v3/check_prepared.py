#!/usr/bin/env python3
"""Independent preflight gate for real MG5 --prepare-only workflow directories.

No integration or event generation is performed. Refuses any missing/incorrect card.
"""
import argparse
import json
import math
from pathlib import Path
import re
from analyze_lhe import verify_run_card
from physics import model_inputs
from processes import COMPONENTS


def inspect_run(path):
    path=Path(path).resolve()
    manifest_path=path/'manifest.json'
    config_path=path/'configuration.json'
    if not (manifest_path.is_file() and config_path.is_file()):
        raise ValueError('Missing manifest or effective configuration: '+str(path))
    manifest=json.loads(manifest_path.read_text())
    config=json.loads(config_path.read_text())
    chosen=manifest['components']
    if not chosen or any(name not in COMPONENTS for name in chosen):
        raise ValueError('Unknown/empty process list in manifest')
    data={}
    for name in chosen:
        proc=path/name
        log=path/'logs'/(name+'_generate.log')
        audit=proc/'configuration_audit.json'
        card=proc/'Cards'/'run_card.dat'
        param=proc/'Cards'/'param_card.dat'
        gen_card=path/'cards'/(name+'.mg5')
        for file in (log,audit,card,param,gen_card):
            if not file.is_file():
                raise ValueError('Missing prepared artifact: '+str(file))
        text=log.read_text(errors='replace')
        diagrams=[int(n) for n in re.findall(r'Process has\s+(\d+)\s+diagrams',text,re.I)]
        if not diagrams or max(diagrams)<=0:
            raise ValueError('Missing positive MG5 diagram count in '+str(log))
        if ('generate '+COMPONENTS[name]['process']) not in gen_card.read_text():
            raise ValueError('Wrong generated process card for '+name)
        cfg_audit=json.loads(audit.read_text())
        if cfg_audit.get('component')!=name:
            raise ValueError('Wrong component in configuration audit: '+name)
        cards=verify_run_card(card,name,config)
        physics=model_inputs(param)
        if not math.isclose(physics['mb_GeV'],config['required_model_values']['mass_5_GeV'],rel_tol=0,abs_tol=1.e-9):
            raise ValueError('Unexpected b mass')
        if not math.isclose(physics['mh_GeV'],config['required_model_values']['mass_25_GeV'],rel_tol=0,abs_tol=1.e-9):
            raise ValueError('Unexpected Higgs mass')
        if not math.isclose(physics['br_hbb_model'],cfg_audit['model_inputs']['br_hbb_model'],rel_tol=1.e-9):
            raise ValueError('Parameter card and saved configuration audit disagree about Higgs BR')
        data[name]={'diagram_counts':diagrams,'run_card_critical_settings':cards,
                    'BR_Hbb_from_model':physics['br_hbb_model'],
                    'production_mode':COMPONENTS[name]['mode'],
                    'Hbb_branch_power':COMPONENTS[name]['br_power'],
                    'manifest_execution_status':manifest['execution'].get(name)}
    return data


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('run',type=Path,help='Path printed as NEW WORK DIRECTORY by --prepare-only')
    a=p.parse_args()
    try:
        result=inspect_run(a.run)
        print('PREPARATION AUDIT PASS:',a.run.resolve())
        for name,detail in result.items():
            print(name, 'diagrams=',detail['diagram_counts'],
                  'BR(Hbb)=',detail['BR_Hbb_from_model'],
                  'expected BR power=',detail['Hbb_branch_power'])
    except (ValueError,KeyError,OSError,TypeError) as exc:
        p.exit(2,'PREPARATION AUDIT FAILED: '+str(exc)+'\n')

if __name__=='__main__':main()
