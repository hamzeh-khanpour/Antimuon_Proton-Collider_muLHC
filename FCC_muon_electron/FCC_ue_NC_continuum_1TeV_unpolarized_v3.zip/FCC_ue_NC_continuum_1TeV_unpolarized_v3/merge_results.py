#!/usr/bin/env python3
"""Safely combine JSON reports from separate one-channel runs.

This is metadata/results aggregation only, NEVER an addition of NC rates.
"""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
from collect_results import collect
from processes import COMPONENTS


def digest(p):
    h=hashlib.sha256()
    with open(p,'rb') as src:
        for chunk in iter(lambda:src.read(2**20),b''):
            h.update(chunk)
    return h.hexdigest()


def merge(runs, output, require_all=True):
    runs=[Path(x).resolve() for x in runs]
    output=Path(output).resolve()
    if output.exists():
        raise ValueError('Refusing to overwrite existing directory: '+str(output))
    if not runs:
        raise ValueError('At least one run directory must be supplied')
    located={}
    provenance={}
    for run in runs:
        reports=run/'reports'
        if not reports.is_dir():
            raise ValueError('No reports directory: '+str(reports))
        found=0
        for path in reports.glob('*.json'):
            # Reject unexpected component names: prevents mixing CC/NC samples.
            if path.stem not in COMPONENTS:
                raise ValueError('Unexpected report in '+str(reports)+': '+path.name)
            name=path.stem
            report=json.loads(path.read_text())
            if report.get('component')!=name:
                raise ValueError('Report claims a different component: '+str(path))
            if name in located:
                raise ValueError('Duplicate component '+name+' in '+str(path)+' and '+str(located[name]))
            if not report.get('run_card_checks') or not report.get('run_card_sha256'):
                raise ValueError('Run-card provenance is missing for '+str(path))
            located[name]=path
            provenance[name]={'source_path':str(path),'sha256':digest(path),
                              'source_run':str(run),
                              'actual_run_card_sha256':report['run_card_sha256'],
                              'actual_param_card_sha256':report['param_card_sha256']}
            found+=1
        if not found:
            raise ValueError('No completed component reports in '+str(reports))
    if require_all and set(located)!=set(COMPONENTS):
        raise ValueError('Missing channels: '+str(sorted(set(COMPONENTS)-set(located))))
    output.mkdir(parents=True)
    (output/'reports').mkdir()
    for name,path in located.items():
        shutil.copy2(path,output/'reports'/(name+'.json'))
    (output/'merge_sources.json').write_text(json.dumps(provenance,indent=2)+'\n')
    try:
        rows=collect(output)
        if require_all and any(row['status'] in ('NOT_RUN','INCOMPLETE','UNRESOLVED_COMPONENT_NO_SELECTED_EVENTS') for row in rows):
            raise ValueError('Collection did not produce all finite results')
        return rows
    except Exception:
        # Leave the new directory with source copies for forensics; never mutate originals.
        raise


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runs',nargs='+',type=Path,required=True,
                        help='One or more completed workflow run directories')
    parser.add_argument('--out',type=Path,required=True,
                        help='New/nonexistent output directory for merged JSON/CSV')
    parser.add_argument('--allow-partial',action='store_true')
    args=parser.parse_args()
    try:
        rows=merge(args.runs,args.out,not args.allow_partial)
        for row in rows:
            print(row['process'],row['status'],row['sigma_fb'],'fb')
        print('Merged results:',args.out.resolve()/'results.csv')
    except (ValueError,KeyError,OSError,TypeError) as exc:
        parser.exit(2,'ERROR: '+str(exc)+'\n')

if __name__=='__main__':
    main()
