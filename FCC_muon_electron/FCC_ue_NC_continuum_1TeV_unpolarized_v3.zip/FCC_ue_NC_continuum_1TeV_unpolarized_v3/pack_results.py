#!/usr/bin/env python3
"""Create small, self-contained audit ZIP(s): NO large LHE or compiled code."""
import argparse
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from processes import COMPONENTS


def digest(data):
    return hashlib.sha256(data).hexdigest()


def gather(run):
    run=Path(run).resolve()
    if not run.is_dir():
        raise ValueError('Run directory absent: '+str(run))
    selected=[]
    for file in ('results.csv','results.json','manifest.json','configuration.json','merge_sources.json'):
        p=run/file
        if p.is_file(): selected.append(p)
    for folder in ('reports','logs','cards'):
        if (run/folder).is_dir():
            selected += [p for p in (run/folder).rglob('*') if p.is_file()]
    for name in COMPONENTS:
        for file in ('Cards/run_card.dat','Cards/param_card.dat','configuration_audit.json'):
            p=run/name/file
            if p.is_file(): selected.append(p)
    if not (run/'reports').is_dir() or not list((run/'reports').glob('*.json')):
        raise ValueError('No completed channel report in: '+str(run))
    # Safety guard: accidental huge log files or binaries are not included.
    selected=sorted(set(selected))
    if any(p.stat().st_size>25*1024*1024 for p in selected):
        raise ValueError('File >25 MB in handoff selection: '+str(next(p for p in selected if p.stat().st_size>25*1024*1024)))
    return run,selected


def pack(runs,out):
    out=Path(out).expanduser().resolve()
    if out.exists():
        raise ValueError('Output ZIP already exists; refusing overwrite: '+str(out))
    items=[gather(run) for run in runs]
    names=[run.name for run,_ in items]
    if len(names)!=len(set(names)):
        raise ValueError('Two source runs share the same directory name')
    out.parent.mkdir(parents=True,exist_ok=True)
    manifest=[]
    with ZipFile(out,'w',compression=ZIP_DEFLATED,compresslevel=7) as zipfile:
        for run,files in items:
            for path in files:
                arc=f'{run.name}/{path.relative_to(run).as_posix()}'
                data=path.read_bytes()
                zipfile.writestr(arc,data)
                manifest.append({'filename':arc,'sha256':digest(data),'bytes':len(data)})
        zipfile.writestr('MANIFEST_SHA256.json',json.dumps(manifest,indent=2)+'\n')
    return out


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runs',nargs='+',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    try:
        path=pack(args.runs,args.out)
        print('Audit handoff:',path,'size:',path.stat().st_size,'bytes')
    except (ValueError,OSError) as exc:
        parser.exit(2,'ERROR: '+str(exc)+'\n')

if __name__=='__main__':
    main()
