#!/usr/bin/env python3
"""Unpolarized FCC-ue NC channels plus Higgs-excluded continuum diagnostic.

These are overlapping and/or diagram-defined contributions, NOT additive samples.
Excluding Higgs internal lines is NOT guaranteed gauge invariant.
"""
from pathlib import Path

GROUPS = ('mue_NC_HH', 'mue_NC_bbH', 'mue_NC_4b', 'mue_NC_continuum')
COMPONENTS = {
    'mue_NC_HH': dict(group='mue_NC_HH', beam='mue', mode='hh',
        final_lepton_pdgs=(11,-13), br_power=2,
        process='mu+ e- > mu+ e- h h QCD=0 QED=4'),
    'mue_NC_bbH': dict(group='mue_NC_bbH', beam='mue', mode='bbh',
        final_lepton_pdgs=(11,-13), br_power=1,
        process='mu+ e- > mu+ e- b b~ h QCD=2 QED=6'),
    'mue_NC_4b': dict(group='mue_NC_4b', beam='mue', mode='fourb',
        final_lepton_pdgs=(11,-13), br_power=0,
        process='mu+ e- > mu+ e- b b~ b b~ QCD=2 QED=6'),
    'mue_NC_continuum': dict(group='mue_NC_continuum', beam='mue', mode='fourb',
        final_lepton_pdgs=(11,-13), br_power=0,
        process='mu+ e- > mu+ e- b b~ b b~ / h QCD=2 QED=6'),
}

def card_text(name):
    if name not in COMPONENTS:
        raise ValueError('Unknown component: '+name)
    return '\n'.join([
        '# FCC-ue charged-lepton neutral-current channel; beam1 mu+, beam2 e-.',
        '# QCD=X and QED=Y mean inclusive UPPER bounds in MadGraph5.',
        '# Couplings and cuts audited later in configure_run.py.',
        'set automatic_html_opening False',
        'set group_subprocesses False',
        'import model sm',
        'generate '+COMPONENTS[name]['process'],
        'output '+name,
        'quit', '',
    ])

def write_cards(folder):
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    for name in COMPONENTS:
        (folder/(name+'.mg5')).write_text(card_text(name))

if __name__ == '__main__':
    write_cards(Path(__file__).parent/'cards')
