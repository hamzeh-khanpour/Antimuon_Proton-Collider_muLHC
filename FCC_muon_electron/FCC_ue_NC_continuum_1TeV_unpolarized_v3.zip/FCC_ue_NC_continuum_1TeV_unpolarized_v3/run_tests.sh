#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
python3 -m compileall -q analyze_lhe.py collect_results.py configure_run.py \
  lhe_io.py physics.py processes.py run_workflow.py merge_results.py pack_results.py check_prepared.py
python3 -m unittest discover -s tests -p 'test_*.py' -v
