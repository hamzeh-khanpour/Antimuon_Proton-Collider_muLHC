"""Offline logic tests with synthetic event 4-vectors (not MG5 predictions)."""
import copy
import json
import math
from pathlib import Path
from random import Random
import tempfile
import unittest
import sys
from zipfile import ZipFile
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from physics import P4,Particle,select,scalar_to_bb,lab_particles,model_inputs
from processes import COMPONENTS,GROUPS,card_text
from configure_run import settings_for,neutralize_registered_cuts
from analyze_lhe import analyze,verify_run_card
from collect_results import collect
from merge_results import merge
from pack_results import pack
from check_prepared import inspect_run
from processes import card_text
CONF=json.loads((ROOT/'configuration.json').read_text())
PARAM='''BLOCK SMINPUTS
 1 1.325070e2
 2 1.166390d-5
 3 1.180000e-1
BLOCK MASS
 5 4.700000e0
 11 0.
 13 0.
 25 1.250000e2
BLOCK YUKAWA
 5 4.700000e0
DECAY 25 6.38233934e-3
'''

def example_particles(mode, lepton_pt=20.):
    # Conservation-preserving CM fixture boosted to FCC-ue asymmetric lab.
    shat=2*math.sqrt(2000*120)
    inc=[Particle(-13,-1,P4(shat/2,0,0,shat/2)),
         Particle(11,-1,P4(shat/2,0,0,-shat/2))]
    E=62.5
    mom=math.sqrt(E*E-4.7**2)
    if mode=='hh':
        had=[Particle(25,1,P4(125,0,0,0)),Particle(25,1,P4(125,0,0,0))]
    elif mode=='bbh':
        had=[Particle(5,1,P4(E,mom,0,0)),Particle(-5,1,P4(E,-mom,0,0)),
             Particle(25,1,P4(125,0,0,0))]
    elif mode=='fourb':
        had=[Particle(5,1,P4(E,mom,0,0)),Particle(-5,1,P4(E,-mom,0,0)),
             Particle(5,1,P4(E,0,mom,0)),Particle(-5,1,P4(E,0,-mom,0))]
    else:
        raise ValueError(mode)
    lept_e=(shat-250)/2
    pz=math.sqrt(lept_e*lept_e-lepton_pt*lepton_pt)
    lept=[Particle(-13,1,P4(lept_e,lepton_pt,0,pz)),
          Particle(11,1,P4(lept_e,-lepton_pt,0,-pz))]
    boost=.5*math.log(2000/120)
    return [Particle(v.pid,v.status,v.p.boost_z(boost)) for v in inc+had+lept]

def write_lhe(path,mode,n=12,pt=20.,pid_override=None):
    rows=['<LesHouchesEvents version="3.0">','<header/>','<init>',
          ' -13 11 2000 120 0 0 0 0 3 1',
          ' 1.000000e-2 1.000000e-4 1.0 1','</init>']
    for _ in range(n):
        particles=example_particles(mode,pt)
        if pid_override is not None:
            particles[-1]=Particle(pid_override,1,particles[-1].p)
        rows.append('<event>')
        rows.append(f'{len(particles)} 1 1 125 0.007 0.118')
        for v in particles:
            p=v.p
            mass=p.mass if abs(v.pid) in (5,25) else 0.
            rows.append(f'{v.pid} {v.status} 0 0 0 0 {p.x:.12e} {p.y:.12e} {p.z:.12e} {p.E:.12e} {mass:.12e} 0 9')
        rows.append('</event>')
    rows.append('</LesHouchesEvents>')
    Path(path).write_text('\n'.join(rows)+'\n')

def run_card(path,polarization=0,lepton_pt=1.):
    settings={'lpp1':0,'lpp2':0,'ebeam1':2000,'ebeam2':120,
              'polbeam1':polarization,'polbeam2':0,'ptl':lepton_pt,
              'ptb':0,'ptj':0,'sde_strategy':2,'ickkw':0,
              'etab':-1,'mmbb':0,'drbb':0}
    Path(path).write_text('\n'.join(f'{val} = {name} ! synthetic card' for name,val in settings.items())+'\n')

class NCThreeTests(unittest.TestCase):
    def test_process_cards_and_normalizations(self):
        self.assertEqual(tuple(COMPONENTS),GROUPS)
        self.assertEqual(len(COMPONENTS),4)
        self.assertEqual([COMPONENTS[n]['br_power'] for n in GROUPS],[2,1,0,0])
        self.assertEqual(CONF['beam_setups']['mue']['energies_GeV'],[2000.,120.])
        self.assertEqual(CONF['physics_conventions']['polarization_percent'],[0.,0.])
        for name in GROUPS:
            t=card_text(name)
            self.assertIn('generate mu+ e- > mu+ e-',t)
            self.assertIn('output '+name,t)
            self.assertNotIn('ve vm~',t)
            self.assertEqual((ROOT/'cards'/(name+'.mg5')).read_text(),t)
        self.assertIn('h h QCD=0 QED=4',card_text('mue_NC_HH'))
        self.assertIn('b b~ h QCD=2 QED=6',card_text('mue_NC_bbH'))
        self.assertIn('b b~ b b~ QCD=2 QED=6',card_text('mue_NC_4b'))
        self.assertIn('b b~ b b~ / h QCD=2 QED=6',card_text('mue_NC_continuum'))
        self.assertEqual(COMPONENTS['mue_NC_continuum']['mode'],'fourb')

    def test_generator_settings(self):
        for name in GROUPS:
            card=settings_for(CONF,name,30000,2712)
            for key,val in {'ebeam1':2000,'ebeam2':120,'polbeam1':0,'polbeam2':0,
                            'ptl':1.,'ptb':0.,'ptj':0.,'etab':-1.,'sde_strategy':2,
                            'lpp1':0,'lpp2':0}.items():
                self.assertEqual(card[key],val)

    def test_actual_card_parser_and_bad_settings(self):
        with tempfile.TemporaryDirectory() as tmp:
            card=Path(tmp)/'run_card.dat'
            run_card(card)
            self.assertEqual(verify_run_card(card,'mue_NC_HH',CONF)['polbeam1'],0)
            run_card(card,polarization=80)
            with self.assertRaisesRegex(ValueError,'polbeam1'):
                verify_run_card(card,'mue_NC_bbH',CONF)
            run_card(card,lepton_pt=0)
            with self.assertRaisesRegex(ValueError,'ptl'):
                verify_run_card(card,'mue_NC_4b',CONF)

    def test_lab_frame_and_pairing_once(self):
        original=example_particles('fourb')
        lab,dy=lab_particles(original,[-13,11],[2000,120])
        self.assertAlmostEqual(dy,0,delta=1e-9)
        self.assertTrue(select([p.p for p in lab if p.pid==5 and p.status==1],
                               [p.p for p in lab if p.pid==-5 and p.status==1],5,110,130)[0])
        p=math.sqrt(62.5**2-4.7**2)
        passed,npair,_=select([P4(62.5,p,0,0)]*2,[P4(62.5,-p,0,0)]*2)
        self.assertTrue(passed)
        self.assertEqual(npair,2)

    def test_two_body_decay_energy_momentum(self):
        P=P4(300,0,0,math.sqrt(300**2-125**2))
        b,a=scalar_to_bb(P,Random(12),4.7)
        self.assertAlmostEqual((b+a).E,P.E,delta=1e-8)
        self.assertAlmostEqual((b+a).z,P.z,delta=1e-8)
        self.assertAlmostEqual(b.mass,4.7,delta=1e-7)
        self.assertAlmostEqual(a.mass,4.7,delta=1e-7)

    def test_three_modes_and_reporting(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp=Path(tmp);param=tmp/'param.dat';param.write_text(PARAM)
            card=tmp/'run_card.dat';run_card(card)
            br=model_inputs(param)['br_hbb_model']
            (tmp/'reports').mkdir()
            for name in GROUPS:
                mode=COMPONENTS[name]['mode']
                lhe=tmp/(name+'.lhe');write_lhe(lhe,mode)
                r=analyze(lhe,name,param,CONF,decays=100,seed=23,run_card=card)
                self.assertEqual(r['n_events'],12)
                self.assertEqual(r['requested_events'],30000)
                self.assertGreater(r['acceptance'],.90)
                self.assertEqual(r['br_power'],COMPONENTS[name]['br_power'])
                self.assertAlmostEqual(r['branching_factor_applied'],br**r['br_power'])
                self.assertAlmostEqual(r['fiducial_xsec_fb'],10*r['branching_factor_applied']*r['acceptance'])
                self.assertEqual(r['total_trials'],12*(100 if mode in ('hh','bbh') else 1))
                self.assertLessEqual(r['effective_n'],12.0000001)
                self.assertEqual(r['run_card_checks']['ptl'],1)
                (tmp/'reports'/(name+'.json')).write_text(json.dumps(r))
            rows=collect(tmp)
            self.assertEqual(len(rows),4)
            for row,power in zip(rows,[2,1,0,0]):
                self.assertEqual(row['br_power'],power)
                self.assertAlmostEqual(row['sigma_before_bcuts_fb'],10*br**power)
                self.assertTrue(row['status'].endswith('_NOT_CONVERGENCE_VALIDATED'))
                self.assertEqual(row['shortfall_events'],29988)

    def test_fails_wrong_leptons_or_regulator(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp=Path(tmp);p=tmp/'param.dat';p.write_text(PARAM)
            lhe=tmp/'events.lhe';write_lhe(lhe,'hh',n=3)
            conf=copy.deepcopy(CONF)
            conf['scattered_lepton_cuts']['minimum_pt_GeV']=50.
            with self.assertRaisesRegex(ValueError,'lepton violates'):
                analyze(lhe,'mue_NC_HH',p,conf,decays=2)
            with self.assertRaisesRegex(ValueError,'Unexpected final state'):
                analyze(lhe,'mue_NC_bbH',p,CONF,decays=2)
            write_lhe(lhe,'hh',n=3,pid_override=12)
            with self.assertRaisesRegex(ValueError,'Unexpected final state'):
                analyze(lhe,'mue_NC_HH',p,CONF,decays=2)

    def test_collector_refuses_mixed_polarizations(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp=Path(tmp);p=tmp/'param.dat';p.write_text(PARAM)
            (tmp/'reports').mkdir()
            for name in GROUPS[:2]:
                lhe=tmp/(name+'.lhe');write_lhe(lhe,COMPONENTS[name]['mode'])
                r=analyze(lhe,name,p,CONF,decays=2)
                if name==GROUPS[1]:r['beam_polarization_percent']=[80,0]
                (tmp/'reports'/(name+'.json')).write_text(json.dumps(r))
            with self.assertRaisesRegex(ValueError,'polarized'):
                collect(tmp)

    def test_merge_and_handoff_excludes_lhe(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp=Path(tmp);p=tmp/'param.dat';p.write_text(PARAM)
            card=tmp/'run_card.dat';run_card(card)
            runs=[]
            for name in GROUPS:
                run=tmp/('run_'+name);(run/'reports').mkdir(parents=True)
                lhe=run/'unweighted_events.lhe';write_lhe(lhe,COMPONENTS[name]['mode'])
                r=analyze(lhe,name,p,CONF,decays=3,run_card=card)
                (run/'reports'/(name+'.json')).write_text(json.dumps(r))
                runs.append(run)
            merged=tmp/'merged'
            rows=merge(runs,merged)
            self.assertEqual(len(rows),4)
            with self.assertRaisesRegex(ValueError,'existing directory'):
                merge(runs,merged)
            with self.assertRaisesRegex(ValueError,'Duplicate component'):
                merge(runs+[runs[0]],tmp/'duplicated')
            with self.assertRaisesRegex(ValueError,'Missing channels'):
                merge(runs[:2],tmp/'missing')
            archive=pack([merged],tmp/'handoff.zip')
            with ZipFile(archive) as z:
                files=z.namelist()
                self.assertIn('MANIFEST_SHA256.json',files)
                self.assertTrue(any(x.endswith('/results.csv') for x in files))
                self.assertTrue(any(x.endswith('/merge_sources.json') for x in files))
                self.assertFalse(any(x.endswith('.lhe') for x in files))

    def test_preflight_checker_verifies_mg_outputs(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp=Path(tmp)
            name='mue_NC_HH'
            (tmp/'configuration.json').write_text(json.dumps(CONF))
            (tmp/'manifest.json').write_text(json.dumps({'components':[name],
                'execution':{name:'PREPARED_NOT_INTEGRATED'}}))
            (tmp/'logs').mkdir()
            (tmp/'logs'/(name+'_generate.log')).write_text('INFO: Process has 4 diagrams\n')
            (tmp/'cards').mkdir()
            (tmp/'cards'/(name+'.mg5')).write_text(card_text(name))
            proc=tmp/name
            (proc/'Cards').mkdir(parents=True)
            param=proc/'Cards'/'param_card.dat';param.write_text(PARAM)
            card=proc/'Cards'/'run_card.dat';run_card(card)
            (proc/'configuration_audit.json').write_text(json.dumps({
                'component':name,'model_inputs':model_inputs(param)}))
            self.assertEqual(inspect_run(tmp)[name]['Hbb_branch_power'],2)
            run_card(card,polarization=80)
            with self.assertRaisesRegex(ValueError,'polbeam1'):
                inspect_run(tmp)

    def test_cut_registry_neutralizer(self):
        class Fake(dict):
            cuts_parameter=['ptb','ptl','mmbb','etaj','drjj','dparameter']
        f=Fake(ptb=20.,ptl=10.,mmbb=25.,etaj=5.,drjj=.4,dparameter=.4)
        changes=neutralize_registered_cuts(f)
        self.assertEqual(f['ptb'],0.)
        self.assertEqual(f['ptl'],0.)
        self.assertEqual(f['etaj'],-1)
        self.assertEqual(f['dparameter'],.4)
        self.assertIn('ptl',changes)

if __name__=='__main__':unittest.main()
