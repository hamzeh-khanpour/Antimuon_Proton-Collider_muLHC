# CERN compatibility hotfix v1.1.0 — `ptl` optional in real MG5 3.6.4 cards

## Observed live CERN failure
`python3 scan.py prepare --mg5 "$BASE/bin/mg5_aMC" --process all` stopped on first `CC_H`: `RuntimeError: CC_H critical run-card fields missing {'ptl'}`.

## Correction
Real MG5 v3.6.4 emits process-dependent `run_card.dat`: CC H has final neutrinos and can omit the lepton transverse-momentum cut `ptl`. The tool now allows `ptl` to be absent. If present, it MUST be reset to 0 and audited. Absent `ptl` is recorded, not fabricated. Mandatory keys `ebeam1`, `ebeam2`, `lpp1`, `lpp2`, `polbeam1`, `polbeam2`, `nevents`, and `iseed` remain strictly enforced. Other existing cuts are still disabled and audited. No physics process, beam energy, or polarization setup was altered.

## Regression tests
Mock-MG5 CC templates now omit `ptl`, while NC mock templates retain it. Both full process preparation and 8 pilot workers are tested. Self-tests cover present and absent `ptl`, and missing mandatory polarization fields.

## On CERN (after uploading full ZIP)
```
BASE=/eos/user/h/hakhanpo/MG5_aMC_v3_6_4
PKG="$BASE/FCCmue_Higgs_PolScan_v1_1_CERN_PTL_FIX"
cd "$BASE"
unzip -tq FCCmue_Higgs_PolScan_v1_1_CERN_PTL_FIX.zip
unzip -n FCCmue_Higgs_PolScan_v1_1_CERN_PTL_FIX.zip
cd "$PKG"
sha256sum -c SHA256SUMS.txt
python3 scan.py self-test
python3 tests/test_workflow.py
python3 scan.py prepare --mg5 "$BASE/bin/mg5_aMC" --process all
python3 scan.py doctor
```
Only submit the pilot after all four templates are marked READY. Do not run 48 production jobs on LXPLUS login nodes.
