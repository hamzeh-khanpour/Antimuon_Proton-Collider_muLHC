# FCC-mue inclusive Higgs polarization scan — CERN package v1.1.0

**HOTFIX v1.1:** Corrected compatibility with actual MG5 3.6.4 cards that omit the optional `ptl` key for charged-current neutrino final states. Active `ptl` is still zeroed and verified. Critical beam/polarization fields remain mandatory. See HOTFIX_NOTES.md.

**Purpose:** Reproducible MadGraph5_aMC@NLO 3.6.4 LO scan for Richard Ruiz / Krzysztof Piotrzkowski: four exact Standard-Model tree-level final states, two electron/muon beam setups, six positive-muon polarizations, **no kinematic phase-space cuts**. Higgs bosons are stable; no decay branching fractions. 4 x 2 x 6 = **48 independent full-production jobs**. Run on CERN HTCondor workers, NOT on shared LXPLUS login nodes.

## Four separate processes (full coherent tree-level amplitudes)

| ID | Physical channel | Exact MadGraph generate command |
|----|------------------|---------------------------------|
| `CC_H` | charged current, single Higgs | `generate e- mu+ > ve vm~ h QCD=0` |
| `CC_HH` | charged current, double Higgs | `generate e- mu+ > ve vm~ h h QCD=0` |
| `NC_H` | neutral current, single Higgs | `generate e- mu+ > e- mu+ h QCD=0` |
| `NC_HH` | neutral current, double Higgs | `generate e- mu+ > e- mu+ h h QCD=0` |

**Naming caveat:** `CC` and `NC` describe final states; the generator calculates all tree-level SM diagrams for each specified final state. `QCD=0` excludes QCD vertices, not electroweak interference. No VBF-approximation / diagram cuts and no `add process` combination.

## CRITICAL: beam ordering and centre-of-mass energies

The process ordering is `e- mu+`, which means **beam 1 is the electron, beam 2 is the positive muon**. At every point: `polbeam1=0`, `polbeam2=P(mu+)` in **percent**, from 0 through +100.

**Default `--preset exact` (exact 1 and 2 TeV)**:

| Label | E(e-) GeV = `ebeam1` | E(mu+) GeV = `ebeam2` | sqrt(s) GeV |
|:---|---:|---:|---:|
| `E1` | 125 | 2000 | 1000 |
| `E2` | 200 | 5000 | 2000 |

**Alternative `--preset fcc_design`** matches the earlier beam configurations used in the FCC-mue project:

| Label | E(e-) GeV | E(mu+) GeV | Actual sqrt(s) GeV |
|:---|---:|---:|---:|
| `E1` | 120 | 2000 | 979.795897 |
| `E2` | 183 | 5000 | 1913.112647 |

**These are different scenarios!** Do not call 120 x 2000 or 183 x 5000 "exactly 1/2 TeV". The package generates unique result names containing the preset to avoid mixing them. The `sm` model has massless e and mu in its default restriction; `sqrt(s)=sqrt(4E_e E_mu)`.

### Polarization scan

`P(mu+) = [0, 20, 40, 60, 80, 100] %`. Charged-current sanity prediction is `sigma_CC(P) / sigma_CC(0) = 1 + P/100` in the ultrarelativistic SM at unpolarized e-. NC dependence is linear but the slope must be measured. Ratios from real generated samples and integration errors are recorded by `collect`. Full production uses 30,000 events per job by default; pilot uses 1,000.

## Installation on CERN

Read [COMMANDS_WINDOWS_POWERSHELL.txt](COMMANDS_WINDOWS_POWERSHELL.txt), then [COMMANDS_CERN_LXPLUS_COPY_PASTE.txt](COMMANDS_CERN_LXPLUS_COPY_PASTE.txt). The only external application required for production is an existing working CERN installation of MG5 3.6.4, and `condor_submit` on LXPLUS. The output workers use system `python3`, `gcc`, `gfortran` and normal MadEvent. Matplotlib is optional for figures (it is **not** required to run any physics jobs).

1. Transfer ZIP using Windows PowerShell SCP to `/eos/user/h/hakhanpo/MG5_aMC_v3_6_4/`.
2. Unzip and verify SHA256 checksums; run `python3 scan.py self-test` and `python3 scan.py doctor`.
3. Generate **four process templates only** with `python3 scan.py prepare --mg5 "$BASE/bin/mg5_aMC"`. Process generation/short prep is permitted on login; event integration is not launched here. Each template archive is self-contained and is transferred to the batch worker.
4. Generate and submit an **8-job pilot** (all four channels at both energies, only unpolarized) using `python3 scan.py submit-file --mode pilot --preset exact --energy both` followed by `condor_submit submissions/pilot_exact_both.sub`.
5. Check `condor_q`, `condor_logs/`, and returned `results/pilot_exact_*.tar.gz`. Run `python3 scan.py collect --mode pilot --preset exact --energy both`. Confirm 8/8 completion and examine `reports/quality_checks.json`.
6. Generate and submit **48 final jobs** using `python3 scan.py submit-file --mode full --preset exact --energy both` and `condor_submit submissions/full_exact_both.sub`. The batch file uses `max_materialize=8` and one CPU per job. This can instead be split into two 24-job submissions (`--energy E1` and `--energy E2`) from your two terminal windows.
7. Once all jobs end: `python3 scan.py collect --mode full --preset exact --energy both`, then (if matplotlib available) `python3 plot_results.py --preset exact --energy both`. Use `python3 make_review_zip.py --mode full --preset exact` for a small audit archive; add `--include-lhe` ONLY if the full event files are needed.

**Never run `run_all.sh` from the earlier 4b package for these four inclusive processes.** This package has a separate workflow.

## What the worker does and checks

Each HTCondor worker receives the corresponding archived process template and separate Python analysis scripts. It extracts to allocated scratch, sets `ebeam1`, `ebeam2`, `polbeam1=0`, `polbeam2=P`, `lpp1=lpp2=0`, 30k events, unique seed, and enforces `ptl=0` when present (if MG5 omits `ptl`, its absence is audited), jet/photon/b cuts off, no lepton-eta/jet-eta bound, and no invariant-mass/DR minimum. It also disables automatic MadAnalysis5 PDF production and configures MadEvent sequential execution (`run_mode=0`, `nb_core=1`) to respect the allocated one core.

After generation, it independently parses the LHE `<init>` cross section and integration error, checks e- and mu+ beam PDGs and energies, expected final states, `IDWTUP=3` or the CERN-realistic `IDWTUP=-4` convention, positive unweighted event weights, number of events, and reports all results in **fb**. On error, it keeps diagnostics and reports a failed job. For successful jobs it marks `COMPLETED_UNVALIDATED` until physics-level convergence checks are performed.

Each returned `results/<job_id>.tar.gz` contains the JSON result, cards, logs, and original `.lhe.gz` event sample (if generated). No simulation result is invented, and the **mock MadGraph scripts are test-only** under `tests/`.

## Scientific limitations / must-do validation

- "No cuts" means no kinematic generator cuts. It does **not** imply the NC full matrix-element integral is always numerically stable: particularly forward configurations and possible photon exchange should be inspected in convergence diagnostics. This package does not impose a stealth regulator or replace the full matrix element with a VBF approximation.
- For `sm/restrict_default`, e and mu masses/yukawas are zero. This affects possible radiation diagrams and the treatment of strictly forward collinear regions. Changing the model changes the physics and requires separate labeled results.
- `QCD=0` tree-level calculations omit QED ISR, electroweak radiative corrections, beamstrahlung, detector response, Higgs decays, and polarization effects on luminosity. Renormalization scale is fixed to 125 GeV to keep numerical settings consistent. No theory/systematic uncertainty estimate is provided.
- A finite MadGraph integration error is **not enough to certify convergence**; repeat selected high-risk channels at fresh independent seeds and inspect integration stability.
- 100% polarization is an idealized endpoint and may require special accelerator feasibility considerations; it is included to test the linearity and determine the pure-helicity limit.
- Distinguish particle helicity conventions from chirality: for a positive muon the charged-current-enhanced helicity state corresponds to the positive/right-handed antimuon in the high-energy limit.

## Output files

| File | Description |
|---|---|
| `templates/{CC_H,CC_HH,NC_H,NC_HH}.tar.gz` | real MG process templates created on CERN (`prepare`) |
| `submissions/{pilot,full}_<preset>_<energy>.sub` | generated HTCondor submit descriptions |
| `results/<job_id>.tar.gz` | complete per-job result package from CERN worker |
| `condor_logs/*` | scheduler, stderr and stdout logs |
| `reports/cross_sections.csv` | measured sigma, error, P, process and sqrt(s) |
| `reports/quality_checks.json` | missing/failed jobs and CC ratio checks |
| `reports/all_results.json` | typed per-job reports |
| `reports/FCCmue_<preset>_{absolute,ratio}.{png,pdf}` | data-driven 4-panel plots (when matplotlib installed) |

No numeric FCC-mue inclusive Higgs cross sections are supplied in this source ZIP, because real MG5 production has not yet been performed for this scan.
