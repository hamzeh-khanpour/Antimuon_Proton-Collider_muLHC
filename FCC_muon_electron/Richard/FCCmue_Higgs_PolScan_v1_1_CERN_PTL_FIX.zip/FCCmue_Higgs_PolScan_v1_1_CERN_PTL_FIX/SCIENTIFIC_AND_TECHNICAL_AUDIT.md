# Physics audit and software scope

**Date:** 2026-11-02. **Tool:** MadGraph5_aMC@NLO 3.6.4 LO event generation at CERN. **Authoring package:** version 1.1.0. This is an executable CERN workflow, **not** a claim that new inclusive FCC-mue cross sections have already been computed.

### 1. Four explicit Standard Model amplitudes

The user and Richard Ruiz specified: `e- mu+ > ve vm~ h`, `e- mu+ > ve vm~ h h`, `e- mu+ > e- mu+ h`, `e- mu+ > e- mu+ h h`, all with `QCD=0`. The generated process card for each is recorded and later checked against these exact strings. `add process` is deliberately not used: each required physical final state has its own rate and statistical error. All electroweak diagrams for that final state are included at the chosen tree-level order; no diagram removal or forced on-shell W/Z intermediate states.

### 2. Beam convention and high-energy geometry

`e-` is initial beam #1, `mu+` is #2. The source scripts set beam one `lpp1=0, polbeam1=0`; beam two `lpp2=0, polbeam2=0,20,40,60,80,100`. Both are monochromatic lepton beams (no PDFs), without ISR or beamstrahlung. This is not an electron polarization scan. `sm` defaults (restrict_default) use massless incoming e and mu; hence sqrt(s) = sqrt(4 E_e E_mu). Exact-energy preset 125 x 2000 and 200 x 5000 GeV yields exactly 1/2 TeV, while prior CERN machine benchmarks 120 x 2000 and 183 x 5000 give 979.795897 and 1913.112647 GeV. Presets must never be merged.

### 3. Polarization sanity identities

For an unpolarized electron and a +muon polarized beam, the generic decomposition is sigma(P) = [(1+P)/2] sigma_R + [(1-P)/2] sigma_L (P dimensionless in [-1,1]). The Standard Model CC rate has sigma_L approximately zero (helicity-flip mass effects neglected) and sigma_CC(P)/sigma_CC(0) = 1+P at both energies, separately for H and HH. The NC rate also varies linearly in P but should be fitted or calculated using both helicity components; a CC slope must not be imposed on the NC rate. The code measures the ratios rather than manufacturing absolute predictions.

### 4. No cuts: details and caveats

MG5 run_card.dat frequently defaults to `ptl = 1 GeV` even when users assume there are no lepton cuts. This package explicitly overrides active pTl/jet/other pT minima, DR, invariant-mass and eta constraints and audits resulting active values. All kinematic cuts present in the generated version-specific card are checked after replacement; absent optional keys are not fabricated. `cut_decays=False`, `xqcut=0` and `gridpack=False` if present. Any critical missing key (`ebeam1`, `ebeam2`, `polbeam1`, `polbeam2`, `nevents`, `iseed`, `lpp1`, `lpp2`) fails closed.

**NO GEN-LEVEL MASS OR ANGULAR REGULATOR** is introduced. If a full NC amplitude is forward divergent/unstable, a legitimate regulated study would require a separately agreed phase-space definition or more appropriate mass/regulator physics. Such a result must not silently be labeled “no cuts.”

### 5. Numerical protocol

Four standalone MadEvent templates, copied by CERN HTCondor per job to scratch with `should_transfer_files=YES`; 1 core requested and enforced via run_mode=0; the declared process and parameter cards are preserved in result archives; no physics integration is performed by process `prepare`. Unique seeds per independent job. Initially an eight-point zero-polarization pilot (1k events), then the full 48-point scan (30k events). Event statistics are not cross-section integration convergence certifications. Repeat selected runs with separate seeds and compare especially NC_HH.

### 6. LHE integrity and unit handling

Require LHE init block incoming PDGs `(11,-13)`, matching e/mu beam energies, exactly one process, finite positive XSECUP in pb, nonnegative integration uncertainty and valid event samples. Check final state on first twenty events and every thousandth event. Accept the MadGraph `IDWTUP=-4` constant-positive-weight convention (XWGTUP~XSECUP) and `IDWTUP=3` unit-weight convention; reject other formats, nonfinite weights, wrong final-state IDs and wrong beam energies. Multiply cross sections and integration uncertainties by **1000** to report fb. Do not multiply by any Higgs decay branching fraction. Store `COMPLETED_UNVALIDATED`, and report missing/broken jobs explicitly. No absolute cross sections are hard-coded in the physics package.

### 7. Provenance and reference checks

The package includes a test-only mock generator, archived card fixtures from CERN MadGraph 3.6.4, and a separate end-to-end test. The mock's arbitrary rates are strictly limited to tests and MUST NOT be interpreted as predictions. On CERN, check the generated diagram process counts and the actual log/cross-section outputs.

For operator guidance see CERN [batch documentation](https://batchdocs.web.cern.ch/) and the [HTCondor submit manual](https://htcondor.readthedocs.io/en/main/users-manual/submitting-a-job.html). For physical process syntax and particle IDs consult the official MadGraph [input examples](https://cp3.irmp.ucl.ac.be/projects/madgraph/wiki/InputEx).

### v1.1 compatibility correction
MG5 3.6.4 can tailor the generated card to a CC final state with neutrinos and omit `ptl`. It is not a missing required field; an absent cut parameter is recorded as optional. If an active `ptl` field is present (especially NC charged-lepton final states), it is set to 0.0 and verified. Beam PDGs, energies, polarizations, seeds and event count remain fail-closed. Real CERN prepare and integration remain to be confirmed.
