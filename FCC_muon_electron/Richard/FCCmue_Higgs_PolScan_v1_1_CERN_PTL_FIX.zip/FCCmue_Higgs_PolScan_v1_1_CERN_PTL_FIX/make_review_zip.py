#!/usr/bin/env python3
"""Build compact CERN review bundle; never conflate physics results with mock tests."""
import argparse
import datetime
import io
import json
from pathlib import Path
import tarfile
import zipfile

ROOT=Path(__file__).resolve().parent


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--mode',choices=['full','pilot'],default='full')
    ap.add_argument('--preset',choices=['exact','fcc_design'],default='exact')
    ap.add_argument('--include-lhe',action='store_true',help='Include full event samples: archive can become large')
    args=ap.parse_args()
    fn=ROOT/f'FCCmue_Higgs_PolScan_{args.mode}_{args.preset}_REVIEW.zip'
    if fn.exists():raise SystemExit('Refusing overwrite: '+str(fn))
    files=['CONFIG.json','README_FIRST.md','SCIENTIFIC_AND_TECHNICAL_AUDIT.md','scan.py','card_utils.py',
           'plot_results.py','reports/cross_sections.csv','reports/quality_checks.json','reports/all_results.json']
    files += [str(p.relative_to(ROOT)) for p in (ROOT/'reports').glob('*.pdf')]
    files += [str(p.relative_to(ROOT)) for p in (ROOT/'reports').glob('*.png')]
    paths=sorted((ROOT/'results').glob(f'{args.mode}_{args.preset}_*.tar.gz'))
    manifest={'date_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'mode':args.mode,'preset':args.preset,'job_archives':[],
              'full_event_samples_included':args.include_lhe}
    with zipfile.ZipFile(fn,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
        for rel in files:
            path=ROOT/rel
            if path.is_file():z.write(path,arcname=rel)
        for item in paths:
            with tarfile.open(item,'r:gz') as t:
                r=json.loads(t.extractfile('result.json').read())
                manifest['job_archives'].append({'name':item.name,'status':r.get('status')})
                for m in t.getmembers():
                    if not m.isfile():continue
                    if m.name.startswith('process/Events/') and not args.include_lhe:
                        continue
                    data=t.extractfile(m).read()
                    rel=f'jobs/{item.stem.removesuffix(".tar")}/{m.name}'
                    z.writestr(rel,data,compress_type=zipfile.ZIP_STORED if m.name.endswith('.gz') else zipfile.ZIP_DEFLATED)
        z.writestr('REVIEW_MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
    with zipfile.ZipFile(fn) as z:
        if z.testzip():raise RuntimeError('Archive integrity failed')
    print('REVIEW ZIP:',fn)
    print('JOB ARCHIVES:',len(paths))
    print('SIZE MB:',round(fn.stat().st_size/1e6,3))
    print('Full LHE content:',args.include_lhe)

if __name__=='__main__':main()
