#!/usr/bin/env python3
"""FCC-mue inclusive Higgs polarization scan. Python standard library only."""
import argparse
import collections
import csv
import gzip
import hashlib
import io
import json
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import traceback

ROOT=Path(__file__).resolve().parent
CONFIG=json.loads((ROOT/'CONFIG.json').read_text())
PROCS=CONFIG['processes']
POLS=CONFIG['polarization_percent']
ENERGIES=('E1','E2')


def dump(obj,path):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    Path(path).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')


def energy_config(preset, eid):
    row=CONFIG['beam_presets'][preset][eid]
    e1=float(row['electron_GeV']);e2=float(row['muplus_GeV'])
    # The MG5 `sm` benchmark uses massless e and mu in restrict_default,
    # so its exact generator invariant energy is sqrt(4*E_e*E_mu).
    sqs=2*math.sqrt(e1*e2)
    return dict(row,energy_id=eid,sqrt_s_GeV=sqs)


def create_process_cards(proc_id, output):
    if proc_id not in PROCS:raise ValueError(proc_id)
    text='\n'.join(['set automatic_html_opening False',
                    'set group_subprocesses False','import model sm',
                    PROCS[proc_id]['generate'],
                    'output '+str(output), 'quit'])+'\n'
    return text


def prepare(args):
    mg5=Path(args.mg5).expanduser().resolve()
    if not (mg5.is_file() and os.access(mg5,os.X_OK)):
        raise ValueError('MadGraph executable not found: '+str(mg5))
    targets=list(PROCS) if args.process=='all' else [args.process]
    archive_dir=ROOT/'templates';archive_dir.mkdir(exist_ok=True)
    for proc_id in targets:
        out=archive_dir/(proc_id+'.tar.gz')
        if out.exists() and not args.force:
            print('EXISTS - preserving',out,'(use --force only if regeneration required)')
            continue
        with tempfile.TemporaryDirectory(prefix='prepare_'+proc_id+'_',dir=str(archive_dir)) as tmp:
            td=Path(tmp)
            proc=td/'process'
            card=td/'process.mg5'
            card.write_text(create_process_cards(proc_id,proc))
            print('PREPARING',proc_id,'with',mg5,flush=True)
            with (td/'mg5_generation.log').open('w') as log:
                p=subprocess.run([str(mg5),str(card)],cwd=td,stdout=log,stderr=subprocess.STDOUT)
            if p.returncode:
                print((td/'mg5_generation.log').read_text()[-7000:])
                raise RuntimeError(proc_id+' MG5 generation failed; log above')
            if not (proc/'bin/generate_events').is_file():
                raise RuntimeError(proc_id+' missing generate_events after MG5 output')
            rc=proc/'Cards/run_card.dat'
            pc=proc/'Cards/param_card.dat'
            if not rc.is_file() or not pc.is_file():
                raise RuntimeError(proc_id+' generated run/param card missing')
            import card_utils
            parsed=card_utils.parse(rc.read_text())
            missing=set(card_utils.REQUIRED)-set(parsed)
            if missing:raise RuntimeError(proc_id+' critical run-card fields missing '+str(missing))
            # MG5 3.6.4 omits ptl for CC neutrino final states.  It is
            # optional: if present, configure() sets it to 0.0 and audits it.
            # Do not fabricate a missing card key.
            if 'ptl' not in parsed:
                print('INFO:',proc_id,'run card omits optional ptl (no active ptl cut)',flush=True)
            spectrum=card_utils.inspect_spectrum(pc)
            generate=PROCS[proc_id]['generate']
            generated_proc=proc/'Cards/proc_card_mg5.dat'
            if generated_proc.is_file() and generate not in generated_proc.read_text():
                raise RuntimeError('Generated process does not match requested: '+proc_id)
            # Remove explicit modes that trigger automatic analyses. The full
            # event sample is retained as a separate product of the worker.
            audit={'process_id':proc_id,'command':generate,'model':'sm',
                   'spectrum':spectrum,'mg5_executable':str(mg5),
                   'generated_run_card_keys':sorted(parsed),
                   'note':'Full SM tree-level process, stable Higgs; no cuts applied at generation.'}
            dump(audit,proc/'FCCMUE_TEMPLATE_AUDIT.json')
            shutil.copy2(td/'mg5_generation.log',proc/'FCCMUE_MG5_GENERATION.log')
            new=td/'archive.tmp.tar.gz'
            with tarfile.open(new,'w:gz') as z:
                z.add(proc,arcname='process')
            if out.exists():out.unlink()
            shutil.move(new,out)
            print('READY:',out,'size MB:',round(out.stat().st_size/1e6,3))
    print('Preparation finished; DO NOT confuse process preparation with event production.')


def jobs(mode,preset,energy):
    if mode not in ('pilot','full'):raise ValueError(mode)
    if preset not in CONFIG['beam_presets']:raise ValueError(preset)
    targets=list(ENERGIES) if energy=='both' else [energy]
    ps=[0] if mode=='pilot' else POLS
    all_jobs=[]
    for eid in targets:
        for ip,proc in enumerate(PROCS):
            for pol in ps:
                serial=POLS.index(pol)
                # Deterministic and unique; pilot and full seeds differ.
                seed=32000000 + (0 if mode=='pilot' else 1000000)+ (0 if eid=='E1' else 100000) + ip*10000 + serial*100 + 37
                job_id=f'{mode}_{preset}_{eid}_{proc}_P{pol:03d}'
                all_jobs.append(dict(job_id=job_id,proc_id=proc,energy_id=eid,
                     polarization=pol,seed=seed,archive='templates/'+proc+'.tar.gz',
                     nevents=CONFIG['pilot_events'] if mode=='pilot' else CONFIG['full_events'],
                     preset=preset))
    return all_jobs


def submit(args):
    js=jobs(args.mode,args.preset,args.energy)
    missing=sorted({j['archive'] for j in js if not (ROOT/j['archive']).is_file()})
    if missing:raise FileNotFoundError('Run prepare first. Missing template archive(s): '+str(missing))
    dest=ROOT/'submissions'; dest.mkdir(exist_ok=True)
    (ROOT/'results').mkdir(exist_ok=True)
    (ROOT/'condor_logs').mkdir(exist_ok=True)
    tag=f'{args.mode}_{args.preset}_{args.energy}'
    listpath=dest/(tag+'.txt')
    with listpath.open('w') as f:
        for j in js:
            f.write(' '.join(str(j[k]) for k in ('job_id','proc_id','energy_id','polarization','seed','archive','nevents','preset'))+'\n')
    cc=CONFIG['condor']
    submitpath=dest/(tag+'.sub')
    submittext=f'''# Generated by scan.py; submit from PACKAGE ROOT (commands below).
universe = vanilla
executable = worker.sh
arguments = $(job_id) $(proc_id) $(energy_id) $(pol) $(seed) $(archive) $(nevents) $(preset)
should_transfer_files = YES
when_to_transfer_output = ON_EXIT
transfer_input_files = $(archive),scan.py,card_utils.py,CONFIG.json
transfer_output_files = job_output.tar.gz
transfer_output_remaps = "job_output.tar.gz=results/$(job_id).tar.gz"
output = condor_logs/$(job_id).$(Cluster).out
error = condor_logs/$(job_id).$(Cluster).err
log = condor_logs/$(job_id).$(Cluster).log
request_cpus = {cc['cpus']}
request_memory = {cc['memory']}
request_disk = {cc['disk']}
+JobFlavour = "{cc['job_flavour']}"
max_materialize = {cc['max_materialize']}
queue job_id,proc_id,energy_id,pol,seed,archive,nevents,preset from {listpath.relative_to(ROOT)}
'''
    submitpath.write_text(submittext)
    print('JOB COUNT:',len(js))
    print('SUBMIT FILE:',submitpath)
    print('PREVIEW:',[(j['job_id'],j['seed']) for j in js[:4]])
    print('From the package directory run: condor_submit '+str(submitpath.relative_to(ROOT)))
    print('This command GENERATES a submit file ONLY; it does not submit jobs.')


def _configure_madevent(path):
    # MG uses key=value config unlike the value=key run-card format.
    cfg=Path(path)/'Cards/me5_configuration.txt'
    text=cfg.read_text() if cfg.exists() else ''
    preserved=[]
    for line in text.splitlines():
        if re.match(r'^\s*(?:run_mode|nb_core|automatic_html_opening)\s*=',line):
            continue
        preserved.append(line)
    preserved+=['run_mode = 0','nb_core = 1','automatic_html_opening = False']
    cfg.write_text('\n'.join(preserved)+'\n')


def _read_lhe(path,proc_id,energy,pol,requested):
    """Validate inclusive LO LHE init block and complete event count."""
    expected_final=collections.Counter(CONFIG['processes'][proc_id]['final_pdgs'])
    n=0
    weights=[]
    init=[]
    inside_init=False
    inside_event=False
    event_lines=[]
    fileopen=gzip.open if str(path).endswith('.gz') else open
    with fileopen(path,'rt',errors='replace') as f:
        for line in f:
            st=line.strip()
            if st.startswith('<init>'):
                inside_init=True
                continue
            if st.startswith('</init>'):
                inside_init=False
                continue
            if inside_init:
                if st and not st.startswith('#') and not st.startswith('<'):
                    init.append(st.split('#',1)[0].split())
            if st.startswith('<event>'):
                inside_event=True
                event_lines=[]
                continue
            if st.startswith('</event>'):
                inside_event=False
                if not event_lines:raise ValueError('empty LHE event')
                h=event_lines[0]
                if len(h)<3:raise ValueError('truncated LHE event header')
                w=float(h[2].replace('D','E'))
                if not math.isfinite(w) or w<0:raise ValueError('non-finite/negative LO event weight')
                weights.append(w)
                if len(event_lines)<int(h[0])+1:
                    raise ValueError('truncated LHE event particles')
                if n < 20 or n%1000==0:
                    final=collections.Counter(int(r[0]) for r in event_lines[1:int(h[0])+1] if int(r[1])==1)
                    if final!=expected_final:
                        raise ValueError(f'{proc_id} final-state PDGs mismatch: {final} expected {expected_final}')
                n+=1
                continue
            if inside_event and st and not st.startswith('#') and not st.startswith('<'):
                event_lines.append(st.split())
    if len(init)<2:raise ValueError('missing LHE init or subprocess cross section')
    h=init[0]
    if len(h)<10:raise ValueError('bad LHE init header')
    pid1,pid2=int(h[0]),int(h[1])
    e1,e2=float(h[2]),float(h[3])
    idwtup,nprup=int(h[8]),int(h[9])
    if (pid1,pid2)!=(11,-13):
        raise ValueError(f'Wrong incoming beam PDGs: {(pid1,pid2)}; expected e- mu+')
    if not (math.isclose(e1,energy['electron_GeV'],abs_tol=1e-6) and math.isclose(e2,energy['muplus_GeV'],abs_tol=1e-6)):
        raise ValueError(f'Beam energy mismatch {(e1,e2)} expected {energy}')
    if nprup!=1 or len(init)!=2:
        raise ValueError('Expected precisely one LHE subprocess; got '+str((nprup,len(init)-1)))
    xsec,err,xmax,lpr=map(float,init[1][:4])
    if not all(math.isfinite(x) for x in (xsec,err,xmax)) or xsec<=0 or err<0:
        raise ValueError('Invalid or nonpositive LHE cross section or error')
    if idwtup not in (-4,3):
        raise ValueError('Unexpected LO unweighting convention IDWTUP='+str(idwtup))
    if n<=0:raise ValueError('No events')
    if idwtup==-4:
        if any(not math.isclose(w,xsec,rel_tol=.005,abs_tol=1e-11) for w in weights):
            raise ValueError('IDWTUP=-4 LO weights not constant XSECUP; refusing silent misnormalization')
        weight_scheme='IDWTUP=-4 constant positive XWGTUP~XSECUP'
    else:
        if any(not math.isclose(w,1.0,rel_tol=1e-6,abs_tol=1e-8) for w in weights):
            raise ValueError('IDWTUP=3 unweighted sample not unit-weight')
        weight_scheme='IDWTUP=3 constant unit-weight'
    return {'sigma_pb':xsec,'sigma_fb':1000*xsec,'sigma_mc_err_pb':err,
            'sigma_mc_err_fb':1000*err,'n_events':n,'requested_events':requested,
            'shortfall':requested-n,'idwtup':idwtup,'weight_scheme':weight_scheme,
            'beam_ids':[pid1,pid2], 'beam_energies_GeV':[e1,e2],
            'validated_final_state':dict(expected_final),'subprocess_id':int(lpr)}


def _archive_output(root,dest):
    """Archive structured results + cards + logs + LHE; exclude compiled bulk."""
    root=Path(root)
    includes=['result.json','exception.txt','run.log','run_card_audit.json',
              'process/Cards/run_card.dat','process/Cards/param_card.dat',
              'process/Cards/proc_card_mg5.dat',
              'process/Events/run_01/unweighted_events.lhe.gz',
              'process/Events/run_01/unweighted_events.lhe']
    with tarfile.open(dest,'w:gz') as tar:
        for rel in includes:
            p=root/rel
            if p.is_file():tar.add(p,arcname=rel)
        eventpath=root/'process/Events/run_01'
        if eventpath.is_dir():
            for p in eventpath.glob('*.log'):
                tar.add(p,arcname=str(p.relative_to(root)))
            for p in eventpath.glob('*banner.txt'):
                tar.add(p,arcname=str(p.relative_to(root)))


def worker(args):
    root=Path.cwd()
    template=root/Path(args.archive).name
    record={'job_id':args.job_id,'process_id':args.proc_id,
            'energy_id':args.energy_id,'polarization_percent':args.pol,
            'seed':args.seed,'requested_events':args.nevents,
            'preset':args.preset,'status':'FAILED'}
    error=None
    try:
        expected_job=f'{args.mode}_{args.preset}_{args.energy_id}_{args.proc_id}_P{args.pol:03d}'
        if args.job_id!=expected_job:raise ValueError('job id does not match parameters: '+expected_job)
        if args.proc_id not in PROCS or args.pol not in POLS:raise ValueError('invalid process or pol')
        if not template.is_file():raise FileNotFoundError('missing transferred template '+str(template))
        with tarfile.open(template,'r:gz') as t:
            members=t.getmembers()
            for member in members:
                p=Path(member.name)
                if not member.name.startswith('process/') and member.name!='process':
                    raise ValueError('unsafe template name: '+member.name)
                if member.issym() or member.islnk():
                    import posixpath
                    # MG5 may create legitimate *internal* relative symlinks.
                    # Permit only links that resolve within the process tree.
                    target=posixpath.normpath(posixpath.join(posixpath.dirname(member.name),member.linkname) if member.issym() else member.linkname)
                    if not (target=='process' or target.startswith('process/')):
                        raise ValueError('template contains unsafe/outside symlink: '+member.name+' -> '+member.linkname)
                if '..' in p.parts or p.is_absolute():raise ValueError('unsafe template member')
            t.extractall(path=root)
        proc=root/'process'
        from card_utils import configure,inspect_spectrum
        ec=energy_config(args.preset,args.energy_id)
        card_audit=configure(proc/'Cards/run_card.dat', ec['electron_GeV'], ec['muplus_GeV'],
                             args.pol,args.nevents,args.seed,CONFIG['fixed_ren_scale_GeV'])
        card_audit['model']=inspect_spectrum(proc/'Cards/param_card.dat')
        card_audit['beam_preset']=ec
        card_audit['process_command']=PROCS[args.proc_id]['generate']
        dump(card_audit,root/'run_card_audit.json')
        _configure_madevent(proc)
        for p in (proc/'Cards').glob('madanalysis5_*card.dat'):
            p.unlink()  # no MadAnalysis5 PDF production in headless worker
        log=root/'run.log'
        with log.open('w') as f:
            ret=subprocess.run([sys.executable,str(proc/'bin/generate_events'),'-f'],
                       cwd=proc,stdout=f,stderr=subprocess.STDOUT)
        if ret.returncode!=0:
            raise RuntimeError('MadEvent returned '+str(ret.returncode)+'; inspect run.log')
        lhe=list((proc/'Events').glob('run_*/unweighted_events.lhe.gz'))
        if not lhe:lhe=list((proc/'Events').glob('run_*/unweighted_events.lhe'))
        if len(lhe)!=1:raise RuntimeError('Expected one final LHE file; found '+str(lhe))
        analyzed=_read_lhe(lhe[0],args.proc_id,ec,args.pol,args.nevents)
        record.update(analyzed)
        record.update({'status':'COMPLETED_UNVALIDATED' if analyzed['shortfall']==0 else 'INCOMPLETE_EVENTS',
                    'beam_config':ec,'sqrts_GeV':ec['sqrt_s_GeV'],
                    'interpretation':'LO uncut full tree-level final state, no Higgs branching factors',
                    'warnings':['Integration convergence / forward-region stability not independently validated',
                                'Photon/collinear sensitivity of NC amplitudes should be checked',
                                'Stable Higgs bosons, no ISR/beamstrahlung/shower/detector']})
        if analyzed['shortfall']:
            raise RuntimeError('MadGraph event shortfall '+str(analyzed['shortfall']))
        print('SUCCESS',record['job_id'], 'sigma_fb=',record['sigma_fb'])
    except Exception as exc:
        error=str(exc)
        record['status']='FAILED'
        record['error']=error
        (root/'exception.txt').write_text(traceback.format_exc())
        print('FAILED:',args.job_id,error,file=sys.stderr)
    finally:
        dump(record,root/'result.json')
        _archive_output(root,root/'job_output.tar.gz')
    if error:sys.exit(1)


def collect(args):
    rsdir=ROOT/'results'
    archive_list=sorted(rsdir.glob('*.tar.gz'))
    records=[]
    bad_archives=[]
    for archive in archive_list:
        try:
            with tarfile.open(archive,'r:gz') as t:
                f=t.extractfile('result.json')
                if f is None:raise ValueError('missing result.json')
                item=json.loads(f.read())
            if archive.name!=item['job_id']+'.tar.gz':
                raise ValueError('archive/job ID mismatch')
            records.append(item)
        except Exception as ex:bad_archives.append([archive.name,str(ex)])
    records=sorted(records,key=lambda r:(r.get('preset',''),r.get('energy_id',''),r.get('process_id',''),r.get('polarization_percent',-1)))
    out=ROOT/'reports';out.mkdir(exist_ok=True)
    cols=['job_id','status','preset','energy_id','sqrts_GeV','process_id',
          'polarization_percent','sigma_fb','sigma_mc_err_fb',
          'n_events','requested_events','seed','error']
    ids={j['job_id'] for j in jobs(args.mode,args.preset,args.energy)}
    scoped=[r for r in records if r.get('job_id') in ids]
    with (out/'cross_sections.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=cols,extrasaction='ignore')
        w.writeheader()
        for r in scoped:w.writerow(r)
    dump(scoped,out/'all_results.json')
    target=jobs(args.mode,args.preset,args.energy)
    relevant={j['job_id']:r for r in records for j in target if r.get('job_id')==j['job_id']}
    missing=[j['job_id'] for j in target if j['job_id'] not in relevant]
    failed=[j for j,r in relevant.items() if r.get('status')!='COMPLETED_UNVALIDATED']
    checks=[]
    for eid in (ENERGIES if args.energy=='both' else (args.energy,)):
        for proc in PROCS:
            baseline=relevant.get(f'{args.mode}_{args.preset}_{eid}_{proc}_P000')
            if not baseline or baseline.get('status')!='COMPLETED_UNVALIDATED':continue
            for pol in (POLS if args.mode=='full' else [0]):
                r=relevant.get(f'{args.mode}_{args.preset}_{eid}_{proc}_P{pol:03d}')
                if not r or r.get('status')!='COMPLETED_UNVALIDATED':continue
                ratio=r['sigma_fb']/baseline['sigma_fb']
                pred=1+pol/100 if PROCS[proc]['type']=='CC' else None
                ratio_err=math.sqrt((r['sigma_mc_err_fb']/baseline['sigma_fb'])**2+
                       (r['sigma_fb']*baseline['sigma_mc_err_fb']/baseline['sigma_fb']**2)**2) if pol else 0
                check={'energy':eid,'proc':proc,'pol':pol,'ratio':ratio,
                       'ratio_error_uncorrelated_approx':ratio_err,'CC_expected_ratio':pred}
                if pred is not None and pol:
                    check['deviation_in_sigma_est']=abs(ratio-pred)/max(ratio_err,1e-12)
                    check['flag_3sigma']=check['deviation_in_sigma_est']>3
                checks.append(check)
    dump({'scope':{'mode':args.mode,'preset':args.preset,'energy':args.energy},
          'requested':len(target),'present':len(relevant),'missing':missing,
          'failed_or_incomplete':failed,'bad_archives':bad_archives,
          'ratios':checks,
          'warnings':['MC integration errors are not systematic uncertainty',
                      'CC linearity is a sanity check; NC uncutted integration may need forward-region audit',
                      'Use actual sqrt(s) values, especially for fcc_design preset']},out/'quality_checks.json')
    print('RESULTS:',out/'cross_sections.csv')
    print(f'For {args.mode}/{args.preset}/{args.energy}: {len(relevant)}/{len(target)} archives; failed {len(failed)}; corrupt {len(bad_archives)}')
    if missing:print('MISSING FIRST:',missing[:10])
    if failed:print('FAILED FIRST:',failed[:10])
    if bad_archives:print('BAD ARCHIVES:',bad_archives)
    if len(relevant)==len(target) and not failed and not bad_archives:
        print('All requested job archives present. NOT an independent convergence certification.')


def doctor(args):
    print('PACKAGE:',ROOT)
    print('PYTHON:',sys.version.split()[0])
    print('BEAM 1: e- (polbeam1=0), BEAM 2: mu+ (polbeam2=scan)')
    print('PROCESSES:',len(PROCS),'POL POINTS:',POLS)
    for preset in CONFIG['beam_presets']:
        for eid in ENERGIES:
            ec=energy_config(preset,eid)
            print(f'{preset} {eid}: E(e-)={ec["electron_GeV"]} GeV E(mu+)={ec["muplus_GeV"]} GeV sqrt(s)={ec["sqrt_s_GeV"]:.6f} GeV')
    for proc in PROCS:
        p=ROOT/'templates'/(proc+'.tar.gz')
        print('TEMPLATE',proc, 'READY' if p.is_file() else 'NOT PREPARED')
    print('condor_submit:',shutil.which('condor_submit') or 'NOT FOUND (normal outside CERN)')
    print('Matplotlib optional for plots; stdlib sufficient for production and extraction.')


def selftest(args):
    from card_utils import configure,parse,entry
    assert entry('0.0 = ptl ! charged lepton pT')==('ptl','0.0')
    assert entry('# 0 = ptl ! comment') is None
    src='''# comment\n0 = lpp1 !\n0 = lpp2 !\n125 = ebeam1 !\n2000 = ebeam2 !\n0 = polbeam1 !\n0 = polbeam2 !\n1 = nevents !\n0 = iseed !\n1 = ptl !\n'''
    with tempfile.TemporaryDirectory() as d:
        t=Path(d)/'run_card.dat';t.write_text(src)
        audit=configure(t,125,2000,80,1000,123456)
        x=parse(t.read_text())
        assert x['polbeam1']=='0' and x['polbeam2']=='80'
        assert x['ptl']=='0.0' and x['nevents']=='1000'
        assert audit['original_ptl']=='1' and audit['new_ptl']=='0.0'
        # Real MG5 3.6.4 CC process cards can omit ptl entirely.
        without_ptl='\n'.join(line for line in src.splitlines()
                              if entry(line) is None or entry(line)[0]!='ptl')+'\n'
        t.write_text(without_ptl)
        no_ptl_audit=configure(t,125,2000,80,1000,123456)
        absent=parse(t.read_text())
        assert 'ptl' not in absent
        assert no_ptl_audit['ptl_field_present'] is False
        assert no_ptl_audit['original_ptl'] is None and no_ptl_audit['new_ptl'] is None
        assert 'ptl' in no_ptl_audit['optional_absent']
        assert absent['polbeam2']=='80' and absent['polbeam1']=='0'
        # Remain fail-closed on critical beam keys.
        t.write_text(without_ptl.replace('0 = polbeam2 !\n',''))
        try:configure(t,125,2000,80,1000,123456)
        except ValueError:pass
        else:raise AssertionError('Missing critical polarization key accepted')
        # Valid LHE -4 with 2 fake events for CC_H: validate PDG, beam, xsec.
        s='''<LesHouchesEvents version="3.0">\n<init>\n 11 -13 125 2000 0 0 0 0 -4 1\n 0.0002 0.000001 0.0002 1\n</init>\n'''
        ev='''<event>\n 5 1 2.000000e-4 125 0.007 0.118\n 11 -1 0 0 0 0 0 0 125 125 0 0 0\n -13 -1 0 0 0 0 0 0 -2000 2000 0.105 0 0\n 12 1 1 2 0 0 1 0 0 1 0 0 0\n -14 1 1 2 0 0 -1 0 0 1 0 0 0\n 25 1 1 2 0 0 0 0 0 125 125 0 0\n</event>\n'''
        path=Path(d)/'test.lhe.gz'
        with gzip.open(path,'wt') as g:g.write(s+ev*2+'</LesHouchesEvents>\n')
        v=_read_lhe(path,'CC_H',energy_config('exact','E1'),80,2)
        assert math.isclose(v['sigma_fb'],0.2) and v['n_events']==2
        bad=s.replace('-4 1','-1 1')
        with gzip.open(path,'wt') as g:g.write(bad+ev+'</LesHouchesEvents>\n')
        try:_read_lhe(path,'CC_H',energy_config('exact','E1'),80,1)
        except ValueError:pass
        else:raise AssertionError('Bad IDWTUP not rejected')
    assert len(jobs('full','exact','both'))==48
    assert len({j['seed'] for j in jobs('full','exact','both')})==48
    assert len(jobs('pilot','exact','both'))==8
    assert math.isclose(energy_config('exact','E1')['sqrt_s_GeV'],1000,abs_tol=0.0002)
    print('SELF TESTS PASS: strict card parsing, beam/polarization assignment, -4 LHE, rejection, 48 unique jobs')


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    sub=ap.add_subparsers(dest='cmd',required=True)
    sub.add_parser('doctor')
    p=sub.add_parser('prepare',help='Generate the 4 standalone MadGraph process templates, no integration')
    p.add_argument('--mg5',required=True)
    p.add_argument('--process',choices=['all']+list(PROCS),default='all')
    p.add_argument('--force',action='store_true')
    p=sub.add_parser('submit-file',help='Write HTCondor queue file without submitting')
    p.add_argument('--mode',choices=['pilot','full'],required=True)
    p.add_argument('--preset',choices=list(CONFIG['beam_presets']),default='exact')
    p.add_argument('--energy',choices=['E1','E2','both'],default='both')
    p=sub.add_parser('worker',help=argparse.SUPPRESS)
    p.add_argument('job_id')
    p.add_argument('proc_id')
    p.add_argument('energy_id',choices=ENERGIES)
    p.add_argument('pol',type=int)
    p.add_argument('seed',type=int)
    p.add_argument('archive')
    p.add_argument('nevents',type=int)
    p.add_argument('preset',choices=list(CONFIG['beam_presets']))
    p=sub.add_parser('collect',help='Validate completed Condor archives and build summary CSV')
    p.add_argument('--mode',choices=['pilot','full'],default='full')
    p.add_argument('--preset',choices=list(CONFIG['beam_presets']),default='exact')
    p.add_argument('--energy',choices=['E1','E2','both'],default='both')
    sub.add_parser('self-test')
    args=ap.parse_args()
    if args.cmd=='doctor':doctor(args)
    elif args.cmd=='prepare':prepare(args)
    elif args.cmd=='submit-file':submit(args)
    elif args.cmd=='worker':
        args.mode=args.job_id.split('_',1)[0]
        worker(args)
    elif args.cmd=='collect':collect(args)
    elif args.cmd=='self-test':selftest(args)

if __name__=='__main__':
    main()
