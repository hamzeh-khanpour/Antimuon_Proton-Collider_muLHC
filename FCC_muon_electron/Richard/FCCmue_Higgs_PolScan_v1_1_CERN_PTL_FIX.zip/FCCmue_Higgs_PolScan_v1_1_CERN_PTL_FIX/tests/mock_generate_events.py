#!/usr/bin/env python3
"""Synthetic integration for unit tests only; emits no physical cross sections."""
import collections,gzip,math,pathlib,re
p=pathlib.Path.cwd();c=p/'Cards/run_card.dat'
a={}
for s in c.read_text().splitlines():
 s=re.split('[!#]',s,maxsplit=1)[0]
 if '=' in s:
  l,r=s.split('=',1);a[r.strip()]=l.strip()
n=int(a['nevents']);e1=float(a['ebeam1']);e2=float(a['ebeam2']);pol=float(a['polbeam2'])
assert ('ptl' not in a or float(a['ptl'])==0.0) and float(a['polbeam1'])==0.0
proc=(p/'Cards/proc_card_mg5.dat').read_text()
cc='> ve vm~' in proc
hh=' h h' in proc
final=([12,-14] if cc else [11,-13])+[25]*(2 if hh else 1)
# Arbitrary mock normalization, not a physics result.
xs=0.000031*(1+pol/100 if cc else 1+pol/700)*(1 if not hh else .02)*(1.2 if e1>=150 else 1.0)
err=0.001*xs
path=p/'Events/run_01';path.mkdir(parents=True,exist_ok=True)
with gzip.open(path/'unweighted_events.lhe.gz','wt') as f:
 f.write('<LesHouchesEvents version="3.0">\n<init>\n')
 f.write(f'11 -13 {e1} {e2} 0 0 0 0 -4 1\n')
 f.write(f'{xs:.14g} {err:.14g} {xs:.14g} 1\n</init>\n')
 for _ in range(n):
  f.write('<event>\n')
  f.write(f'{2+len(final)} 1 {xs:.14g} 125 0.007 0.118\n')
  for pdg,status in [(11,-1),(-13,-1)]+[(v,1) for v in final]:
   f.write(f'{pdg} {status} 0 0 0 0 0 0 0 125 125 0 0\n')
  f.write('</event>\n')
 f.write('</LesHouchesEvents>\n')
print('MOCK TEST-ONLY samples produced, n=',n)
