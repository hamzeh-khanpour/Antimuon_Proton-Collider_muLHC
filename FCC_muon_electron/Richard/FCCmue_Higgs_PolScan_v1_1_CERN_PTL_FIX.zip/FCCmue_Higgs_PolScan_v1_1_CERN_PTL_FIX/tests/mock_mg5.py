#!/usr/bin/env python3
"""Synthetic *test-only* MG5 output generator. NEVER a physics data source."""
import pathlib,sys,shutil
ROOT=pathlib.Path(__file__).resolve().parent
script=pathlib.Path(sys.argv[1]).read_text().splitlines()
generate=next(l for l in script if l.startswith('generate '))
proc=pathlib.Path(next(l.split(' ',1)[1] for l in script if l.startswith('output ')))
(proc/'Cards').mkdir(parents=True)
(proc/'bin').mkdir()
shutil.copyfile(ROOT/'fixtures/mg5_3_6_4_run_card_fixture.dat',proc/'Cards/run_card.dat')
# Regression: real MG5 v3.6.4 CC process cards may omit ptl entirely.
if ' > ve vm~ ' in generate:
    sys.path.insert(0,str(ROOT.parent))
    from card_utils import entry
    p=proc/'Cards/run_card.dat'
    lines=p.read_text().splitlines(keepends=True)
    p.write_text(''.join(line for line in lines if not (entry(line) and entry(line)[0]=='ptl')))
shutil.copyfile(ROOT/'fixtures/mg5_3_6_4_param_card_fixture.dat',proc/'Cards/param_card.dat')
(proc/'Cards/proc_card_mg5.dat').write_text(generate+'\n')
shutil.copyfile(ROOT/'mock_generate_events.py',proc/'bin/generate_events')
print('MOCK TEST-ONLY MadGraph process:',generate)
