#!/usr/bin/env python3
"""Integration test of four process templates, eight pilot jobs and collector."""
import json,os,pathlib,shutil,subprocess,sys,tarfile,tempfile,unittest
SOURCE=pathlib.Path(__file__).resolve().parent.parent

class EndToEnd(unittest.TestCase):
    def test_8_pilots_and_submit_layout(self):
        with tempfile.TemporaryDirectory() as name:
            root=pathlib.Path(name)
            for f in ('CONFIG.json','scan.py','card_utils.py','worker.sh'):
                shutil.copyfile(SOURCE/f,root/f)
            shutil.copytree(SOURCE/'tests',root/'tests')
            # Create scripts with absolute executable that exists in test environment.
            fake=root/'tests/mock_mg5.py'
            def run(*a,cwd=None):
                return subprocess.run([sys.executable,str(root/'scan.py'),*a],cwd=cwd or root,
                                      stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,check=True)
            run('self-test')
            run('prepare','--mg5',str(fake),'--process','all')
            for proc in ('CC_H','CC_HH','NC_H','NC_HH'):
                self.assertTrue((root/'templates'/(proc+'.tar.gz')).exists())
            r=run('submit-file','--mode','pilot','--energy','both')
            self.assertIn('JOB COUNT: 8',r.stdout)
            submit=(root/'submissions/pilot_exact_both.sub').read_text()
            self.assertIn('request_cpus = 1',submit)
            self.assertIn('transfer_output_remaps',submit)
            self.assertIn('queue job_id,proc_id',submit)
            run('submit-file','--mode','full','--energy','both')
            self.assertEqual(len((root/'submissions/full_exact_both.txt').read_text().splitlines()),48)
            (root/'results').mkdir(exist_ok=True)
            for line in (root/'submissions/pilot_exact_both.txt').read_text().splitlines():
                job,proc,energy,pol,seed,archive,nevents,preset=line.split()
                jobroot=root/'scratch'/job
                jobroot.mkdir(parents=True)
                shutil.copyfile(root/archive,jobroot/pathlib.Path(archive).name)
                for f in ('CONFIG.json','scan.py','card_utils.py'):
                    shutil.copyfile(root/f,jobroot/f)
                r=run('worker',job,proc,energy,pol,seed,archive,nevents,preset,cwd=jobroot)
                self.assertIn('SUCCESS',r.stdout)
                with tarfile.open(jobroot/'job_output.tar.gz','r:gz') as tf:
                    record=json.loads(tf.extractfile('result.json').read())
                self.assertEqual(record['n_events'],1000)
                self.assertEqual(record['status'],'COMPLETED_UNVALIDATED')
                self.assertEqual(record['beam_ids'],[11,-13])
                self.assertEqual(record['idwtup'],-4)
                self.assertEqual(record['polarization_percent'],0)
                shutil.copyfile(jobroot/'job_output.tar.gz',root/'results'/(job+'.tar.gz'))
            r=run('collect','--mode','pilot','--energy','both')
            self.assertIn('8/8 archives',r.stdout)
            quality=json.loads((root/'reports/quality_checks.json').read_text())
            self.assertEqual(quality['failed_or_incomplete'],[])
            self.assertEqual(quality['missing'],[])
            # Test one 80% polarized CC job with its explicitly transferred template.
            line=next(j for j in (root/'submissions/full_exact_both.txt').read_text().splitlines()
                      if 'E1_CC_H_P080' in j)
            job,proc,energy,pol,seed,archive,nevents,preset=line.split()
            one=root/'scratch'/job
            one.mkdir()
            shutil.copyfile(root/archive,one/pathlib.Path(archive).name)
            for f in ('CONFIG.json','scan.py','card_utils.py'):
                shutil.copyfile(root/f,one/f)
            # Keep this lightweight; test accepts independent worker-requested events.
            r=run('worker',job,proc,energy,pol,seed,archive,'5',preset,cwd=one)
            self.assertIn('SUCCESS',r.stdout)
            record=json.loads((one/'result.json').read_text())
            self.assertEqual(record['polarization_percent'],80)
            self.assertEqual(record['n_events'],5)
            self.assertEqual(record['beam_energies_GeV'],[125,2000])

if __name__=='__main__':unittest.main(verbosity=2)
