#!/usr/bin/env bash
# HTCondor starts this script in a per-job scratch directory.
set -euo pipefail
export PYTHONUNBUFFERED=1
printf 'Start worker at %s on %s, sandbox %s\n' "$(date -u)" "$(hostname)" "$(pwd)"
python3 scan.py worker "$@"
