# FCC-ue / MuC LO +80% polarization review package

Created by analyzing the uploaded CERN results archives.


- `scientific_audit.md`: findings, 16-row summary, normalization, MC caveats and source notes.
- `tables_16rows.tex`: LaTeX table of 16 comparison entries.
- `cross_sections_16rows.csv`: spreadsheet-ready numerical comparison.
- `2TeV_8_components.csv`: precise per-component 2 TeV polarized outputs.
- `run_card_audit.csv`: 16 polarized run-card beam/polarization checks.
- `merged_2TeV_80Pol/reports/*.json`: the original seven 2 TeV reports plus the tau-only rerun report.
- `merged_2TeV_80Pol/results.csv` and `.json`: independently reconstructed complete 4-process CSV and JSON.

Numerical files preserve full input precision. Rounding in LaTeX and prose is for presentation. No LHE event data are included. The original run archives are not altered.
