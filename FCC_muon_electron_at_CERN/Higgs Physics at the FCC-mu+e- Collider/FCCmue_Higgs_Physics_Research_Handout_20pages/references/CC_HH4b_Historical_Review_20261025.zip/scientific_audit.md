# FCC-ue / Muon Collider HH → 4b vs complete 4b — CERN LO preliminary audit

**Prepared from the user-supplied 2 TeV +80% ZIP and previously supplied 1 TeV +80% ZIP; 2 TeV 0% CERN audit tar archive; and earlier 1 TeV 0% audit reference.**

## Verification summary

- Both uploaded polarized ZIPs pass archive CRC integrity checks. The 2 TeV ZIP contains 7 complete original reports and the eighth `mumu_4b_tau` report in a second run.
- All eight 2 TeV run cards confirm FCC-ue (5000,183) GeV and MuC (1000,1000) GeV, `polbeam1=80`, `polbeam2=0`. All eight 1 TeV cards confirm FCC-ue (2000,120) GeV and MuC (500,500) GeV with the same polarization.
- Eight 2 TeV JSON reports have the same SHA256 param-card reference, identical model-input dictionaries, and identical fiducial selection settings. The 2 TeV unpolarized model card SHA256 also matches.
- Higgs decays in the HH component use model-card BR(H→bb)=0.8446400227319534 and BR²=0.7134167680006347. Before-cuts HH values have been multiplied by BR². Direct 4b before/after cuts are never multiplied by BR².
- The physical collider energies are FCC-ue √s = 979.7959 GeV / 1913.11265 GeV and MuC √s = 1000 GeV / 2000 GeV, for nominal 1 TeV / 2 TeV benchmarks, respectively.
- Fiducial cuts: all 4 final-state b/anti-b satisfy |η|<5; both disjoint opposite-sign bb pair masses in [110,130] GeV for at least one pairing; pTmin=0; laboratory frame. There is no showering, detector simulation, or b-tagging in the parton-level output.
- `results.csv` from the ORIGINAL 2 TeV run is correctly INCOMPLETE for `mumu_4b`. The separately analyzed tau JSON completes the sum; see `merged_2TeV_80Pol/results.csv`.

## 1 TeV configuration

| Collider/process | P(μ⁺) | Before cuts (fb) | After cuts ± MC (fb) | Enhancement |
|---|---:|---:|---:|---:|
| FCC-ue HH → 4b | 0% | 0.049581 | 0.049124 ± 0.000080 | — |
| FCC-ue HH → 4b | +80% | 0.088984 | 0.088157 ± 0.000155 | 1.79457× |
| FCC-ue complete 4b | 0% | 0.866106 | 0.053554 ± 0.001210 | — |
| FCC-ue complete 4b | +80% | 1.560278 | 0.091952 ± 0.002127 | 1.71700× |
| Muon collider HH → 4b | 0% | 0.070538 | 0.070474 ± 0.000100 | — |
| Muon collider HH → 4b | +80% | 0.115929 | 0.115815 ± 0.000169 | 1.64336× |
| Muon collider complete 4b | 0% | 0.980033 | 0.075295 ± 0.001360 | — |
| Muon collider complete 4b | +80% | 1.724901 | 0.124718 ± 0.002404 | 1.65638× |

## 2 TeV configuration

| Collider/process | P(μ⁺) | Before cuts (fb) | After cuts ± MC (fb) | Enhancement |
|---|---:|---:|---:|---:|
| FCC-ue HH → 4b | 0% | 0.274277 | 0.264782 ± 0.000430 | — |
| FCC-ue HH → 4b | +80% | 0.493162 | 0.476106 ± 0.000788 | 1.79811× |
| FCC-ue complete 4b | 0% | 2.532894 | 0.281573 ± 0.004625 | — |
| FCC-ue complete 4b | +80% | 4.562030 | 0.507450 ± 0.008324 | 1.80219× |
| Muon collider HH → 4b | 0% | 0.307077 | 0.306240 ± 0.000542 | — |
| Muon collider HH → 4b | +80% | 0.547571 | 0.546063 ± 0.000850 | 1.78312× |
| Muon collider complete 4b | 0% | 2.745109 | 0.324799 ± 0.005085 | — |
| Muon collider complete 4b | +80% | 4.929144 | 0.578734 ± 0.009136 | 1.78182× |

## The previously missing 2 TeV +80% complete-4b result

Neutrino-flavor contributions after cuts (fb):

- `mumu_4b_e`: 0.003068166 ± 0.000062920; 10,069/30,000 events.
- `mumu_4b_mu`: 0.572490512 ± 0.009135722; 30,000/30,000 events.
- `mumu_4b_tau`: 0.003175339 ± 0.000075396; 7,163/30,000 events.

**Sum = 0.578734018 ± 0.009136250 fb** (quadrature MC approximation). Before cuts = 4.929143920 fb.

## Caveats relevant to Krzysztof

- The 2 TeV +80% `mumu_4b_e` and `mumu_4b_tau` channels produced 10,069 and 7,163 events, respectively, compared with 30,000 requested. These were not fatal errors but are an important failure of the requested sampling target (33.6% and 23.9%). Each is numerically much smaller than the mu-neutrino contribution, but independent convergence checks are necessary for any precision claim.
- The original 2 TeV unpolarized CERN audit also has small 4b e and tau samples (2,407 and 6,388). Ratios are therefore exploratory, not precision polarization measurements.
- The overall MC uncertainties are quadrature approximations, not complete uncertainty budgets. They neglect covariance, potentially correlated sampling effects, PDF/scale electroweak input variations, hadronization, tagging, detector and beam-related systematics.
- The conventional precision-SM BR(H→bb) around 0.582 differs from the actual model-card value 0.84464. Do not silently change the signal normalization or present these as precision-SM HH→4b predictions.
- Complete 4b is a full matrix-element cross section including resonant/nonresonant/interference contributions. Subtraction of an on-shell HH→4b estimate is not a pure background calculation.
- Unpolarized 1 TeV reference after-cuts values and uncertainties were available from an earlier audit, but the exact underlying unpolarized 1 TeV JSONs were not in this particular submitted ZIP; the 1 TeV 0% figures are labeled accordingly. By contrast the unpolarized 2 TeV entries were independently recomputed from `FCC_ue_MuC_2TeV_Run_Audit.tar.gz` in this workspace.
- Archived CSV/JSON component reports and run cards were independently verified and arithmetically combined, not a fresh MG5 generation or independent event-level LHE re-analysis; no LHEs are in this ZIP.

## Exact source provenance

- `FCC_ue_MuC_2TeV_80Pol_FINAL_RESULTS.zip` includes original 7-component run `run_20261025T085840Z_6032fdbe` and tau rerun `run_20261025T152242Z_3f2c0bb0`.
- `FCC_ue_MuC_1TeV_80Pol_FINAL_RESULTS.zip` includes all eight 1 TeV +80% channel reports.
- `FCC_ue_MuC_2TeV_Run_Audit.tar.gz` includes the eight 2 TeV unpolarized channel reports.
