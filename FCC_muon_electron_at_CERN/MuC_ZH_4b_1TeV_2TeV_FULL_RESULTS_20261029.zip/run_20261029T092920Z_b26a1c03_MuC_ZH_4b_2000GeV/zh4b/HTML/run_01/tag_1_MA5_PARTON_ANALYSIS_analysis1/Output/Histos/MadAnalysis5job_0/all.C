// STL headers
#include <iostream>

// ROOT headers
#include <TAxis.h>
#include <TH1F.h>
#include <TLegend.h>
#include <TCanvas.h>
#include <TFile.h>
#include <THStack.h>
#include <TStyle.h>
#include <TSystem.h>
#include <TROOT.h>

// Including histograms
#include "selection_0.C"
#include "selection_1.C"
#include "selection_2.C"
#include "selection_3.C"
#include "selection_4.C"
#include "selection_5.C"
#include "selection_6.C"
#include "selection_7.C"
#include "selection_8.C"
#include "selection_9.C"
#include "selection_10.C"
#include "selection_11.C"
#include "selection_12.C"
#include "selection_13.C"
#include "selection_14.C"
#include "selection_15.C"
#include "selection_16.C"
#include "selection_17.C"
#include "selection_18.C"
#include "selection_19.C"
#include "selection_20.C"
#include "selection_21.C"
#include "selection_22.C"
#include "selection_23.C"
#include "selection_24.C"
#include "selection_25.C"
#include "selection_26.C"
#include "selection_27.C"
#include "selection_28.C"
#include "selection_29.C"
#include "selection_30.C"
#include "selection_31.C"
#include "selection_32.C"
#include "selection_33.C"

// Main program
int main()
{
  std::cout << "BEGIN-STAMP" << std::endl;
  selection_0();
  selection_1();
  selection_2();
  selection_3();
  selection_4();
  selection_5();
  selection_6();
  selection_7();
  selection_8();
  selection_9();
  selection_10();
  selection_11();
  selection_12();
  selection_13();
  selection_14();
  selection_15();
  selection_16();
  selection_17();
  selection_18();
  selection_19();
  selection_20();
  selection_21();
  selection_22();
  selection_23();
  selection_24();
  selection_25();
  selection_26();
  selection_27();
  selection_28();
  selection_29();
  selection_30();
  selection_31();
  selection_32();
  selection_33();
  std::cout << "END-STAMP" << std::endl;
  return 0;
}
