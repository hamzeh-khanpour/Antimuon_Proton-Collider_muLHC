void selection_11()
{

  // ROOT version
  Int_t root_version = gROOT->GetVersionInt();

  // Creating a new TCanvas
  TCanvas* canvas = new TCanvas("canvas_plotflow_tempo23","canvas_plotflow_tempo23",0,0,700,500);
  gStyle->SetOptStat(0);
  gStyle->SetOptTitle(0);
  canvas->SetHighLightColor(2);
  canvas->SetFillColor(0);
  canvas->SetBorderMode(0);
  canvas->SetBorderSize(3);
  canvas->SetFrameBorderMode(0);
  canvas->SetFrameBorderSize(0);
  canvas->SetTickx(1);
  canvas->SetTicky(1);
  canvas->SetLeftMargin(0.14);
  canvas->SetRightMargin(0.05);
  canvas->SetBottomMargin(0.15);
  canvas->SetTopMargin(0.05);

  // Creating a new TH1F
  TH1F* S12_PT_0 = new TH1F("S12_PT_0","S12_PT_0",40,0.0,500.0);
  // Content
  S12_PT_0->SetBinContent(0,0.0); // underflow
  S12_PT_0->SetBinContent(1,0.05419126952666611);
  S12_PT_0->SetBinContent(2,0.06000200316666683);
  S12_PT_0->SetBinContent(3,0.0754130373133332);
  S12_PT_0->SetBinContent(4,0.06972863701333318);
  S12_PT_0->SetBinContent(5,0.07490777062000055);
  S12_PT_0->SetBinContent(6,0.07692887072666618);
  S12_PT_0->SetBinContent(7,0.08059217092000058);
  S12_PT_0->SetBinContent(8,0.08046583757999987);
  S12_PT_0->SetBinContent(9,0.08918193804000095);
  S12_PT_0->SetBinContent(10,0.08652920456666689);
  S12_PT_0->SetBinContent(11,0.08690817125333393);
  S12_PT_0->SetBinContent(12,0.08880297135333393);
  S12_PT_0->SetBinContent(13,0.09057143811333324);
  S12_PT_0->SetBinContent(14,0.09107673814000095);
  S12_PT_0->SetBinContent(15,0.09095040480000026);
  S12_PT_0->SetBinContent(16,0.08968720473333358);
  S12_PT_0->SetBinContent(17,0.09461367165999957);
  S12_PT_0->SetBinContent(18,0.09436103831333323);
  S12_PT_0->SetBinContent(19,0.09221360486666692);
  S12_PT_0->SetBinContent(20,0.09233993820666762);
  S12_PT_0->SetBinContent(21,0.08753977128666726);
  S12_PT_0->SetBinContent(22,0.09095040480000026);
  S12_PT_0->SetBinContent(23,0.07680257072000056);
  S12_PT_0->SetBinContent(24,0.08615023787999988);
  S12_PT_0->SetBinContent(25,0.08160273764000094);
  S12_PT_0->SetBinContent(26,0.08324487105999953);
  S12_PT_0->SetBinContent(27,0.0792026375133332);
  S12_PT_0->SetBinContent(28,0.08349753774000093);
  S12_PT_0->SetBinContent(29,0.07516040396666687);
  S12_PT_0->SetBinContent(30,0.07301297052000055);
  S12_PT_0->SetBinContent(31,0.0738972039000002);
  S12_PT_0->SetBinContent(32,0.07402353724000091);
  S12_PT_0->SetBinContent(33,0.07162343711333317);
  S12_PT_0->SetBinContent(34,0.0631600033333335);
  S12_PT_0->SetBinContent(35,0.0627810366466665);
  S12_PT_0->SetBinContent(36,0.07124447042666615);
  S12_PT_0->SetBinContent(37,0.05671766965999945);
  S12_PT_0->SetBinContent(38,0.05798086972666612);
  S12_PT_0->SetBinContent(39,0.05646503631333313);
  S12_PT_0->SetBinContent(40,0.0539386361799998);
  S12_PT_0->SetBinContent(41,0.6711380354199934); // overflow
  S12_PT_0->SetEntries(30000);
  // Style
  S12_PT_0->SetLineColor(9);
  S12_PT_0->SetLineStyle(1);
  S12_PT_0->SetLineWidth(1);
  S12_PT_0->SetFillColor(9);
  S12_PT_0->SetFillStyle(1001);

  // Creating a new THStack
  THStack* stack = new THStack("mystack_24","mystack");
  stack->Add(S12_PT_0);
  stack->Draw("");

  // Y axis
  stack->GetYaxis()->SetLabelSize(0.04);
  stack->GetYaxis()->SetLabelOffset(0.005);
  stack->GetYaxis()->SetTitleSize(0.06);
  stack->GetYaxis()->SetTitleFont(22);
  stack->GetYaxis()->SetTitleOffset(1);
  stack->GetYaxis()->SetTitle("Events  ( L_{int} = 10 fb^{-1} )");

  // X axis
  stack->GetXaxis()->SetLabelSize(0.04);
  stack->GetXaxis()->SetLabelOffset(0.005);
  stack->GetXaxis()->SetTitleSize(0.06);
  stack->GetXaxis()->SetTitleFont(22);
  stack->GetXaxis()->SetTitleOffset(1);
  stack->GetXaxis()->SetTitle("p_{T} [ b_{2} ] (GeV/c) ");

  // Finalizing the TCanvas
  canvas->SetLogx(0);
  canvas->SetLogy(1);

  // Saving the image
  canvas->SaveAs("../../HTML/MadAnalysis5job_0/selection_11.png");
  canvas->SaveAs("../../PDF/MadAnalysis5job_0/selection_11.png");
  canvas->SaveAs("../../DVI/MadAnalysis5job_0/selection_11.eps");

}
