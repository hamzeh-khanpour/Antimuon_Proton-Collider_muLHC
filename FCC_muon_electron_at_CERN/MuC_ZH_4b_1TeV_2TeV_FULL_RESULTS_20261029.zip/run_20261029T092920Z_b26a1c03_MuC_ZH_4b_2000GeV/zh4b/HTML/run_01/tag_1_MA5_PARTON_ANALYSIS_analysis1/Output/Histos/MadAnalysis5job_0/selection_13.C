void selection_13()
{

  // ROOT version
  Int_t root_version = gROOT->GetVersionInt();

  // Creating a new TCanvas
  TCanvas* canvas = new TCanvas("canvas_plotflow_tempo27","canvas_plotflow_tempo27",0,0,700,500);
  gStyle->SetOptStat(0);
  gStyle->SetOptTitle(0);
  canvas->SetHighLightColor(2);
  canvas->SetFillColor(0);
  canvas->SetBorderMode(0);
  canvas->SetBorderSize(3);
  canvas->SetFrameBorderMode(0);
  canvas->SetFrameBorderSize(0);
  canvas->SetTickx(1);
  canvas->SetTicky(1);
  canvas->SetLeftMargin(0.14);
  canvas->SetRightMargin(0.05);
  canvas->SetBottomMargin(0.15);
  canvas->SetTopMargin(0.05);

  // Creating a new TH1F
  TH1F* S14_PT_0 = new TH1F("S14_PT_0","S14_PT_0",40,0.0,500.0);
  // Content
  S14_PT_0->SetBinContent(0,0.0); // underflow
  S14_PT_0->SetBinContent(1,0.0);
  S14_PT_0->SetBinContent(2,0.00025263999777777775);
  S14_PT_0->SetBinContent(3,0.0005052799955555555);
  S14_PT_0->SetBinContent(4,0.002147439981111111);
  S14_PT_0->SetBinContent(5,0.00341063997);
  S14_PT_0->SetBinContent(6,0.0045475199599999995);
  S14_PT_0->SetBinContent(7,0.004294879962222222);
  S14_PT_0->SetBinContent(8,0.009095039919999999);
  S14_PT_0->SetBinContent(9,0.009979279912222222);
  S14_PT_0->SetBinContent(10,0.010610879906666667);
  S14_PT_0->SetBinContent(11,0.013516239881111112);
  S14_PT_0->SetBinContent(12,0.01591631986);
  S14_PT_0->SetBinContent(13,0.017684799844444443);
  S14_PT_0->SetBinContent(14,0.019326959829999997);
  S14_PT_0->SetBinContent(15,0.023116559796666665);
  S14_PT_0->SetBinContent(16,0.024000799788888885);
  S14_PT_0->SetBinContent(17,0.026148239769999998);
  S14_PT_0->SetBinContent(18,0.027537759757777776);
  S14_PT_0->SetBinContent(19,0.030316799733333333);
  S14_PT_0->SetBinContent(20,0.03044311973222222);
  S14_PT_0->SetBinContent(21,0.038653932993333216);
  S14_PT_0->SetBinContent(22,0.04181193296555543);
  S14_PT_0->SetBinContent(23,0.043706732948888764);
  S14_PT_0->SetBinContent(24,0.04004343298111117);
  S14_PT_0->SetBinContent(25,0.044717266273333445);
  S14_PT_0->SetBinContent(26,0.051791199544444444);
  S14_PT_0->SetBinContent(27,0.05014903289222228);
  S14_PT_0->SetBinContent(28,0.05633873283777766);
  S14_PT_0->SetBinContent(29,0.05267543287000006);
  S14_PT_0->SetBinContent(30,0.0569703328322221);
  S14_PT_0->SetBinContent(31,0.05722296616333328);
  S14_PT_0->SetBinContent(32,0.06063359946666667);
  S14_PT_0->SetBinContent(33,0.06240206611777789);
  S14_PT_0->SetBinContent(34,0.06720223274222227);
  S14_PT_0->SetBinContent(35,0.060507266134444564);
  S14_PT_0->SetBinContent(36,0.07023393271555543);
  S14_PT_0->SetBinContent(37,0.07010759938333333);
  S14_PT_0->SetBinContent(38,0.0761709659966666);
  S14_PT_0->SetBinContent(39,0.07920263263666673);
  S14_PT_0->SetBinContent(40,0.07718153265444432);
  S14_PT_0->SetBinContent(41,2.35902597925); // overflow
  S14_PT_0->SetEntries(30000);
  // Style
  S14_PT_0->SetLineColor(9);
  S14_PT_0->SetLineStyle(1);
  S14_PT_0->SetLineWidth(1);
  S14_PT_0->SetFillColor(9);
  S14_PT_0->SetFillStyle(1001);

  // Creating a new THStack
  THStack* stack = new THStack("mystack_28","mystack");
  stack->Add(S14_PT_0);
  stack->Draw("");

  // Y axis
  stack->GetYaxis()->SetLabelSize(0.04);
  stack->GetYaxis()->SetLabelOffset(0.005);
  stack->GetYaxis()->SetTitleSize(0.06);
  stack->GetYaxis()->SetTitleFont(22);
  stack->GetYaxis()->SetTitleOffset(1);
  stack->GetYaxis()->SetTitle("Events  ( L_{int} = 10 fb^{-1} )");

  // X axis
  stack->GetXaxis()->SetLabelSize(0.04);
  stack->GetXaxis()->SetLabelOffset(0.005);
  stack->GetXaxis()->SetTitleSize(0.06);
  stack->GetXaxis()->SetTitleFont(22);
  stack->GetXaxis()->SetTitleOffset(1);
  stack->GetXaxis()->SetTitle("p_{T} [ b~_{1} ] (GeV/c) ");

  // Finalizing the TCanvas
  canvas->SetLogx(0);
  canvas->SetLogy(1);

  // Saving the image
  canvas->SaveAs("../../HTML/MadAnalysis5job_0/selection_13.png");
  canvas->SaveAs("../../PDF/MadAnalysis5job_0/selection_13.png");
  canvas->SaveAs("../../DVI/MadAnalysis5job_0/selection_13.eps");

}
