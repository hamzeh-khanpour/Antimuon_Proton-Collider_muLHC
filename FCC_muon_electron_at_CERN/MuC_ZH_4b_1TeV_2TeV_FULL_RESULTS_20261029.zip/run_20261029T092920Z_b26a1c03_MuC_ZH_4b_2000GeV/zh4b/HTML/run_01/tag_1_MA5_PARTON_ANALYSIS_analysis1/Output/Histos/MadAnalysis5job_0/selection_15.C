void selection_15()
{

  // ROOT version
  Int_t root_version = gROOT->GetVersionInt();

  // Creating a new TCanvas
  TCanvas* canvas = new TCanvas("canvas_plotflow_tempo31","canvas_plotflow_tempo31",0,0,700,500);
  gStyle->SetOptStat(0);
  gStyle->SetOptTitle(0);
  canvas->SetHighLightColor(2);
  canvas->SetFillColor(0);
  canvas->SetBorderMode(0);
  canvas->SetBorderSize(3);
  canvas->SetFrameBorderMode(0);
  canvas->SetFrameBorderSize(0);
  canvas->SetTickx(1);
  canvas->SetTicky(1);
  canvas->SetLeftMargin(0.14);
  canvas->SetRightMargin(0.05);
  canvas->SetBottomMargin(0.15);
  canvas->SetTopMargin(0.05);

  // Creating a new TH1F
  TH1F* S16_PT_0 = new TH1F("S16_PT_0","S16_PT_0",40,0.0,500.0);
  // Content
  S16_PT_0->SetBinContent(0,0.0); // underflow
  S16_PT_0->SetBinContent(1,0.050906967114444535);
  S16_PT_0->SetBinContent(2,0.06505480057222225);
  S16_PT_0->SetBinContent(3,0.07124446729333325);
  S16_PT_0->SetBinContent(4,0.06897073394000015);
  S16_PT_0->SetBinContent(5,0.07263400063888893);
  S16_PT_0->SetBinContent(6,0.08324486739888882);
  S16_PT_0->SetBinContent(7,0.07617096733666677);
  S16_PT_0->SetBinContent(8,0.08236063405777777);
  S16_PT_0->SetBinContent(9,0.08627656742555566);
  S16_PT_0->SetBinContent(10,0.08791873410666684);
  S16_PT_0->SetBinContent(11,0.09271886748222215);
  S16_PT_0->SetBinContent(12,0.09233993414555572);
  S16_PT_0->SetBinContent(13,0.08703446743222215);
  S16_PT_0->SetBinContent(14,0.09410840082777784);
  S16_PT_0->SetBinContent(15,0.09385576749222234);
  S16_PT_0->SetBinContent(16,0.09663480085000006);
  S16_PT_0->SetBinContent(17,0.08905560078333338);
  S16_PT_0->SetBinContent(18,0.09221360081111117);
  S16_PT_0->SetBinContent(19,0.08703446743222215);
  S16_PT_0->SetBinContent(20,0.09208726747666661);
  S16_PT_0->SetBinContent(21,0.08362383406888889);
  S16_PT_0->SetBinContent(22,0.09385576749222234);
  S16_PT_0->SetBinContent(23,0.0807184673766666);
  S16_PT_0->SetBinContent(24,0.08627656742555566);
  S16_PT_0->SetBinContent(25,0.08337120073333339);
  S16_PT_0->SetBinContent(26,0.08690816743111122);
  S16_PT_0->SetBinContent(27,0.07654993400666682);
  S16_PT_0->SetBinContent(28,0.08135006738222215);
  S16_PT_0->SetBinContent(29,0.0757920006666667);
  S16_PT_0->SetBinContent(30,0.07553936733111122);
  S16_PT_0->SetBinContent(31,0.07212873396777794);
  S16_PT_0->SetBinContent(32,0.0757920006666667);
  S16_PT_0->SetBinContent(33,0.06960233394555572);
  S16_PT_0->SetBinContent(34,0.06758120059444449);
  S16_PT_0->SetBinContent(35,0.06669696725333343);
  S16_PT_0->SetBinContent(36,0.06480216723666676);
  S16_PT_0->SetBinContent(37,0.059370400522222255);
  S16_PT_0->SetBinContent(38,0.05520183381888886);
  S16_PT_0->SetBinContent(39,0.055707133823333484);
  S16_PT_0->SetBinContent(40,0.051033267115555475);
  S16_PT_0->SetBinContent(41,0.6658326725233332); // overflow
  S16_PT_0->SetEntries(30000);
  // Style
  S16_PT_0->SetLineColor(9);
  S16_PT_0->SetLineStyle(1);
  S16_PT_0->SetLineWidth(1);
  S16_PT_0->SetFillColor(9);
  S16_PT_0->SetFillStyle(1001);

  // Creating a new THStack
  THStack* stack = new THStack("mystack_32","mystack");
  stack->Add(S16_PT_0);
  stack->Draw("");

  // Y axis
  stack->GetYaxis()->SetLabelSize(0.04);
  stack->GetYaxis()->SetLabelOffset(0.005);
  stack->GetYaxis()->SetTitleSize(0.06);
  stack->GetYaxis()->SetTitleFont(22);
  stack->GetYaxis()->SetTitleOffset(1);
  stack->GetYaxis()->SetTitle("Events  ( L_{int} = 10 fb^{-1} )");

  // X axis
  stack->GetXaxis()->SetLabelSize(0.04);
  stack->GetXaxis()->SetLabelOffset(0.005);
  stack->GetXaxis()->SetTitleSize(0.06);
  stack->GetXaxis()->SetTitleFont(22);
  stack->GetXaxis()->SetTitleOffset(1);
  stack->GetXaxis()->SetTitle("p_{T} [ b~_{2} ] (GeV/c) ");

  // Finalizing the TCanvas
  canvas->SetLogx(0);
  canvas->SetLogy(1);

  // Saving the image
  canvas->SaveAs("../../HTML/MadAnalysis5job_0/selection_15.png");
  canvas->SaveAs("../../PDF/MadAnalysis5job_0/selection_15.png");
  canvas->SaveAs("../../DVI/MadAnalysis5job_0/selection_15.eps");

}
