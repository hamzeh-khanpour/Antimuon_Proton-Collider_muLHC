void selection_17()
{

  // ROOT version
  Int_t root_version = gROOT->GetVersionInt();

  // Creating a new TCanvas
  TCanvas* canvas = new TCanvas("canvas_plotflow_tempo35","canvas_plotflow_tempo35",0,0,700,500);
  gStyle->SetOptStat(0);
  gStyle->SetOptTitle(0);
  canvas->SetHighLightColor(2);
  canvas->SetFillColor(0);
  canvas->SetBorderMode(0);
  canvas->SetBorderSize(3);
  canvas->SetFrameBorderMode(0);
  canvas->SetFrameBorderSize(0);
  canvas->SetTickx(1);
  canvas->SetTicky(1);
  canvas->SetLeftMargin(0.14);
  canvas->SetRightMargin(0.05);
  canvas->SetBottomMargin(0.15);
  canvas->SetTopMargin(0.05);

  // Creating a new TH1F
  TH1F* S18_M_0 = new TH1F("S18_M_0","S18_M_0",40,0.0,500.0);
  // Content
  S18_M_0->SetBinContent(0,0.0); // underflow
  S18_M_0->SetBinContent(1,0.0);
  S18_M_0->SetBinContent(2,0.000252640014222223);
  S18_M_0->SetBinContent(3,0.000505280028444446);
  S18_M_0->SetBinContent(4,0.0017684800995555609);
  S18_M_0->SetBinContent(5,0.0032843201848888988);
  S18_M_0->SetBinContent(6,0.005052800284444461);
  S18_M_0->SetBinContent(7,0.005558080312888906);
  S18_M_0->SetBinContent(8,0.006442320362666687);
  S18_M_0->SetBinContent(9,0.009474000533333362);
  S18_M_0->SetBinContent(10,0.008210800462222247);
  S18_M_0->SetBinContent(11,0.008084480455111136);
  S18_M_0->SetBinContent(12,0.010358240583111144);
  S18_M_0->SetBinContent(13,0.012000400675555592);
  S18_M_0->SetBinContent(14,0.012884640725333374);
  S18_M_0->SetBinContent(15,0.014147840796444487);
  S18_M_0->SetBinContent(16,0.014400480810666711);
  S18_M_0->SetBinContent(17,0.013895200782222266);
  S18_M_0->SetBinContent(18,0.014653120824888935);
  S18_M_0->SetBinContent(19,0.016168960910222272);
  S18_M_0->SetBinContent(20,0.01781112100266672);
  S18_M_0->SetBinContent(21,0.017558480988444498);
  S18_M_0->SetBinContent(22,0.016926880952888943);
  S18_M_0->SetBinContent(23,0.017179520967111162);
  S18_M_0->SetBinContent(24,0.020716481166222288);
  S18_M_0->SetBinContent(25,0.019705921109333394);
  S18_M_0->SetBinContent(26,0.01920064108088895);
  S18_M_0->SetBinContent(27,0.023242881308444513);
  S18_M_0->SetBinContent(28,0.02185336123022229);
  S18_M_0->SetBinContent(29,0.02336920131555563);
  S18_M_0->SetBinContent(30,0.026021921464888968);
  S18_M_0->SetBinContent(31,0.02576928145066675);
  S18_M_0->SetBinContent(32,0.027537761550222306);
  S18_M_0->SetBinContent(33,0.02425344136533341);
  S18_M_0->SetBinContent(34,0.029937841685333425);
  S18_M_0->SetBinContent(35,0.02475872139377785);
  S18_M_0->SetBinContent(36,0.02513768141511119);
  S18_M_0->SetBinContent(37,0.02892728162844453);
  S18_M_0->SetBinContent(38,0.03044312171377787);
  S18_M_0->SetBinContent(39,0.031453681770666764);
  S18_M_0->SetBinContent(40,0.029937841685333425);
  S18_M_0->SetBinContent(41,3.130714842908442); // overflow
  S18_M_0->SetEntries(30000);
  // Style
  S18_M_0->SetLineColor(9);
  S18_M_0->SetLineStyle(1);
  S18_M_0->SetLineWidth(1);
  S18_M_0->SetFillColor(9);
  S18_M_0->SetFillStyle(1001);

  // Creating a new THStack
  THStack* stack = new THStack("mystack_36","mystack");
  stack->Add(S18_M_0);
  stack->Draw("");

  // Y axis
  stack->GetYaxis()->SetLabelSize(0.04);
  stack->GetYaxis()->SetLabelOffset(0.005);
  stack->GetYaxis()->SetTitleSize(0.06);
  stack->GetYaxis()->SetTitleFont(22);
  stack->GetYaxis()->SetTitleOffset(1);
  stack->GetYaxis()->SetTitle("Events  ( L_{int} = 10 fb^{-1} )");

  // X axis
  stack->GetXaxis()->SetLabelSize(0.04);
  stack->GetXaxis()->SetLabelOffset(0.005);
  stack->GetXaxis()->SetTitleSize(0.06);
  stack->GetXaxis()->SetTitleFont(22);
  stack->GetXaxis()->SetTitleOffset(1);
  stack->GetXaxis()->SetTitle("M [ b_{1} b_{2} ] (GeV/c^{2}) ");

  // Finalizing the TCanvas
  canvas->SetLogx(0);
  canvas->SetLogy(1);

  // Saving the image
  canvas->SaveAs("../../HTML/MadAnalysis5job_0/selection_17.png");
  canvas->SaveAs("../../PDF/MadAnalysis5job_0/selection_17.png");
  canvas->SaveAs("../../DVI/MadAnalysis5job_0/selection_17.eps");

}
