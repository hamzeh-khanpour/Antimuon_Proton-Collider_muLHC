void selection_20()
{

  // ROOT version
  Int_t root_version = gROOT->GetVersionInt();

  // Creating a new TCanvas
  TCanvas* canvas = new TCanvas("canvas_plotflow_tempo41","canvas_plotflow_tempo41",0,0,700,500);
  gStyle->SetOptStat(0);
  gStyle->SetOptTitle(0);
  canvas->SetHighLightColor(2);
  canvas->SetFillColor(0);
  canvas->SetBorderMode(0);
  canvas->SetBorderSize(3);
  canvas->SetFrameBorderMode(0);
  canvas->SetFrameBorderSize(0);
  canvas->SetTickx(1);
  canvas->SetTicky(1);
  canvas->SetLeftMargin(0.14);
  canvas->SetRightMargin(0.05);
  canvas->SetBottomMargin(0.15);
  canvas->SetTopMargin(0.05);

  // Creating a new TH1F
  TH1F* S21_M_0 = new TH1F("S21_M_0","S21_M_0",40,0.0,500.0);
  // Content
  S21_M_0->SetBinContent(0,0.0); // underflow
  S21_M_0->SetBinContent(1,0.0);
  S21_M_0->SetBinContent(2,0.0);
  S21_M_0->SetBinContent(3,0.0);
  S21_M_0->SetBinContent(4,0.0);
  S21_M_0->SetBinContent(5,0.0);
  S21_M_0->SetBinContent(6,0.0);
  S21_M_0->SetBinContent(7,0.0);
  S21_M_0->SetBinContent(8,0.0);
  S21_M_0->SetBinContent(9,0.00012632004000001268);
  S21_M_0->SetBinContent(10,0.002021120640000203);
  S21_M_0->SetBinContent(11,0.0032843210400003296);
  S21_M_0->SetBinContent(12,0.0032843210400003296);
  S21_M_0->SetBinContent(13,0.0037896012000003805);
  S21_M_0->SetBinContent(14,0.004294881360000431);
  S21_M_0->SetBinContent(15,0.005052801600000508);
  S21_M_0->SetBinContent(16,0.003915921240000393);
  S21_M_0->SetBinContent(17,0.006316002000000634);
  S21_M_0->SetBinContent(18,0.005558081760000558);
  S21_M_0->SetBinContent(19,0.004421201400000444);
  S21_M_0->SetBinContent(20,0.006568642080000659);
  S21_M_0->SetBinContent(21,0.005810721840000583);
  S21_M_0->SetBinContent(22,0.007705522440000774);
  S21_M_0->SetBinContent(23,0.008337122640000838);
  S21_M_0->SetBinContent(24,0.007326562320000736);
  S21_M_0->SetBinContent(25,0.00707392224000071);
  S21_M_0->SetBinContent(26,0.007452882360000748);
  S21_M_0->SetBinContent(27,0.008337122640000838);
  S21_M_0->SetBinContent(28,0.011621443680001165);
  S21_M_0->SetBinContent(29,0.010231923240001026);
  S21_M_0->SetBinContent(30,0.010989843480001104);
  S21_M_0->SetBinContent(31,0.011495123640001154);
  S21_M_0->SetBinContent(32,0.013137284160001319);
  S21_M_0->SetBinContent(33,0.010610883360001067);
  S21_M_0->SetBinContent(34,0.011116163520001115);
  S21_M_0->SetBinContent(35,0.012884644080001294);
  S21_M_0->SetBinContent(36,0.014653124640001472);
  S21_M_0->SetBinContent(37,0.013263604200001331);
  S21_M_0->SetBinContent(38,0.01225304388000123);
  S21_M_0->SetBinContent(39,0.015284724840001533);
  S21_M_0->SetBinContent(40,0.015790005000001585);
  S21_M_0->SetBinContent(41,3.525591116399974); // overflow
  S21_M_0->SetEntries(30000);
  // Style
  S21_M_0->SetLineColor(9);
  S21_M_0->SetLineStyle(1);
  S21_M_0->SetLineWidth(1);
  S21_M_0->SetFillColor(9);
  S21_M_0->SetFillStyle(1001);

  // Creating a new THStack
  THStack* stack = new THStack("mystack_42","mystack");
  stack->Add(S21_M_0);
  stack->Draw("");

  // Y axis
  stack->GetYaxis()->SetLabelSize(0.04);
  stack->GetYaxis()->SetLabelOffset(0.005);
  stack->GetYaxis()->SetTitleSize(0.06);
  stack->GetYaxis()->SetTitleFont(22);
  stack->GetYaxis()->SetTitleOffset(1);
  stack->GetYaxis()->SetTitle("Events  ( L_{int} = 10 fb^{-1} )");

  // X axis
  stack->GetXaxis()->SetLabelSize(0.04);
  stack->GetXaxis()->SetLabelOffset(0.005);
  stack->GetXaxis()->SetTitleSize(0.06);
  stack->GetXaxis()->SetTitleFont(22);
  stack->GetXaxis()->SetTitleOffset(1);
  stack->GetXaxis()->SetTitle("M [ b_{1} b_{2} b~_{2} ] (GeV/c^{2}) ");

  // Finalizing the TCanvas
  canvas->SetLogx(0);
  canvas->SetLogy(1);

  // Saving the image
  canvas->SaveAs("../../HTML/MadAnalysis5job_0/selection_20.png");
  canvas->SaveAs("../../PDF/MadAnalysis5job_0/selection_20.png");
  canvas->SaveAs("../../DVI/MadAnalysis5job_0/selection_20.eps");

}
