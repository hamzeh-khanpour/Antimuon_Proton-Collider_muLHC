void selection_25()
{

  // ROOT version
  Int_t root_version = gROOT->GetVersionInt();

  // Creating a new TCanvas
  TCanvas* canvas = new TCanvas("canvas_plotflow_tempo51","canvas_plotflow_tempo51",0,0,700,500);
  gStyle->SetOptStat(0);
  gStyle->SetOptTitle(0);
  canvas->SetHighLightColor(2);
  canvas->SetFillColor(0);
  canvas->SetBorderMode(0);
  canvas->SetBorderSize(3);
  canvas->SetFrameBorderMode(0);
  canvas->SetFrameBorderSize(0);
  canvas->SetTickx(1);
  canvas->SetTicky(1);
  canvas->SetLeftMargin(0.14);
  canvas->SetRightMargin(0.05);
  canvas->SetBottomMargin(0.15);
  canvas->SetTopMargin(0.05);

  // Creating a new TH1F
  TH1F* S26_M_0 = new TH1F("S26_M_0","S26_M_0",40,0.0,500.0);
  // Content
  S26_M_0->SetBinContent(0,0.0); // underflow
  S26_M_0->SetBinContent(1,0.0);
  S26_M_0->SetBinContent(2,0.0);
  S26_M_0->SetBinContent(3,0.0);
  S26_M_0->SetBinContent(4,0.0);
  S26_M_0->SetBinContent(5,0.0);
  S26_M_0->SetBinContent(6,0.0);
  S26_M_0->SetBinContent(7,0.0);
  S26_M_0->SetBinContent(8,0.0);
  S26_M_0->SetBinContent(9,0.00012632003377778683);
  S26_M_0->SetBinContent(10,0.001515840405333442);
  S26_M_0->SetBinContent(11,0.0026527207093335237);
  S26_M_0->SetBinContent(12,0.0041685611146669655);
  S26_M_0->SetBinContent(13,0.0034106409120002444);
  S26_M_0->SetBinContent(14,0.0031580008444446707);
  S26_M_0->SetBinContent(15,0.003663280979555818);
  S26_M_0->SetBinContent(16,0.004673841249778113);
  S26_M_0->SetBinContent(17,0.006821281824000489);
  S26_M_0->SetBinContent(18,0.004547521216000326);
  S26_M_0->SetBinContent(19,0.005305441418667047);
  S26_M_0->SetBinContent(20,0.006947601857778276);
  S26_M_0->SetBinContent(21,0.007073921891556062);
  S26_M_0->SetBinContent(22,0.005305441418667047);
  S26_M_0->SetBinContent(23,0.006947601857778276);
  S26_M_0->SetBinContent(24,0.006189681655111554);
  S26_M_0->SetBinContent(25,0.007579202026667209);
  S26_M_0->SetBinContent(26,0.00871608233066729);
  S26_M_0->SetBinContent(27,0.008210802195556144);
  S26_M_0->SetBinContent(28,0.012253043276445321);
  S26_M_0->SetBinContent(29,0.011242483006223027);
  S26_M_0->SetBinContent(30,0.009726642600889585);
  S26_M_0->SetBinContent(31,0.011116162972445241);
  S26_M_0->SetBinContent(32,0.010484562803556306);
  S26_M_0->SetBinContent(33,0.014021523749334337);
  S26_M_0->SetBinContent(34,0.013389923580445403);
  S26_M_0->SetBinContent(35,0.0114951230737786);
  S26_M_0->SetBinContent(36,0.011242483006223027);
  S26_M_0->SetBinContent(37,0.013768883681778763);
  S26_M_0->SetBinContent(38,0.014905763985778845);
  S26_M_0->SetBinContent(39,0.012632003377778683);
  S26_M_0->SetBinContent(40,0.015790004222223354);
  S26_M_0->SetBinContent(41,3.5305176107217595); // overflow
  S26_M_0->SetEntries(30000);
  // Style
  S26_M_0->SetLineColor(9);
  S26_M_0->SetLineStyle(1);
  S26_M_0->SetLineWidth(1);
  S26_M_0->SetFillColor(9);
  S26_M_0->SetFillStyle(1001);

  // Creating a new THStack
  THStack* stack = new THStack("mystack_52","mystack");
  stack->Add(S26_M_0);
  stack->Draw("");

  // Y axis
  stack->GetYaxis()->SetLabelSize(0.04);
  stack->GetYaxis()->SetLabelOffset(0.005);
  stack->GetYaxis()->SetTitleSize(0.06);
  stack->GetYaxis()->SetTitleFont(22);
  stack->GetYaxis()->SetTitleOffset(1);
  stack->GetYaxis()->SetTitle("Events  ( L_{int} = 10 fb^{-1} )");

  // X axis
  stack->GetXaxis()->SetLabelSize(0.04);
  stack->GetXaxis()->SetLabelOffset(0.005);
  stack->GetXaxis()->SetTitleSize(0.06);
  stack->GetXaxis()->SetTitleFont(22);
  stack->GetXaxis()->SetTitleOffset(1);
  stack->GetXaxis()->SetTitle("M [ b_{2} b~_{1} b~_{2} ] (GeV/c^{2}) ");

  // Finalizing the TCanvas
  canvas->SetLogx(0);
  canvas->SetLogy(1);

  // Saving the image
  canvas->SaveAs("../../HTML/MadAnalysis5job_0/selection_25.png");
  canvas->SaveAs("../../PDF/MadAnalysis5job_0/selection_25.png");
  canvas->SaveAs("../../DVI/MadAnalysis5job_0/selection_25.eps");

}
