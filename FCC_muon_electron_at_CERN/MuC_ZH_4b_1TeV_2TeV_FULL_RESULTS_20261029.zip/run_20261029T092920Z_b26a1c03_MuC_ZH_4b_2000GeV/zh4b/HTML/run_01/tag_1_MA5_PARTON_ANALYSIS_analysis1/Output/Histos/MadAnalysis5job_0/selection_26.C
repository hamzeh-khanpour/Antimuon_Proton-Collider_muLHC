void selection_26()
{

  // ROOT version
  Int_t root_version = gROOT->GetVersionInt();

  // Creating a new TCanvas
  TCanvas* canvas = new TCanvas("canvas_plotflow_tempo53","canvas_plotflow_tempo53",0,0,700,500);
  gStyle->SetOptStat(0);
  gStyle->SetOptTitle(0);
  canvas->SetHighLightColor(2);
  canvas->SetFillColor(0);
  canvas->SetBorderMode(0);
  canvas->SetBorderSize(3);
  canvas->SetFrameBorderMode(0);
  canvas->SetFrameBorderSize(0);
  canvas->SetTickx(1);
  canvas->SetTicky(1);
  canvas->SetLeftMargin(0.14);
  canvas->SetRightMargin(0.05);
  canvas->SetBottomMargin(0.15);
  canvas->SetTopMargin(0.05);

  // Creating a new TH1F
  TH1F* S27_M_0 = new TH1F("S27_M_0","S27_M_0",40,0.0,500.0);
  // Content
  S27_M_0->SetBinContent(0,0.0); // underflow
  S27_M_0->SetBinContent(1,0.0);
  S27_M_0->SetBinContent(2,0.0005052799955555555);
  S27_M_0->SetBinContent(3,0.0016421599855555554);
  S27_M_0->SetBinContent(4,0.0045475199599999995);
  S27_M_0->SetBinContent(5,0.0064423199433333335);
  S27_M_0->SetBinContent(6,0.009600319915555555);
  S27_M_0->SetBinContent(7,0.01338991988222222);
  S27_M_0->SetBinContent(8,0.026527199766666665);
  S27_M_0->SetBinContent(9,0.01667423985333333);
  S27_M_0->SetBinContent(10,0.01680055985222222);
  S27_M_0->SetBinContent(11,0.021853359807777778);
  S27_M_0->SetBinContent(12,0.018947999833333333);
  S27_M_0->SetBinContent(13,0.022611279801111113);
  S27_M_0->SetBinContent(14,0.026148239769999998);
  S27_M_0->SetBinContent(15,0.023116559796666665);
  S27_M_0->SetBinContent(16,0.029053599744444443);
  S27_M_0->SetBinContent(17,0.02943255974111111);
  S27_M_0->SetBinContent(18,0.03145367972333333);
  S27_M_0->SetBinContent(19,0.034737999694444445);
  S27_M_0->SetBinContent(20,0.035369599688888885);
  S27_M_0->SetBinContent(21,0.03524326635666678);
  S27_M_0->SetBinContent(22,0.034737999694444445);
  S27_M_0->SetBinContent(23,0.03675913300999988);
  S27_M_0->SetBinContent(24,0.03941183298666672);
  S27_M_0->SetBinContent(25,0.04320143295333339);
  S27_M_0->SetBinContent(26,0.042317199627777774);
  S27_M_0->SetBinContent(27,0.04294879962222222);
  S27_M_0->SetBinContent(28,0.04522256626888883);
  S27_M_0->SetBinContent(29,0.04534886626777789);
  S27_M_0->SetBinContent(30,0.05040166622333345);
  S27_M_0->SetBinContent(31,0.048380566241111055);
  S27_M_0->SetBinContent(32,0.05040166622333345);
  S27_M_0->SetBinContent(33,0.05368599952777778);
  S27_M_0->SetBinContent(34,0.05115959955);
  S27_M_0->SetBinContent(35,0.05747559949444444);
  S27_M_0->SetBinContent(36,0.05507553284888877);
  S27_M_0->SetBinContent(37,0.05355966619555567);
  S27_M_0->SetBinContent(38,0.05659136616888883);
  S27_M_0->SetBinContent(39,0.059117766146666605);
  S27_M_0->SetBinContent(40,0.062275766118888826);
  S27_M_0->SetBinContent(41,2.4574293117177772); // overflow
  S27_M_0->SetEntries(30000);
  // Style
  S27_M_0->SetLineColor(9);
  S27_M_0->SetLineStyle(1);
  S27_M_0->SetLineWidth(1);
  S27_M_0->SetFillColor(9);
  S27_M_0->SetFillStyle(1001);

  // Creating a new THStack
  THStack* stack = new THStack("mystack_54","mystack");
  stack->Add(S27_M_0);
  stack->Draw("");

  // Y axis
  stack->GetYaxis()->SetLabelSize(0.04);
  stack->GetYaxis()->SetLabelOffset(0.005);
  stack->GetYaxis()->SetTitleSize(0.06);
  stack->GetYaxis()->SetTitleFont(22);
  stack->GetYaxis()->SetTitleOffset(1);
  stack->GetYaxis()->SetTitle("Events  ( L_{int} = 10 fb^{-1} )");

  // X axis
  stack->GetXaxis()->SetLabelSize(0.04);
  stack->GetXaxis()->SetLabelOffset(0.005);
  stack->GetXaxis()->SetTitleSize(0.06);
  stack->GetXaxis()->SetTitleFont(22);
  stack->GetXaxis()->SetTitleOffset(1);
  stack->GetXaxis()->SetTitle("M [ b_{2} b~_{2} ] (GeV/c^{2}) ");

  // Finalizing the TCanvas
  canvas->SetLogx(0);
  canvas->SetLogy(1);

  // Saving the image
  canvas->SaveAs("../../HTML/MadAnalysis5job_0/selection_26.png");
  canvas->SaveAs("../../PDF/MadAnalysis5job_0/selection_26.png");
  canvas->SaveAs("../../DVI/MadAnalysis5job_0/selection_26.eps");

}
