def selection_26():

    # Library import
    import numpy
    import matplotlib
    import matplotlib.pyplot   as plt
    import matplotlib.gridspec as gridspec

    # Library version
    matplotlib_version = matplotlib.__version__
    numpy_version      = numpy.__version__

    # Histo binning
    xBinning = numpy.linspace(0.0,500.0,41,endpoint=True)

    # Creating data sequence: middle of each bin
    xData = numpy.array([6.25,18.75,31.25,43.75,56.25,68.75,81.25,93.75,106.25,118.75,131.25,143.75,156.25,168.75,181.25,193.75,206.25,218.75,231.25,243.75,256.25,268.75,281.25,293.75,306.25,318.75,331.25,343.75,356.25,368.75,381.25,393.75,406.25,418.75,431.25,443.75,456.25,468.75,481.25,493.75])

    # Creating weights for histo: y27_M_0
    y27_M_0_weights = numpy.array([0.0,0.0005052799955555555,0.0016421599855555554,0.0045475199599999995,0.0064423199433333335,0.009600319915555555,0.01338991988222222,0.026527199766666665,0.01667423985333333,0.01680055985222222,0.021853359807777778,0.018947999833333333,0.022611279801111113,0.026148239769999998,0.023116559796666665,0.029053599744444443,0.02943255974111111,0.03145367972333333,0.034737999694444445,0.035369599688888885,0.03524326635666678,0.034737999694444445,0.03675913300999988,0.03941183298666672,0.04320143295333339,0.042317199627777774,0.04294879962222222,0.04522256626888883,0.04534886626777789,0.05040166622333345,0.048380566241111055,0.05040166622333345,0.05368599952777778,0.05115959955,0.05747559949444444,0.05507553284888877,0.05355966619555567,0.05659136616888883,0.059117766146666605,0.062275766118888826])

    # Creating a new Canvas
    fig   = plt.figure(figsize=(8.75,6.25),dpi=80)
    frame = gridspec.GridSpec(1,1)
    pad   = fig.add_subplot(frame[0])

    # Creating a new Stack
    pad.hist(x=xData, bins=xBinning, weights=y27_M_0_weights,\
             label="$run\_01$", histtype="stepfilled", rwidth=1.0,\
             color="#5954d8", edgecolor="#5954d8", linewidth=1, linestyle="solid",\
             bottom=None, cumulative=False, density=False, align="mid", orientation="vertical")


    # Axis
    plt.rc('text',usetex=False)
    plt.xlabel(r"$M$ $[ b_{2} b~_{2} ]$ $(GeV/c^{2})$ ",\
               fontsize=16,color="black")
    plt.ylabel(r"$\mathrm{Events}$ $(\mathcal{L}_{\mathrm{int}} = 10\ \mathrm{fb}^{-1})$ ",\
               fontsize=16,color="black")

    # Boundary of y-axis
    ymax=(y27_M_0_weights).max()*1.1
    #ymin=0 # linear scale
    ymin=min([x for x in (y27_M_0_weights) if x])/100. # log scale
    plt.gca().set_ylim(ymin,ymax)

    # Log/Linear scale for X-axis
    plt.gca().set_xscale("linear")
    #plt.gca().set_xscale("log",nonpositive="clip")

    # Log/Linear scale for Y-axis
    #plt.gca().set_yscale("linear")
    plt.gca().set_yscale("log",nonpositive="clip")

    # Saving the image
    plt.savefig('../../HTML/MadAnalysis5job_0/selection_26.png')
    plt.savefig('../../PDF/MadAnalysis5job_0/selection_26.png')
    plt.savefig('../../DVI/MadAnalysis5job_0/selection_26.eps')

# Running!
if __name__ == '__main__':
    selection_26()
