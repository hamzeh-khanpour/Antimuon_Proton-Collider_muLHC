void selection_27()
{

  // ROOT version
  Int_t root_version = gROOT->GetVersionInt();

  // Creating a new TCanvas
  TCanvas* canvas = new TCanvas("canvas_plotflow_tempo55","canvas_plotflow_tempo55",0,0,700,500);
  gStyle->SetOptStat(0);
  gStyle->SetOptTitle(0);
  canvas->SetHighLightColor(2);
  canvas->SetFillColor(0);
  canvas->SetBorderMode(0);
  canvas->SetBorderSize(3);
  canvas->SetFrameBorderMode(0);
  canvas->SetFrameBorderSize(0);
  canvas->SetTickx(1);
  canvas->SetTicky(1);
  canvas->SetLeftMargin(0.14);
  canvas->SetRightMargin(0.05);
  canvas->SetBottomMargin(0.15);
  canvas->SetTopMargin(0.05);

  // Creating a new TH1F
  TH1F* S28_M_0 = new TH1F("S28_M_0","S28_M_0",40,0.0,500.0);
  // Content
  S28_M_0->SetBinContent(0,0.0); // underflow
  S28_M_0->SetBinContent(1,0.0);
  S28_M_0->SetBinContent(2,0.0001263200031111112);
  S28_M_0->SetBinContent(3,0.0008842400217777783);
  S28_M_0->SetBinContent(4,0.0007579200186666672);
  S28_M_0->SetBinContent(5,0.002652720065333335);
  S28_M_0->SetBinContent(6,0.004926480121333336);
  S28_M_0->SetBinContent(7,0.0055580801368888925);
  S28_M_0->SetBinContent(8,0.006947600171111116);
  S28_M_0->SetBinContent(9,0.006189680152444448);
  S28_M_0->SetBinContent(10,0.0073265601804444495);
  S28_M_0->SetBinContent(11,0.010484560258222227);
  S28_M_0->SetBinContent(12,0.010737200264444451);
  S28_M_0->SetBinContent(13,0.012126720298666675);
  S28_M_0->SetBinContent(14,0.010231920252000006);
  S28_M_0->SetBinContent(15,0.013642560336000009);
  S28_M_0->SetBinContent(16,0.013389920329777786);
  S28_M_0->SetBinContent(17,0.014779440364000009);
  S28_M_0->SetBinContent(18,0.014653120360888899);
  S28_M_0->SetBinContent(19,0.01591632039200001);
  S28_M_0->SetBinContent(20,0.017558480432444453);
  S28_M_0->SetBinContent(21,0.022737600560000015);
  S28_M_0->SetBinContent(22,0.016168960398222233);
  S28_M_0->SetBinContent(23,0.016547920407555566);
  S28_M_0->SetBinContent(24,0.020716480510222235);
  S28_M_0->SetBinContent(25,0.021853360538222236);
  S28_M_0->SetBinContent(26,0.02210600054444446);
  S28_M_0->SetBinContent(27,0.021979680541333348);
  S28_M_0->SetBinContent(28,0.02412712059422224);
  S28_M_0->SetBinContent(29,0.026274560647111124);
  S28_M_0->SetBinContent(30,0.02463240060666668);
  S28_M_0->SetBinContent(31,0.022863920563111127);
  S28_M_0->SetBinContent(32,0.026021920640888905);
  S28_M_0->SetBinContent(33,0.02539032062533335);
  S28_M_0->SetBinContent(34,0.026779840659555573);
  S28_M_0->SetBinContent(35,0.028295680696888904);
  S28_M_0->SetBinContent(36,0.031327360771555575);
  S28_M_0->SetBinContent(37,0.02880096070933335);
  S28_M_0->SetBinContent(38,0.02867464070622224);
  S28_M_0->SetBinContent(39,0.031327360771555575);
  S28_M_0->SetBinContent(40,0.02854832070311113);
  S28_M_0->SetBinContent(41,3.1255357436448885); // overflow
  S28_M_0->SetEntries(30000);
  // Style
  S28_M_0->SetLineColor(9);
  S28_M_0->SetLineStyle(1);
  S28_M_0->SetLineWidth(1);
  S28_M_0->SetFillColor(9);
  S28_M_0->SetFillStyle(1001);

  // Creating a new THStack
  THStack* stack = new THStack("mystack_56","mystack");
  stack->Add(S28_M_0);
  stack->Draw("");

  // Y axis
  stack->GetYaxis()->SetLabelSize(0.04);
  stack->GetYaxis()->SetLabelOffset(0.005);
  stack->GetYaxis()->SetTitleSize(0.06);
  stack->GetYaxis()->SetTitleFont(22);
  stack->GetYaxis()->SetTitleOffset(1);
  stack->GetYaxis()->SetTitle("Events  ( L_{int} = 10 fb^{-1} )");

  // X axis
  stack->GetXaxis()->SetLabelSize(0.04);
  stack->GetXaxis()->SetLabelOffset(0.005);
  stack->GetXaxis()->SetTitleSize(0.06);
  stack->GetXaxis()->SetTitleFont(22);
  stack->GetXaxis()->SetTitleOffset(1);
  stack->GetXaxis()->SetTitle("M [ b~_{1} b~_{2} ] (GeV/c^{2}) ");

  // Finalizing the TCanvas
  canvas->SetLogx(0);
  canvas->SetLogy(1);

  // Saving the image
  canvas->SaveAs("../../HTML/MadAnalysis5job_0/selection_27.png");
  canvas->SaveAs("../../PDF/MadAnalysis5job_0/selection_27.png");
  canvas->SaveAs("../../DVI/MadAnalysis5job_0/selection_27.eps");

}
