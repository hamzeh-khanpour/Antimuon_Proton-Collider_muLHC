def selection_27():

    # Library import
    import numpy
    import matplotlib
    import matplotlib.pyplot   as plt
    import matplotlib.gridspec as gridspec

    # Library version
    matplotlib_version = matplotlib.__version__
    numpy_version      = numpy.__version__

    # Histo binning
    xBinning = numpy.linspace(0.0,500.0,41,endpoint=True)

    # Creating data sequence: middle of each bin
    xData = numpy.array([6.25,18.75,31.25,43.75,56.25,68.75,81.25,93.75,106.25,118.75,131.25,143.75,156.25,168.75,181.25,193.75,206.25,218.75,231.25,243.75,256.25,268.75,281.25,293.75,306.25,318.75,331.25,343.75,356.25,368.75,381.25,393.75,406.25,418.75,431.25,443.75,456.25,468.75,481.25,493.75])

    # Creating weights for histo: y28_M_0
    y28_M_0_weights = numpy.array([0.0,0.0001263200031111112,0.0008842400217777783,0.0007579200186666672,0.002652720065333335,0.004926480121333336,0.0055580801368888925,0.006947600171111116,0.006189680152444448,0.0073265601804444495,0.010484560258222227,0.010737200264444451,0.012126720298666675,0.010231920252000006,0.013642560336000009,0.013389920329777786,0.014779440364000009,0.014653120360888899,0.01591632039200001,0.017558480432444453,0.022737600560000015,0.016168960398222233,0.016547920407555566,0.020716480510222235,0.021853360538222236,0.02210600054444446,0.021979680541333348,0.02412712059422224,0.026274560647111124,0.02463240060666668,0.022863920563111127,0.026021920640888905,0.02539032062533335,0.026779840659555573,0.028295680696888904,0.031327360771555575,0.02880096070933335,0.02867464070622224,0.031327360771555575,0.02854832070311113])

    # Creating a new Canvas
    fig   = plt.figure(figsize=(8.75,6.25),dpi=80)
    frame = gridspec.GridSpec(1,1)
    pad   = fig.add_subplot(frame[0])

    # Creating a new Stack
    pad.hist(x=xData, bins=xBinning, weights=y28_M_0_weights,\
             label="$run\_01$", histtype="stepfilled", rwidth=1.0,\
             color="#5954d8", edgecolor="#5954d8", linewidth=1, linestyle="solid",\
             bottom=None, cumulative=False, density=False, align="mid", orientation="vertical")


    # Axis
    plt.rc('text',usetex=False)
    plt.xlabel(r"$M$ $[ b~_{1} b~_{2} ]$ $(GeV/c^{2})$ ",\
               fontsize=16,color="black")
    plt.ylabel(r"$\mathrm{Events}$ $(\mathcal{L}_{\mathrm{int}} = 10\ \mathrm{fb}^{-1})$ ",\
               fontsize=16,color="black")

    # Boundary of y-axis
    ymax=(y28_M_0_weights).max()*1.1
    #ymin=0 # linear scale
    ymin=min([x for x in (y28_M_0_weights) if x])/100. # log scale
    plt.gca().set_ylim(ymin,ymax)

    # Log/Linear scale for X-axis
    plt.gca().set_xscale("linear")
    #plt.gca().set_xscale("log",nonpositive="clip")

    # Log/Linear scale for Y-axis
    #plt.gca().set_yscale("linear")
    plt.gca().set_yscale("log",nonpositive="clip")

    # Saving the image
    plt.savefig('../../HTML/MadAnalysis5job_0/selection_27.png')
    plt.savefig('../../PDF/MadAnalysis5job_0/selection_27.png')
    plt.savefig('../../DVI/MadAnalysis5job_0/selection_27.eps')

# Running!
if __name__ == '__main__':
    selection_27()
