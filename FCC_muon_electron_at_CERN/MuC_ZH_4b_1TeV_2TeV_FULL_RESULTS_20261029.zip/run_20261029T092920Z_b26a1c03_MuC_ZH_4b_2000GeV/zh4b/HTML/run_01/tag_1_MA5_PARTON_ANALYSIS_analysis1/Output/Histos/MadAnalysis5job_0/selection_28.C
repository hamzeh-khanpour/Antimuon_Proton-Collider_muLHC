void selection_28()
{

  // ROOT version
  Int_t root_version = gROOT->GetVersionInt();

  // Creating a new TCanvas
  TCanvas* canvas = new TCanvas("canvas_plotflow_tempo57","canvas_plotflow_tempo57",0,0,700,500);
  gStyle->SetOptStat(0);
  gStyle->SetOptTitle(0);
  canvas->SetHighLightColor(2);
  canvas->SetFillColor(0);
  canvas->SetBorderMode(0);
  canvas->SetBorderSize(3);
  canvas->SetFrameBorderMode(0);
  canvas->SetFrameBorderSize(0);
  canvas->SetTickx(1);
  canvas->SetTicky(1);
  canvas->SetLeftMargin(0.14);
  canvas->SetRightMargin(0.05);
  canvas->SetBottomMargin(0.15);
  canvas->SetTopMargin(0.05);

  // Creating a new TH1F
  TH1F* S29_DELTAR_0 = new TH1F("S29_DELTAR_0","S29_DELTAR_0",40,0.0,10.0);
  // Content
  S29_DELTAR_0->SetBinContent(0,0.0); // underflow
  S29_DELTAR_0->SetBinContent(1,0.0);
  S29_DELTAR_0->SetBinContent(2,0.0002526399982222222);
  S29_DELTAR_0->SetBinContent(3,0.0005052799964444444);
  S29_DELTAR_0->SetBinContent(4,0.0011368799919999997);
  S29_DELTAR_0->SetBinContent(5,0.0008842399937777775);
  S29_DELTAR_0->SetBinContent(6,0.0018947999866666663);
  S29_DELTAR_0->SetBinContent(7,0.003915919972444443);
  S29_DELTAR_0->SetBinContent(8,0.005937039958222221);
  S29_DELTAR_0->SetBinContent(9,0.013642559903999997);
  S29_DELTAR_0->SetBinContent(10,0.025642959819555552);
  S29_DELTAR_0->SetBinContent(11,0.08589759939555554);
  S29_DELTAR_0->SetBinContent(12,0.5494919961333332);
  S29_DELTAR_0->SetBinContent(13,2.053331652217777);
  S29_DELTAR_0->SetBinContent(14,0.6250313289351112);
  S29_DELTAR_0->SetBinContent(15,0.22396536509066656);
  S29_DELTAR_0->SetBinContent(16,0.10257183261155557);
  S29_DELTAR_0->SetBinContent(17,0.044085666356444536);
  S29_DELTAR_0->SetBinContent(18,0.025137679823111107);
  S29_DELTAR_0->SetBinContent(19,0.010358239927111108);
  S29_DELTAR_0->SetBinContent(20,0.006694959952888887);
  S29_DELTAR_0->SetBinContent(21,0.003410639975999999);
  S29_DELTAR_0->SetBinContent(22,0.0022737599839999993);
  S29_DELTAR_0->SetBinContent(23,0.001642159988444444);
  S29_DELTAR_0->SetBinContent(24,0.0005052799964444444);
  S29_DELTAR_0->SetBinContent(25,0.0010105599928888888);
  S29_DELTAR_0->SetBinContent(26,0.0002526399982222222);
  S29_DELTAR_0->SetBinContent(27,0.0001263199991111111);
  S29_DELTAR_0->SetBinContent(28,0.0);
  S29_DELTAR_0->SetBinContent(29,0.0);
  S29_DELTAR_0->SetBinContent(30,0.0);
  S29_DELTAR_0->SetBinContent(31,0.0);
  S29_DELTAR_0->SetBinContent(32,0.0);
  S29_DELTAR_0->SetBinContent(33,0.0);
  S29_DELTAR_0->SetBinContent(34,0.0);
  S29_DELTAR_0->SetBinContent(35,0.0);
  S29_DELTAR_0->SetBinContent(36,0.0);
  S29_DELTAR_0->SetBinContent(37,0.0);
  S29_DELTAR_0->SetBinContent(38,0.0);
  S29_DELTAR_0->SetBinContent(39,0.0);
  S29_DELTAR_0->SetBinContent(40,0.0);
  S29_DELTAR_0->SetBinContent(41,0.0); // overflow
  S29_DELTAR_0->SetEntries(30000);
  // Style
  S29_DELTAR_0->SetLineColor(9);
  S29_DELTAR_0->SetLineStyle(1);
  S29_DELTAR_0->SetLineWidth(1);
  S29_DELTAR_0->SetFillColor(9);
  S29_DELTAR_0->SetFillStyle(1001);

  // Creating a new THStack
  THStack* stack = new THStack("mystack_58","mystack");
  stack->Add(S29_DELTAR_0);
  stack->Draw("");

  // Y axis
  stack->GetYaxis()->SetLabelSize(0.04);
  stack->GetYaxis()->SetLabelOffset(0.005);
  stack->GetYaxis()->SetTitleSize(0.06);
  stack->GetYaxis()->SetTitleFont(22);
  stack->GetYaxis()->SetTitleOffset(1);
  stack->GetYaxis()->SetTitle("Events  ( L_{int} = 10 fb^{-1} )");

  // X axis
  stack->GetXaxis()->SetLabelSize(0.04);
  stack->GetXaxis()->SetLabelOffset(0.005);
  stack->GetXaxis()->SetTitleSize(0.06);
  stack->GetXaxis()->SetTitleFont(22);
  stack->GetXaxis()->SetTitleOffset(1);
  stack->GetXaxis()->SetTitle("#DeltaR [ b_{1}, b_{2} ] ");

  // Finalizing the TCanvas
  canvas->SetLogx(0);
  canvas->SetLogy(1);

  // Saving the image
  canvas->SaveAs("../../HTML/MadAnalysis5job_0/selection_28.png");
  canvas->SaveAs("../../PDF/MadAnalysis5job_0/selection_28.png");
  canvas->SaveAs("../../DVI/MadAnalysis5job_0/selection_28.eps");

}
