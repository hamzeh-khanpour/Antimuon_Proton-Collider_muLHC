void selection_29()
{

  // ROOT version
  Int_t root_version = gROOT->GetVersionInt();

  // Creating a new TCanvas
  TCanvas* canvas = new TCanvas("canvas_plotflow_tempo59","canvas_plotflow_tempo59",0,0,700,500);
  gStyle->SetOptStat(0);
  gStyle->SetOptTitle(0);
  canvas->SetHighLightColor(2);
  canvas->SetFillColor(0);
  canvas->SetBorderMode(0);
  canvas->SetBorderSize(3);
  canvas->SetFrameBorderMode(0);
  canvas->SetFrameBorderSize(0);
  canvas->SetTickx(1);
  canvas->SetTicky(1);
  canvas->SetLeftMargin(0.14);
  canvas->SetRightMargin(0.05);
  canvas->SetBottomMargin(0.15);
  canvas->SetTopMargin(0.05);

  // Creating a new TH1F
  TH1F* S30_DELTAR_0 = new TH1F("S30_DELTAR_0","S30_DELTAR_0",40,0.0,10.0);
  // Content
  S30_DELTAR_0->SetBinContent(0,0.0); // underflow
  S30_DELTAR_0->SetBinContent(1,0.0030316801333333384);
  S30_DELTAR_0->SetBinContent(2,0.014400480633333356);
  S30_DELTAR_0->SetBinContent(3,0.0016421600722222247);
  S30_DELTAR_0->SetBinContent(4,0.0);
  S30_DELTAR_0->SetBinContent(5,0.0006316000277777788);
  S30_DELTAR_0->SetBinContent(6,0.00012632000555555577);
  S30_DELTAR_0->SetBinContent(7,0.00012632000555555577);
  S30_DELTAR_0->SetBinContent(8,0.00012632000555555577);
  S30_DELTAR_0->SetBinContent(9,0.0);
  S30_DELTAR_0->SetBinContent(10,0.00025264001111111154);
  S30_DELTAR_0->SetBinContent(11,0.0005052800222222231);
  S30_DELTAR_0->SetBinContent(12,0.18164817465555616);
  S30_DELTAR_0->SetBinContent(13,2.382521438116662);
  S30_DELTAR_0->SetBinContent(14,0.7329086989000024);
  S30_DELTAR_0->SetBinContent(15,0.2594612780777776);
  S30_DELTAR_0->SetBinContent(16,0.11090897154444491);
  S30_DELTAR_0->SetBinContent(17,0.049517435511110895);
  S30_DELTAR_0->SetBinContent(18,0.026400881161111153);
  S30_DELTAR_0->SetBinContent(19,0.013137280577777797);
  S30_DELTAR_0->SetBinContent(20,0.006189680272222231);
  S30_DELTAR_0->SetBinContent(21,0.0025264001111111154);
  S30_DELTAR_0->SetBinContent(22,0.0020211200888888923);
  S30_DELTAR_0->SetBinContent(23,0.0005052800222222231);
  S30_DELTAR_0->SetBinContent(24,0.0006316000277777788);
  S30_DELTAR_0->SetBinContent(25,0.00012632000555555577);
  S30_DELTAR_0->SetBinContent(26,0.0);
  S30_DELTAR_0->SetBinContent(27,0.00012632000555555577);
  S30_DELTAR_0->SetBinContent(28,0.0);
  S30_DELTAR_0->SetBinContent(29,0.00012632000555555577);
  S30_DELTAR_0->SetBinContent(30,0.0);
  S30_DELTAR_0->SetBinContent(31,0.0);
  S30_DELTAR_0->SetBinContent(32,0.0);
  S30_DELTAR_0->SetBinContent(33,0.0);
  S30_DELTAR_0->SetBinContent(34,0.0);
  S30_DELTAR_0->SetBinContent(35,0.0);
  S30_DELTAR_0->SetBinContent(36,0.0);
  S30_DELTAR_0->SetBinContent(37,0.0);
  S30_DELTAR_0->SetBinContent(38,0.0);
  S30_DELTAR_0->SetBinContent(39,0.0);
  S30_DELTAR_0->SetBinContent(40,0.0);
  S30_DELTAR_0->SetBinContent(41,0.0); // overflow
  S30_DELTAR_0->SetEntries(30000);
  // Style
  S30_DELTAR_0->SetLineColor(9);
  S30_DELTAR_0->SetLineStyle(1);
  S30_DELTAR_0->SetLineWidth(1);
  S30_DELTAR_0->SetFillColor(9);
  S30_DELTAR_0->SetFillStyle(1001);

  // Creating a new THStack
  THStack* stack = new THStack("mystack_60","mystack");
  stack->Add(S30_DELTAR_0);
  stack->Draw("");

  // Y axis
  stack->GetYaxis()->SetLabelSize(0.04);
  stack->GetYaxis()->SetLabelOffset(0.005);
  stack->GetYaxis()->SetTitleSize(0.06);
  stack->GetYaxis()->SetTitleFont(22);
  stack->GetYaxis()->SetTitleOffset(1);
  stack->GetYaxis()->SetTitle("Events  ( L_{int} = 10 fb^{-1} )");

  // X axis
  stack->GetXaxis()->SetLabelSize(0.04);
  stack->GetXaxis()->SetLabelOffset(0.005);
  stack->GetXaxis()->SetTitleSize(0.06);
  stack->GetXaxis()->SetTitleFont(22);
  stack->GetXaxis()->SetTitleOffset(1);
  stack->GetXaxis()->SetTitle("#DeltaR [ b_{1}, b~_{1} ] ");

  // Finalizing the TCanvas
  canvas->SetLogx(0);
  canvas->SetLogy(1);

  // Saving the image
  canvas->SaveAs("../../HTML/MadAnalysis5job_0/selection_29.png");
  canvas->SaveAs("../../PDF/MadAnalysis5job_0/selection_29.png");
  canvas->SaveAs("../../DVI/MadAnalysis5job_0/selection_29.eps");

}
