void selection_3()
{

  // ROOT version
  Int_t root_version = gROOT->GetVersionInt();

  // Creating a new TCanvas
  TCanvas* canvas = new TCanvas("canvas_plotflow_tempo7","canvas_plotflow_tempo7",0,0,700,500);
  gStyle->SetOptStat(0);
  gStyle->SetOptTitle(0);
  canvas->SetHighLightColor(2);
  canvas->SetFillColor(0);
  canvas->SetBorderMode(0);
  canvas->SetBorderSize(3);
  canvas->SetFrameBorderMode(0);
  canvas->SetFrameBorderSize(0);
  canvas->SetTickx(1);
  canvas->SetTicky(1);
  canvas->SetLeftMargin(0.14);
  canvas->SetRightMargin(0.05);
  canvas->SetBottomMargin(0.15);
  canvas->SetTopMargin(0.05);

  // Creating a new TH1F
  TH1F* S4_PT_0 = new TH1F("S4_PT_0","S4_PT_0",40,0.0,500.0);
  // Content
  S4_PT_0->SetBinContent(0,0.0); // underflow
  S4_PT_0->SetBinContent(1,0.0);
  S4_PT_0->SetBinContent(2,0.0);
  S4_PT_0->SetBinContent(3,0.0);
  S4_PT_0->SetBinContent(4,0.0);
  S4_PT_0->SetBinContent(5,0.00012632001066666758);
  S4_PT_0->SetBinContent(6,0.00012632001066666758);
  S4_PT_0->SetBinContent(7,0.00037896003200000276);
  S4_PT_0->SetBinContent(8,0.00012632001066666758);
  S4_PT_0->SetBinContent(9,0.00037896003200000276);
  S4_PT_0->SetBinContent(10,0.00025264002133333516);
  S4_PT_0->SetBinContent(11,0.00037896003200000276);
  S4_PT_0->SetBinContent(12,0.00025264002133333516);
  S4_PT_0->SetBinContent(13,0.0006316000533333379);
  S4_PT_0->SetBinContent(14,0.0007579200640000055);
  S4_PT_0->SetBinContent(15,0.0006316000533333379);
  S4_PT_0->SetBinContent(16,0.0006316000533333379);
  S4_PT_0->SetBinContent(17,0.000884240074666673);
  S4_PT_0->SetBinContent(18,0.0006316000533333379);
  S4_PT_0->SetBinContent(19,0.0016421601386666783);
  S4_PT_0->SetBinContent(20,0.001515840128000011);
  S4_PT_0->SetBinContent(21,0.001515840128000011);
  S4_PT_0->SetBinContent(22,0.0013895201173333433);
  S4_PT_0->SetBinContent(23,0.0018948001600000138);
  S4_PT_0->SetBinContent(24,0.0022737601920000163);
  S4_PT_0->SetBinContent(25,0.002905360245333354);
  S4_PT_0->SetBinContent(26,0.003031680256000022);
  S4_PT_0->SetBinContent(27,0.003031680256000022);
  S4_PT_0->SetBinContent(28,0.0036632803093333602);
  S4_PT_0->SetBinContent(29,0.004673840394666701);
  S4_PT_0->SetBinContent(30,0.0066949605653333815);
  S4_PT_0->SetBinContent(31,0.00416856035200003);
  S4_PT_0->SetBinContent(32,0.005179120437333371);
  S4_PT_0->SetBinContent(33,0.005052800426666703);
  S4_PT_0->SetBinContent(34,0.007579200640000055);
  S4_PT_0->SetBinContent(35,0.007579200640000055);
  S4_PT_0->SetBinContent(36,0.0073265606186667205);
  S4_PT_0->SetBinContent(37,0.008084480682666725);
  S4_PT_0->SetBinContent(38,0.011621440981333416);
  S4_PT_0->SetBinContent(39,0.009221360778666733);
  S4_PT_0->SetBinContent(40,0.010484560885333408);
  S4_PT_0->SetBinContent(41,3.6728803101439995); // overflow
  S4_PT_0->SetEntries(30000);
  // Style
  S4_PT_0->SetLineColor(9);
  S4_PT_0->SetLineStyle(1);
  S4_PT_0->SetLineWidth(1);
  S4_PT_0->SetFillColor(9);
  S4_PT_0->SetFillStyle(1001);

  // Creating a new THStack
  THStack* stack = new THStack("mystack_8","mystack");
  stack->Add(S4_PT_0);
  stack->Draw("");

  // Y axis
  stack->GetYaxis()->SetLabelSize(0.04);
  stack->GetYaxis()->SetLabelOffset(0.005);
  stack->GetYaxis()->SetTitleSize(0.06);
  stack->GetYaxis()->SetTitleFont(22);
  stack->GetYaxis()->SetTitleOffset(1);
  stack->GetYaxis()->SetTitle("Events  ( L_{int} = 10 fb^{-1} )");

  // X axis
  stack->GetXaxis()->SetLabelSize(0.04);
  stack->GetXaxis()->SetLabelOffset(0.005);
  stack->GetXaxis()->SetTitleSize(0.06);
  stack->GetXaxis()->SetTitleFont(22);
  stack->GetXaxis()->SetTitleOffset(1);
  stack->GetXaxis()->SetTitle("p_{T} [ h_{1} ] (GeV/c) ");

  // Finalizing the TCanvas
  canvas->SetLogx(0);
  canvas->SetLogy(1);

  // Saving the image
  canvas->SaveAs("../../HTML/MadAnalysis5job_0/selection_3.png");
  canvas->SaveAs("../../PDF/MadAnalysis5job_0/selection_3.png");
  canvas->SaveAs("../../DVI/MadAnalysis5job_0/selection_3.eps");

}
