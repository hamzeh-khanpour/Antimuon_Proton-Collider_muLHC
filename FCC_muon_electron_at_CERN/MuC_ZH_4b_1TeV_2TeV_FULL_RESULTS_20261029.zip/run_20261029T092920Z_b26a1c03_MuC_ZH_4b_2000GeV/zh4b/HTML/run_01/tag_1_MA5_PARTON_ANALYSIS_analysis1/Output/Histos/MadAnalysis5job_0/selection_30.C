void selection_30()
{

  // ROOT version
  Int_t root_version = gROOT->GetVersionInt();

  // Creating a new TCanvas
  TCanvas* canvas = new TCanvas("canvas_plotflow_tempo61","canvas_plotflow_tempo61",0,0,700,500);
  gStyle->SetOptStat(0);
  gStyle->SetOptTitle(0);
  canvas->SetHighLightColor(2);
  canvas->SetFillColor(0);
  canvas->SetBorderMode(0);
  canvas->SetBorderSize(3);
  canvas->SetFrameBorderMode(0);
  canvas->SetFrameBorderSize(0);
  canvas->SetTickx(1);
  canvas->SetTicky(1);
  canvas->SetLeftMargin(0.14);
  canvas->SetRightMargin(0.05);
  canvas->SetBottomMargin(0.15);
  canvas->SetTopMargin(0.05);

  // Creating a new TH1F
  TH1F* S31_DELTAR_0 = new TH1F("S31_DELTAR_0","S31_DELTAR_0",40,0.0,10.0);
  // Content
  S31_DELTAR_0->SetBinContent(0,0.0); // underflow
  S31_DELTAR_0->SetBinContent(1,1.272926702496001);
  S31_DELTAR_0->SetBinContent(2,2.051689391082664);
  S31_DELTAR_0->SetBinContent(3,0.2731038410204443);
  S31_DELTAR_0->SetBinContent(4,0.08551863574044428);
  S31_DELTAR_0->SetBinContent(5,0.035243267658666304);
  S31_DELTAR_0->SetBinContent(6,0.018442720519111118);
  S31_DELTAR_0->SetBinContent(7,0.010737200302222225);
  S31_DELTAR_0->SetBinContent(8,0.005558080156444446);
  S31_DELTAR_0->SetBinContent(9,0.004042240113777779);
  S31_DELTAR_0->SetBinContent(10,0.002526400071111112);
  S31_DELTAR_0->SetBinContent(11,0.0031580000888888895);
  S31_DELTAR_0->SetBinContent(12,0.004926480138666668);
  S31_DELTAR_0->SetBinContent(13,0.011495120323555558);
  S31_DELTAR_0->SetBinContent(14,0.004168560117333334);
  S31_DELTAR_0->SetBinContent(15,0.001894800053333334);
  S31_DELTAR_0->SetBinContent(16,0.0013895200391111115);
  S31_DELTAR_0->SetBinContent(17,0.0007579200213333336);
  S31_DELTAR_0->SetBinContent(18,0.00025264000711111117);
  S31_DELTAR_0->SetBinContent(19,0.00012632000355555559);
  S31_DELTAR_0->SetBinContent(20,0.00025264000711111117);
  S31_DELTAR_0->SetBinContent(21,0.0005052800142222223);
  S31_DELTAR_0->SetBinContent(22,0.00012632000355555559);
  S31_DELTAR_0->SetBinContent(23,0.00012632000355555559);
  S31_DELTAR_0->SetBinContent(24,0.00012632000355555559);
  S31_DELTAR_0->SetBinContent(25,0.0);
  S31_DELTAR_0->SetBinContent(26,0.0003789600106666668);
  S31_DELTAR_0->SetBinContent(27,0.0);
  S31_DELTAR_0->SetBinContent(28,0.0);
  S31_DELTAR_0->SetBinContent(29,0.0);
  S31_DELTAR_0->SetBinContent(30,0.0);
  S31_DELTAR_0->SetBinContent(31,0.00012632000355555559);
  S31_DELTAR_0->SetBinContent(32,0.0);
  S31_DELTAR_0->SetBinContent(33,0.0);
  S31_DELTAR_0->SetBinContent(34,0.0);
  S31_DELTAR_0->SetBinContent(35,0.0);
  S31_DELTAR_0->SetBinContent(36,0.0);
  S31_DELTAR_0->SetBinContent(37,0.0);
  S31_DELTAR_0->SetBinContent(38,0.0);
  S31_DELTAR_0->SetBinContent(39,0.0);
  S31_DELTAR_0->SetBinContent(40,0.0);
  S31_DELTAR_0->SetBinContent(41,0.0); // overflow
  S31_DELTAR_0->SetEntries(30000);
  // Style
  S31_DELTAR_0->SetLineColor(9);
  S31_DELTAR_0->SetLineStyle(1);
  S31_DELTAR_0->SetLineWidth(1);
  S31_DELTAR_0->SetFillColor(9);
  S31_DELTAR_0->SetFillStyle(1001);

  // Creating a new THStack
  THStack* stack = new THStack("mystack_62","mystack");
  stack->Add(S31_DELTAR_0);
  stack->Draw("");

  // Y axis
  stack->GetYaxis()->SetLabelSize(0.04);
  stack->GetYaxis()->SetLabelOffset(0.005);
  stack->GetYaxis()->SetTitleSize(0.06);
  stack->GetYaxis()->SetTitleFont(22);
  stack->GetYaxis()->SetTitleOffset(1);
  stack->GetYaxis()->SetTitle("Events  ( L_{int} = 10 fb^{-1} )");

  // X axis
  stack->GetXaxis()->SetLabelSize(0.04);
  stack->GetXaxis()->SetLabelOffset(0.005);
  stack->GetXaxis()->SetTitleSize(0.06);
  stack->GetXaxis()->SetTitleFont(22);
  stack->GetXaxis()->SetTitleOffset(1);
  stack->GetXaxis()->SetTitle("#DeltaR [ b_{1}, b~_{2} ] ");

  // Finalizing the TCanvas
  canvas->SetLogx(0);
  canvas->SetLogy(1);

  // Saving the image
  canvas->SaveAs("../../HTML/MadAnalysis5job_0/selection_30.png");
  canvas->SaveAs("../../PDF/MadAnalysis5job_0/selection_30.png");
  canvas->SaveAs("../../DVI/MadAnalysis5job_0/selection_30.eps");

}
