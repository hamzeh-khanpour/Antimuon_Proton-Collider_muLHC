void selection_31()
{

  // ROOT version
  Int_t root_version = gROOT->GetVersionInt();

  // Creating a new TCanvas
  TCanvas* canvas = new TCanvas("canvas_plotflow_tempo63","canvas_plotflow_tempo63",0,0,700,500);
  gStyle->SetOptStat(0);
  gStyle->SetOptTitle(0);
  canvas->SetHighLightColor(2);
  canvas->SetFillColor(0);
  canvas->SetBorderMode(0);
  canvas->SetBorderSize(3);
  canvas->SetFrameBorderMode(0);
  canvas->SetFrameBorderSize(0);
  canvas->SetTickx(1);
  canvas->SetTicky(1);
  canvas->SetLeftMargin(0.14);
  canvas->SetRightMargin(0.05);
  canvas->SetBottomMargin(0.15);
  canvas->SetTopMargin(0.05);

  // Creating a new TH1F
  TH1F* S32_DELTAR_0 = new TH1F("S32_DELTAR_0","S32_DELTAR_0",40,0.0,10.0);
  // Content
  S32_DELTAR_0->SetBinContent(0,0.0); // underflow
  S32_DELTAR_0->SetBinContent(1,1.2722950156675557);
  S32_DELTAR_0->SetBinContent(2,2.052952691947557);
  S32_DELTAR_0->SetBinContent(3,0.2749986367197778);
  S32_DELTAR_0->SetBinContent(4,0.08008686765288876);
  S32_DELTAR_0->SetBinContent(5,0.036506467116222074);
  S32_DELTAR_0->SetBinContent(6,0.018569040228666674);
  S32_DELTAR_0->SetBinContent(7,0.008716080107333338);
  S32_DELTAR_0->SetBinContent(8,0.007579200093333337);
  S32_DELTAR_0->SetBinContent(9,0.006189680076222224);
  S32_DELTAR_0->SetBinContent(10,0.002652720032666668);
  S32_DELTAR_0->SetBinContent(11,0.0032843200404444454);
  S32_DELTAR_0->SetBinContent(12,0.0037896000466666685);
  S32_DELTAR_0->SetBinContent(13,0.011747760144666672);
  S32_DELTAR_0->SetBinContent(14,0.0044212000544444465);
  S32_DELTAR_0->SetBinContent(15,0.0018948000233333343);
  S32_DELTAR_0->SetBinContent(16,0.0011368800140000004);
  S32_DELTAR_0->SetBinContent(17,0.00037896000466666686);
  S32_DELTAR_0->SetBinContent(18,0.0005052800062222225);
  S32_DELTAR_0->SetBinContent(19,0.0007579200093333337);
  S32_DELTAR_0->SetBinContent(20,0.0007579200093333337);
  S32_DELTAR_0->SetBinContent(21,0.00012632000155555562);
  S32_DELTAR_0->SetBinContent(22,0.00012632000155555562);
  S32_DELTAR_0->SetBinContent(23,0.0);
  S32_DELTAR_0->SetBinContent(24,0.0);
  S32_DELTAR_0->SetBinContent(25,0.0);
  S32_DELTAR_0->SetBinContent(26,0.00012632000155555562);
  S32_DELTAR_0->SetBinContent(27,0.0);
  S32_DELTAR_0->SetBinContent(28,0.0);
  S32_DELTAR_0->SetBinContent(29,0.0);
  S32_DELTAR_0->SetBinContent(30,0.0);
  S32_DELTAR_0->SetBinContent(31,0.0);
  S32_DELTAR_0->SetBinContent(32,0.0);
  S32_DELTAR_0->SetBinContent(33,0.0);
  S32_DELTAR_0->SetBinContent(34,0.0);
  S32_DELTAR_0->SetBinContent(35,0.0);
  S32_DELTAR_0->SetBinContent(36,0.0);
  S32_DELTAR_0->SetBinContent(37,0.0);
  S32_DELTAR_0->SetBinContent(38,0.0);
  S32_DELTAR_0->SetBinContent(39,0.0);
  S32_DELTAR_0->SetBinContent(40,0.0);
  S32_DELTAR_0->SetBinContent(41,0.0); // overflow
  S32_DELTAR_0->SetEntries(30000);
  // Style
  S32_DELTAR_0->SetLineColor(9);
  S32_DELTAR_0->SetLineStyle(1);
  S32_DELTAR_0->SetLineWidth(1);
  S32_DELTAR_0->SetFillColor(9);
  S32_DELTAR_0->SetFillStyle(1001);

  // Creating a new THStack
  THStack* stack = new THStack("mystack_64","mystack");
  stack->Add(S32_DELTAR_0);
  stack->Draw("");

  // Y axis
  stack->GetYaxis()->SetLabelSize(0.04);
  stack->GetYaxis()->SetLabelOffset(0.005);
  stack->GetYaxis()->SetTitleSize(0.06);
  stack->GetYaxis()->SetTitleFont(22);
  stack->GetYaxis()->SetTitleOffset(1);
  stack->GetYaxis()->SetTitle("Events  ( L_{int} = 10 fb^{-1} )");

  // X axis
  stack->GetXaxis()->SetLabelSize(0.04);
  stack->GetXaxis()->SetLabelOffset(0.005);
  stack->GetXaxis()->SetTitleSize(0.06);
  stack->GetXaxis()->SetTitleFont(22);
  stack->GetXaxis()->SetTitleOffset(1);
  stack->GetXaxis()->SetTitle("#DeltaR [ b_{2}, b~_{1} ] ");

  // Finalizing the TCanvas
  canvas->SetLogx(0);
  canvas->SetLogy(1);

  // Saving the image
  canvas->SaveAs("../../HTML/MadAnalysis5job_0/selection_31.png");
  canvas->SaveAs("../../PDF/MadAnalysis5job_0/selection_31.png");
  canvas->SaveAs("../../DVI/MadAnalysis5job_0/selection_31.eps");

}
