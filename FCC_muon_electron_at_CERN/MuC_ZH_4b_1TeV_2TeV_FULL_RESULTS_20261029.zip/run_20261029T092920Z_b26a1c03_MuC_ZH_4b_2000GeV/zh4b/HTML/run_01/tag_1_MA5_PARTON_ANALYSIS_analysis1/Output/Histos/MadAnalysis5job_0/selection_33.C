void selection_33()
{

  // ROOT version
  Int_t root_version = gROOT->GetVersionInt();

  // Creating a new TCanvas
  TCanvas* canvas = new TCanvas("canvas_plotflow_tempo67","canvas_plotflow_tempo67",0,0,700,500);
  gStyle->SetOptStat(0);
  gStyle->SetOptTitle(0);
  canvas->SetHighLightColor(2);
  canvas->SetFillColor(0);
  canvas->SetBorderMode(0);
  canvas->SetBorderSize(3);
  canvas->SetFrameBorderMode(0);
  canvas->SetFrameBorderSize(0);
  canvas->SetTickx(1);
  canvas->SetTicky(1);
  canvas->SetLeftMargin(0.14);
  canvas->SetRightMargin(0.05);
  canvas->SetBottomMargin(0.15);
  canvas->SetTopMargin(0.05);

  // Creating a new TH1F
  TH1F* S34_DELTAR_0 = new TH1F("S34_DELTAR_0","S34_DELTAR_0",40,0.0,10.0);
  // Content
  S34_DELTAR_0->SetBinContent(0,0.0); // underflow
  S34_DELTAR_0->SetBinContent(1,0.0);
  S34_DELTAR_0->SetBinContent(2,0.00012632000555555582);
  S34_DELTAR_0->SetBinContent(3,0.0005052800222222233);
  S34_DELTAR_0->SetBinContent(4,0.0012632000555555583);
  S34_DELTAR_0->SetBinContent(5,0.0008842400388888907);
  S34_DELTAR_0->SetBinContent(6,0.0029053601277777836);
  S34_DELTAR_0->SetBinContent(7,0.0029053601277777836);
  S34_DELTAR_0->SetBinContent(8,0.005937040261111123);
  S34_DELTAR_0->SetBinContent(9,0.010989840483333357);
  S34_DELTAR_0->SetBinContent(10,0.024127121061111163);
  S34_DELTAR_0->SetBinContent(11,0.08716080383333352);
  S34_DELTAR_0->SetBinContent(12,0.5462076906888894);
  S34_DELTAR_0->SetBinContent(13,2.0724060911444524);
  S34_DELTAR_0->SetBinContent(14,0.6171993604777709);
  S34_DELTAR_0->SetBinContent(15,0.2240916765222221);
  S34_DELTAR_0->SetBinContent(16,0.09676110425555488);
  S34_DELTAR_0->SetBinContent(17,0.044717268633332835);
  S34_DELTAR_0->SetBinContent(18,0.02299024101111116);
  S34_DELTAR_0->SetBinContent(19,0.012253040538888914);
  S34_DELTAR_0->SetBinContent(20,0.007326560322222238);
  S34_DELTAR_0->SetBinContent(21,0.0030316801333333397);
  S34_DELTAR_0->SetBinContent(22,0.002779040122222228);
  S34_DELTAR_0->SetBinContent(23,0.001389520061111114);
  S34_DELTAR_0->SetBinContent(24,0.0008842400388888907);
  S34_DELTAR_0->SetBinContent(25,0.00025264001111111164);
  S34_DELTAR_0->SetBinContent(26,0.00025264001111111164);
  S34_DELTAR_0->SetBinContent(27,0.00012632000555555582);
  S34_DELTAR_0->SetBinContent(28,0.0);
  S34_DELTAR_0->SetBinContent(29,0.0);
  S34_DELTAR_0->SetBinContent(30,0.0);
  S34_DELTAR_0->SetBinContent(31,0.00012632000555555582);
  S34_DELTAR_0->SetBinContent(32,0.0);
  S34_DELTAR_0->SetBinContent(33,0.0);
  S34_DELTAR_0->SetBinContent(34,0.0);
  S34_DELTAR_0->SetBinContent(35,0.0);
  S34_DELTAR_0->SetBinContent(36,0.0);
  S34_DELTAR_0->SetBinContent(37,0.0);
  S34_DELTAR_0->SetBinContent(38,0.0);
  S34_DELTAR_0->SetBinContent(39,0.0);
  S34_DELTAR_0->SetBinContent(40,0.0);
  S34_DELTAR_0->SetBinContent(41,0.0); // overflow
  S34_DELTAR_0->SetEntries(30000);
  // Style
  S34_DELTAR_0->SetLineColor(9);
  S34_DELTAR_0->SetLineStyle(1);
  S34_DELTAR_0->SetLineWidth(1);
  S34_DELTAR_0->SetFillColor(9);
  S34_DELTAR_0->SetFillStyle(1001);

  // Creating a new THStack
  THStack* stack = new THStack("mystack_68","mystack");
  stack->Add(S34_DELTAR_0);
  stack->Draw("");

  // Y axis
  stack->GetYaxis()->SetLabelSize(0.04);
  stack->GetYaxis()->SetLabelOffset(0.005);
  stack->GetYaxis()->SetTitleSize(0.06);
  stack->GetYaxis()->SetTitleFont(22);
  stack->GetYaxis()->SetTitleOffset(1);
  stack->GetYaxis()->SetTitle("Events  ( L_{int} = 10 fb^{-1} )");

  // X axis
  stack->GetXaxis()->SetLabelSize(0.04);
  stack->GetXaxis()->SetLabelOffset(0.005);
  stack->GetXaxis()->SetTitleSize(0.06);
  stack->GetXaxis()->SetTitleFont(22);
  stack->GetXaxis()->SetTitleOffset(1);
  stack->GetXaxis()->SetTitle("#DeltaR [ b~_{1}, b~_{2} ] ");

  // Finalizing the TCanvas
  canvas->SetLogx(0);
  canvas->SetLogy(1);

  // Saving the image
  canvas->SaveAs("../../HTML/MadAnalysis5job_0/selection_33.png");
  canvas->SaveAs("../../PDF/MadAnalysis5job_0/selection_33.png");
  canvas->SaveAs("../../DVI/MadAnalysis5job_0/selection_33.eps");

}
