void selection_9()
{

  // ROOT version
  Int_t root_version = gROOT->GetVersionInt();

  // Creating a new TCanvas
  TCanvas* canvas = new TCanvas("canvas_plotflow_tempo19","canvas_plotflow_tempo19",0,0,700,500);
  gStyle->SetOptStat(0);
  gStyle->SetOptTitle(0);
  canvas->SetHighLightColor(2);
  canvas->SetFillColor(0);
  canvas->SetBorderMode(0);
  canvas->SetBorderSize(3);
  canvas->SetFrameBorderMode(0);
  canvas->SetFrameBorderSize(0);
  canvas->SetTickx(1);
  canvas->SetTicky(1);
  canvas->SetLeftMargin(0.14);
  canvas->SetRightMargin(0.05);
  canvas->SetBottomMargin(0.15);
  canvas->SetTopMargin(0.05);

  // Creating a new TH1F
  TH1F* S10_PT_0 = new TH1F("S10_PT_0","S10_PT_0",40,0.0,500.0);
  // Content
  S10_PT_0->SetBinContent(0,0.0); // underflow
  S10_PT_0->SetBinContent(1,0.0);
  S10_PT_0->SetBinContent(2,0.0007579200226666674);
  S10_PT_0->SetBinContent(3,0.0007579200226666674);
  S10_PT_0->SetBinContent(4,0.0016421600491111125);
  S10_PT_0->SetBinContent(5,0.0020211200604444463);
  S10_PT_0->SetBinContent(6,0.00480016014355556);
  S10_PT_0->SetBinContent(7,0.00480016014355556);
  S10_PT_0->SetBinContent(8,0.00720024021533334);
  S10_PT_0->SetBinContent(9,0.009852960294666676);
  S10_PT_0->SetBinContent(10,0.009726640290888898);
  S10_PT_0->SetBinContent(11,0.013389920400444457);
  S10_PT_0->SetBinContent(12,0.015284720457111125);
  S10_PT_0->SetBinContent(13,0.016547920494888905);
  S10_PT_0->SetBinContent(14,0.021853360653555576);
  S10_PT_0->SetBinContent(15,0.018948000566666685);
  S10_PT_0->SetBinContent(16,0.02223232066488891);
  S10_PT_0->SetBinContent(17,0.027032480808444472);
  S10_PT_0->SetBinContent(18,0.030695760918000026);
  S10_PT_0->SetBinContent(19,0.03006416089911114);
  S10_PT_0->SetBinContent(20,0.03423273435711154);
  S10_PT_0->SetBinContent(21,0.036759134432667095);
  S10_PT_0->SetBinContent(22,0.03827496781133356);
  S10_PT_0->SetBinContent(23,0.04080136788688913);
  S10_PT_0->SetBinContent(24,0.03903286783399964);
  S10_PT_0->SetBinContent(25,0.0473700014166667);
  S10_PT_0->SetBinContent(26,0.04850686811733298);
  S10_PT_0->SetBinContent(27,0.04699103473866651);
  S10_PT_0->SetBinContent(28,0.05191753488600044);
  S10_PT_0->SetBinContent(29,0.05355966826844409);
  S10_PT_0->SetBinContent(30,0.057222968378000255);
  S10_PT_0->SetBinContent(31,0.06518113528266713);
  S10_PT_0->SetBinContent(32,0.06833913537711157);
  S10_PT_0->SetBinContent(33,0.05937040177555561);
  S10_PT_0->SetBinContent(34,0.057601935056000454);
  S10_PT_0->SetBinContent(35,0.0659390353053332);
  S10_PT_0->SetBinContent(36,0.06947600207777785);
  S10_PT_0->SetBinContent(37,0.07288663551311098);
  S10_PT_0->SetBinContent(38,0.07149713547155602);
  S10_PT_0->SetBinContent(39,0.07566566892955523);
  S10_PT_0->SetBinContent(40,0.0716234354753332);
  S10_PT_0->SetBinContent(41,2.3797424045028865); // overflow
  S10_PT_0->SetEntries(30000);
  // Style
  S10_PT_0->SetLineColor(9);
  S10_PT_0->SetLineStyle(1);
  S10_PT_0->SetLineWidth(1);
  S10_PT_0->SetFillColor(9);
  S10_PT_0->SetFillStyle(1001);

  // Creating a new THStack
  THStack* stack = new THStack("mystack_20","mystack");
  stack->Add(S10_PT_0);
  stack->Draw("");

  // Y axis
  stack->GetYaxis()->SetLabelSize(0.04);
  stack->GetYaxis()->SetLabelOffset(0.005);
  stack->GetYaxis()->SetTitleSize(0.06);
  stack->GetYaxis()->SetTitleFont(22);
  stack->GetYaxis()->SetTitleOffset(1);
  stack->GetYaxis()->SetTitle("Events  ( L_{int} = 10 fb^{-1} )");

  // X axis
  stack->GetXaxis()->SetLabelSize(0.04);
  stack->GetXaxis()->SetLabelOffset(0.005);
  stack->GetXaxis()->SetTitleSize(0.06);
  stack->GetXaxis()->SetTitleFont(22);
  stack->GetXaxis()->SetTitleOffset(1);
  stack->GetXaxis()->SetTitle("p_{T} [ b_{1} ] (GeV/c) ");

  // Finalizing the TCanvas
  canvas->SetLogx(0);
  canvas->SetLogy(1);

  // Saving the image
  canvas->SaveAs("../../HTML/MadAnalysis5job_0/selection_9.png");
  canvas->SaveAs("../../PDF/MadAnalysis5job_0/selection_9.png");
  canvas->SaveAs("../../DVI/MadAnalysis5job_0/selection_9.eps");

}
