Original MadGraph5_aMC@NLO Feynman-diagram graphics for four FCC-mue processes.

CC_H:  e- mu+ > ve vm~ h QCD=0
CC_HH: e- mu+ > ve vm~ h h QCD=0
NC_H:  e- mu+ > e- mu+ h QCD=0
NC_HH: e- mu+ > e- mu+ h h QCD=0

Source: process archives under templates/ from the FCCmue Higgs PolScan CERN package.
These are MadGraph-exported diagrams; the full 2->3 or 2->4 tree amplitudes
may contain more graphs than the illustrative VBF subtopologies.
The 1-TeV/2-TeV beam energies and beam polarization affect the matrix-element
evaluation and cross section, not which diagrams are generated.
