# FCC-μ⁺e⁻ Higgs-pair study
## Physics, CERN run commands and backup inventory

**11 November 2026** · Hamzeh Khanpour, Krzysztof Piotrzkowski, Richard Ruiz and Piotr Kotko

### 1. Work completed

| Step | Verified outcome |
|---|---|
| Historical SM campaign | Archived the 48 stable-H and stable-HH configurations at 1 and 2 TeV, with CC and NC channels and six μ⁺ polarizations. The continuity bundle also preserves the earlier resonant and complete four-bottom studies, associated-Higgs results, μ⁺μ⁻ comparisons, and original diagrams. |
| Model source | Located ATLAS `HHVBF_UFO` on CVMFS, copied it from CERN, and preserved its source archive and SHA-256. Audited the parameters, vertices and generation orders. |
| Model validation | Built MadGraph5_aMC@NLO 3.6.4 CC and NC templates. Fixed-phase-space matrix-element comparisons verified the SM limit and the quadratic response to the adjustable trilinear coupling. |
| SM closure | CERN cluster `13387443` returned four diagnostic archives after a MadEvent runtime-card error. The corrected v1.1 package contains four successful local MadEvent runs and closure comparisons against the original CERN rates. |
| Unpolarized κ₃ scan | CERN cluster `13388388` supplied 88 new successful 30,000-event runs. Four validated SM points were reused. The original three-file rate export gives 92 channel rates and 46 CC+NC sums. |
| Polarization and κ₃ scan | The production package defines 460 new runs and reuses the 92 unpolarized rates. The available fit output has 138 grid points per channel at each energy, consistent with the full 552 channel-rate grid and 276 CC+NC sums. The figures, fit coefficients, covariance matrices and near-limit predictions are archived here. The original polarized collector report and job-level LHE archives are needed to verify per-job completion and event counts independently. |

Richard’s stable-HH rate plots are available for the SM polarization dependence, the unpolarized coupling dependence and the joint dependence on polarization and coupling. The two-dimensional maps and three-dimensional surfaces show an interference minimum near κ₃ ≈ 1.56 at 1 TeV and 1.64 at 2 TeV. Positive μ⁺ polarization primarily raises the CC rate. Richard’s new HH→4b event generation, truth reconstruction and decay-plane observables, matched signal/background selection study and proposed HHH extension remain outstanding. Earlier four-bottom studies are preserved under the historical settings in the continuity archive.

### 2. ATLAS UFO, processes and run settings

CVMFS entry point on lxplus

```text
/cvmfs/atlas.cern.ch/repo/sw/Generators/madgraph/models/latest/HHVBF_UFO
```

Resolved source path and archived source SHA-256

```text
/cvmfs/atlas.cern.ch/repo/sw/Generators/madgraph/models/latest/Higgs/HHVBF_UFO
afe36ce9cc12008247d9147aeb93cbecfe7696f073f0b6725d2a649b70eb9599
```

| UFO card entry | Meaning | Runtime setting |
|---|---|---|
| `BLOCK NEW`, index 1, `CV` | Single-Higgs gauge coupling modifier | 1 |
| `BLOCK NEW`, index 2, `C2V` | Double-Higgs gauge coupling modifier | 1 |
| `BLOCK NEW`, index 3, `C3` | Higgs trilinear modifier, κ₃ = λ₃/λ₃^SM | 1 for SM closure, varied in the scans |

The trilinear term is −κ₃ m_H² h³/(2v), giving the vertex −iκ₃ 3m_H²/v. The audited model uses `GC_89 = -6*C3*complex(0,1)*lam*vev`. The gauge–Higgs terms relevant here are (2C_V h/v + C_2V h²/v²)(m_W² W⁺W⁻ + ½m_Z² Zμ Z^μ), with Lorentz indices contracted. The FCCmue copy adds an import restriction using distinct nonunit placeholders to keep the three modifiers editable. The runtime cards assign the physical values. References for the coupling convention and ATLAS implementation are [Bishara, Contino and Rojo, arXiv:1611.03860, Eqs. 2–3](https://arxiv.org/abs/1611.03860) and [ATLAS, arXiv:2301.03212, Fig. 2](https://arxiv.org/abs/2301.03212).

MadGraph commands for the two exports, with the relevant `generate` line used separately for each

```text
set gauge unitary
import model HHVBF_UFO_FCCmue-fccmue
generate e- mu+ > ve vm~ h h QCD=0 QED=4 CV=2 C2V=1 C3=1
generate e- mu+ > e- mu+ h h QCD=0 QED=4 CV=2 C2V=1 C3=1
```

CC is e⁻μ⁺ → νₑν̄μHH and NC is e⁻μ⁺ → e⁻μ⁺HH. Each contains four tree diagrams, with contact, t/u exchange and trilinear contributions evaluated coherently. The displayed coupling orders are generation bounds. CC+NC sums the rates for the two distinct external states. Each process template preserves its full intra-channel interference.

| √s | Beam 1, e⁻ | Beam 2, μ⁺ | Polarization settings |
|---:|---:|---:|---|
| 1 TeV | 125 GeV | 2000 GeV | `polbeam1 = 0`, `polbeam2 = 0, 20, 40, 60, 80, 100` |
| 2 TeV | 200 GeV | 5000 GeV | `polbeam1 = 0`, `polbeam2 = 0, 20, 40, 60, 80, 100` |

The listed run-card polarizations are percentages. The +100% point is the ideal positive-helicity antimuon benchmark. These are inclusive LO stable-Higgs cross sections with beam PDFs off (`lpp1=lpp2=0`), generation cuts disabled and no branching-ratio factors. The fixed renormalization scale is 125 GeV. The matched inputs include m_H = 125 GeV, M_Z = 91.188 GeV, G_F = 1.16639×10⁻⁵ GeV⁻², α_EW⁻¹ = 132.507, derived M_W = 80.41900244576 GeV and the historical Higgs width 0.006382339 GeV. The exact cards and source benchmark IDs are embedded in the run packages. Some earlier four-bottom workflows used μ⁺ first in the process definition and consequently assigned its polarization to `polbeam1`. Those workflows also used their own cuts and branching-ratio conventions.

### 3. SM closure and grid analysis

| √s | Channel | Corrected MadEvent run (fb) | Historical CERN SM (fb) | Pull |
|---:|:---:|---:|---:|---:|
| 1 TeV | CC | 0.0742573 ± 0.0001341 | 0.0743838 | −0.684 |
| 1 TeV | NC | 0.00963590 ± 0.00001504 | 0.00962012 | +0.754 |
| 2 TeV | CC | 0.419742 ± 0.000655 | 0.418510 | +1.329 |
| 2 TeV | NC | 0.0547123 ± 0.0000803 | 0.0547116 | +0.006 |

The reported uncertainties are MC integration errors. The pulls use the historical and corrected errors added in quadrature. The largest difference is 1.33σ and about 0.30%. The failed v1 collector reported a missing seed in the returned artifacts. The underlying MadEvent exception was the absent mass entry for particle 24 in the runtime card. v1.1 added the evaluated W mass to that card and validated the four LHE results. Its CERN submission is unconfirmed. The closure checks compatibility at the archived settings. Independent integration-convergence certification of the historical rates remains outstanding.

The 23 coupling values used at both energies are

```text
-10, -5, -3, -2, -1, 0, 0.1, 0.5, 0.7, 0.8, 0.9, 1,
1.1, 1.2, 1.3, 1.5, 1.9, 2, 3, 4, 5, 7, 10
```

With C_V = C_2V = 1, the tree-level amplitude is linear in κ₃, so the unpolarized fits are quadratic. The joint fits use σ(κ₃,p) = A + Bκ₃ + Cκ₃² + p(D + Eκ₃ + Fκ₃²), with p = P_μ⁺/100 for polarization entered in percent. The CC helicity prediction σ_CC(κ₃,p) ≈ (1+p)σ_CC(κ₃,0) and the linear polarization interpolation were checked against the scan. The near-limit figures evaluate the fit at −1.35, −1.2, −0.71, −0.5, 5.8, 6.1, 6.37 and 7.2. The shaded intervals and lines reference LHC observed one-parameter bounds. FCC-μ⁺e⁻ coupling sensitivity still requires luminosity, efficiencies and backgrounds. [ATLAS+CMS, arXiv:2602.23991](https://arxiv.org/abs/2602.23991) · [ATLAS, arXiv:2406.09971](https://arxiv.org/abs/2406.09971) · [CMS, arXiv:2510.07527](https://arxiv.org/abs/2510.07527)

### 4. Transfer and backup inventory

| Original file or directory | Transfer evidence and backup location |
|---|---|
| `HHVBF_UFO_source.tar.gz` | CERN source download, archived in `01_model/`. |
| `FCCmue_HHVBF_ModelValidation_v1.zip` | Uploaded to lxplus and used to prepare CC and NC templates. Original ZIP in `02_run_packages/`. |
| `FCCmue_HHVBF_SMClosure_v1.zip` | Uploaded to lxplus and used for four v1 closure jobs. Original ZIP in `02_run_packages/`. |
| `FCCmue_HHVBF_SMClosure_v1_1.zip` | Corrected package with the successful local closure results, including four LHE archives. Original ZIP in `02_run_packages/`. |
| `FCCmue_HHVBF_Kappa3Scan_P000_v1.zip` | Uploaded to lxplus and used for the unpolarized scan. Original ZIP in `02_run_packages/`. |
| `FCCmue_HHVBF_Kappa3PolarizationScan_v1.zip` | Uploaded to lxplus for the joint scan. Original ZIP in `02_run_packages/`. |
| `smclosure_v1_E1_CC_HH_P000.tar.gz`, `smclosure_v1_E1_NC_HH_P000.tar.gz`, `smclosure_v1_E2_CC_HH_P000.tar.gz`, `smclosure_v1_E2_NC_HH_P000.tar.gz` | Four original failed job returns downloaded from CERN. Preserved in `03_cern_downloads/`. |
| `FCCmue_Kappa3Scan_cross_sections.zip` | Original CERN rate export with `scan_points.csv`, `scan_totals.csv` and `scan_report.json`. Preserved in `03_cern_downloads/`. |
| `FCCmue_HHVBF_Kappa3Scan_P000_v1/` | The whole CERN directory was copied to Windows Downloads with `scp -r`. The attached rate ZIP contains the numerical output. Recover the raw folder from Windows or CERN to add the 88 job-level returns to this backup. |
| `FCCmue_Kappa3Polarization_local_plot.zip` | A 59 KB CERN download to Windows is confirmed. Its original ZIP is absent here. Recover it to preserve the polarized point tables and collector JSON along with the plotting code. |
| `FCCmue_Kappa3Polarization_CERN_full.zip` | Name supplied for a full polarized archive. Creation and transfer are unconfirmed. If required, build and download it using section 7. |
| `FCCmue_Kappa3Scan_CERN_results.zip` | Name supplied for a ZIP of the unpolarized run folder. The directory copy is confirmed. ZIP creation and transfer are unconfirmed. |
| `FCCmue_Kappa3Scan_CERN_analysis.zip` and separately supplied unpolarized plots | Local analysis of the CERN rate export, archived in `04_analysis/`. |
| Six polarized figures, each PDF and PNG, `surface_fits.json` and `near_limit_predictions.csv` | Available local outputs, archived in `04_analysis/polarized/`. |
| `FCCmue_Continuity_Source_Bundle_2026-11-10.zip`, handoff and continuation audit | Historical inputs, cards, results, diagrams, Richard’s email and whiteboard photos in `05_historical/`. The source bundle retains its original bytes and canonical filename. |

`SHA256SUMS` covers every payload in this backup. Verify it from the extracted backup directory with `sha256sum -c SHA256SUMS`. Windows can verify individual files with `Get-FileHash -Algorithm SHA256 PATH`. Verify package-internal manifests from inside their own extracted directories.

The historical continuity ZIP contains these nine earlier archives under `sources/`, plus standalone reports and source data. Their individual lxplus transfer histories are not established by the current HHVBF run logs.

- `FCCmue_Higgs_Physics_Kickoff_2026_COMPLETE.zip`
- `FCCmue_Higgs_PolScan_v1_1_CERN_PTL_FIX.zip`
- `FCCmue_Higgs_PolScan_full_exact_REVIEW.zip`
- `FCCmue_Higgs_Polarization_Figures_v2_Source_Data.zip`
- `FCCmue_Original_MadGraph_Diagrams_Verified_All4.zip`
- `FCCmue_Higgs_Physics_Research_Handout_20pages_COMPLETE.zip`
- `FCC_ue_MuC_1TeV_2TeV_80Pol_Review_20261025.zip`
- `FCC_ue_NC_ThreeProcess_Validation_Package_20261027.zip`
- `MuC_ZH_4b_1TeV_2TeV_FULL_RESULTS_20261029.zip`

### 5. Source transfer and CERN submission commands

The following archive creation reproduces the directory layout of the source capture. Preserve the original archive and recorded SHA for exact provenance because CVMFS `latest` may change.

```bash
FCCMUE_UFO_REAL=$(readlink -f /cvmfs/atlas.cern.ch/repo/sw/Generators/madgraph/models/latest/HHVBF_UFO)
FCCMUE_AUDIT_DIR=$(mktemp -d "$HOME/FCCmue_HHVBF_Audit_XXXXXXXX")
tar -C "$FCCMUE_UFO_REAL" -czf "$FCCMUE_AUDIT_DIR/HHVBF_UFO_source.tar.gz" .
sha256sum "$FCCMUE_AUDIT_DIR/HHVBF_UFO_source.tar.gz"
```

Windows PowerShell commands for the source download, each of the four confirmed uploads and login. These use the original Downloads location. If you extract the backup elsewhere, point the local source paths at `02_run_packages`.

```powershell
$downloads = "$env:USERPROFILE\Downloads"
$cern = "hakhanpo@lxplus.cern.ch"
$afs = "/afs/cern.ch/user/h/hakhanpo"

scp "${cern}:$afs/FCCmue_HHVBF_Audit_CKKTpvkp/HHVBF_UFO_source.tar.gz" "$downloads"
scp -o ServerAliveInterval=15 "$downloads\FCCmue_HHVBF_ModelValidation_v1.zip" "${cern}:"
scp "$downloads\FCCmue_HHVBF_SMClosure_v1.zip" "${cern}:"
scp "$downloads\FCCmue_HHVBF_Kappa3Scan_P000_v1.zip" "${cern}:"
scp "$downloads\FCCmue_HHVBF_Kappa3PolarizationScan_v1.zip" "${cern}:"
ssh -o ServerAliveInterval=15 "$cern"
```

On lxplus, prepare the common model templates

```bash
unzip -n "$HOME/FCCmue_HHVBF_ModelValidation_v1.zip" -d "$HOME"
cd "$HOME/FCCmue_HHVBF_ModelValidation_v1"
python3 audit_ufo.py --out source_audit_CERN.json
python3 prepare_model.py \
  --mg5 /eos/user/h/hakhanpo/MG5_aMC_v3_6_4 \
  --output "$HOME/FCCmue_HHVBF_ModelValidation_v1/prepared" \
  --format madevent
```

The original CERN closure submission ran as follows. The v1 submission is historical. The corrected v1.1 ZIP already includes the four successful comparison runs. Its README records the corresponding optional corrected CERN procedure.

```bash
cd "$HOME"
unzip -n FCCmue_HHVBF_SMClosure_v1.zip
cd "$HOME/FCCmue_HHVBF_SMClosure_v1"
sha256sum -c SHA256SUMS
python3 closure.py prepare \
  --prepared "$HOME/FCCmue_HHVBF_ModelValidation_v1/prepared"
python3 closure.py submit-file
condor_submit -dry-run submissions/closure.classad submissions/closure.sub
condor_submit submissions/closure.sub
condor_q "$USER"
# After the queue drained
python3 closure.py collect
cat reports/closure_report.json
```

Run sequence for each coupling scan. Set `campaign` to the relevant package stem and use the same commands. The dry run should show 88 jobs for the unpolarized scan and 460 for the polarized scan. This is the archived submission recipe. For completed campaigns, use collection or file recovery directly.

```bash
campaign=FCCmue_HHVBF_Kappa3Scan_P000_v1
# For the joint grid, use campaign=FCCmue_HHVBF_Kappa3PolarizationScan_v1
cd "$HOME" &&
unzip -n "$campaign.zip" &&
cd "$HOME/$campaign" &&
sha256sum -c SHA256SUMS &&
python3 scan.py prepare &&
python3 scan.py submit-file &&
condor_submit -dry-run submissions/main.classad submissions/main.sub

condor_submit submissions/main.sub
condor_q "$USER"
# After the queue drained
python3 scan.py collect
# Optional plotting on lxplus after a COMPLETE report
python3 plot_scan.py
```

Use the actual scan directory before running `scan.py` or `plot_scan.py`. Each collector writes `reports/scan_points.csv`, `reports/scan_totals.csv` and `reports/scan_report.json`. The polarized collector checks seeds, event counts, couplings and polarization in the returned LHE artifacts. Its README records selective retry commands for an incomplete report.

### 6. Compact exports and downloads

Run on lxplus when a compact export needs to be made again. An existing valid export can be copied directly with `scp`.

```bash
cd "$HOME/FCCmue_HHVBF_Kappa3Scan_P000_v1"
zip -j "$HOME/FCCmue_Kappa3Scan_cross_sections.zip" \
  reports/scan_points.csv reports/scan_totals.csv reports/scan_report.json

cd "$HOME/FCCmue_HHVBF_Kappa3PolarizationScan_v1"
zip "$HOME/FCCmue_Kappa3Polarization_local_plot.zip" \
  plot_scan.py scan_grid.py scan_results.py card_utils.py \
  reports/scan_points.csv reports/scan_totals.csv reports/scan_report.json
```

Windows PowerShell download commands with the original names. The unpolarized folder copy includes the full directory, with the job-level results and submitted configuration.

```powershell
$downloads = "$env:USERPROFILE\Downloads"
$cern = "hakhanpo@lxplus.cern.ch"
$afs = "/afs/cern.ch/user/h/hakhanpo"

scp "${cern}:$afs/FCCmue_HHVBF_SMClosure_v1/results/smclosure_v1_*.tar.gz" "$downloads"
scp "${cern}:$afs/FCCmue_Kappa3Scan_cross_sections.zip" "$downloads"
scp -r "${cern}:$afs/FCCmue_HHVBF_Kappa3Scan_P000_v1" "$downloads"
scp "${cern}:$afs/FCCmue_Kappa3Polarization_local_plot.zip" "$downloads"
```

For local plotting of the polarized grid, open the previously extracted folder or expand the ZIP into a fresh folder. The Windows transcript showed that `py -3` was unavailable. Use the Python installation exposed as `python`.

```powershell
$plotDir = Join-Path $downloads "FCCmue_Kappa3Polarization_local_plot"
Expand-Archive "$downloads\FCCmue_Kappa3Polarization_local_plot.zip" -DestinationPath "$plotDir"
Set-Location "$plotDir"
python --version
python .\plot_scan.py
```

The plotting dependencies are NumPy and Matplotlib. The plotting script in the unpolarized analysis ZIP can be run locally from its extracted directory as `python .\plot_scan.py --report .\tables\scan_report.json --outdir .\plots`.

### 7. Optional full CERN backups without rerunning any jobs

On lxplus, after collection has completed, archive the existing directories. `-0` stores already compressed LHE/job archives directly. Use a fresh archive name if one of the ZIP files already exists and needs a new snapshot. These are additional backups to recover the original run files.

```bash
cd "$HOME"
zip -0 -r FCCmue_Kappa3Scan_CERN_results.zip FCCmue_HHVBF_Kappa3Scan_P000_v1
zip -0 -r FCCmue_Kappa3Polarization_CERN_full.zip FCCmue_HHVBF_Kappa3PolarizationScan_v1
sha256sum FCCmue_Kappa3Scan_CERN_results.zip FCCmue_Kappa3Polarization_CERN_full.zip
```

In Windows PowerShell

```powershell
$downloads = "$env:USERPROFILE\Downloads"
$cern = "hakhanpo@lxplus.cern.ch"
$afs = "/afs/cern.ch/user/h/hakhanpo"

scp "${cern}:$afs/FCCmue_Kappa3Scan_CERN_results.zip" "$downloads"
scp "${cern}:$afs/FCCmue_Kappa3Polarization_CERN_full.zip" "$downloads"
Get-FileHash -Algorithm SHA256 "$downloads\FCCmue_Kappa3Scan_CERN_results.zip"
Get-FileHash -Algorithm SHA256 "$downloads\FCCmue_Kappa3Polarization_CERN_full.zip"
```

If the full unpolarized directory is already in Windows Downloads, you can also ZIP it locally from there. Add the original polarized plotting ZIP and the two complete run directories or ZIPs to the project backup when available.
