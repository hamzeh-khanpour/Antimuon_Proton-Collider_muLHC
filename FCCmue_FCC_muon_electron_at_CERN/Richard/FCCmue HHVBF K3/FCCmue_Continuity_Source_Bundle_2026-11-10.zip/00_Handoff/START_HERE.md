# START HERE — FCC-μe Higgs Physics collaboration continuation

This bundle is a curated research handoff from the long ChatGPT project conversation through **10 November 2026**. It retains the completed calculations plus the **new Richard Ruiz request**, but it **does not** contain a newly completed anomalous-coupling simulation.

## New ChatGPT chat: suggested workflow

1. Start a **new conversation within the existing CERN kick-off Meeting LHeC/uLHC project**.
2. Upload **`FCCmue_Project_Handoff_2026-11-10.md`** (separately available) and this source ZIP, or add them to the Project files area.
3. Paste the prompt from Section H of the handoff.
4. Ask the assistant to verify source material inside `data/`, `diagrams/` and `sources/` *before* rewriting cross sections or Feynman diagrams.
5. Continue the work with Richard's **κ₃ × muon-polarization coupling scan and HH→4b event-level analysis**. Do not repeat the old SM 48 runs unless needed as a reproducibility pilot.

## Bundle directory structure

- `00_Handoff/` — portable context, Richard's email as text, and the new-chat opening message.
- `data/` — original source-derived 48-row cross-section CSV and historical 4b CSV.
- `diagrams/` — original vector MG5 matrices for CC/NC single/double Higgs.
- `meeting_photos/` — three user-supplied whiteboard images from 10 Nov 2026.
- `sources/` — intact previous CERN calculation/report/plot/script ZIPs and PDFs, plus 48-slide AGH Beamer presentation and 20-page research handout.

## Scientific caution

The 48 inclusive LO CERN jobs succeeded computationally, but were originally labeled `COMPLETED_UNVALIDATED` for independent scientific convergence. The older decay calculation used `BR(H→bb)=0.844640`. The NC full-4b vs bbH consistency issue is unresolved. No κ₃ variation, Richard's 4b angular scan, or HHH cross sections have been generated yet.

## Keep original CERN files

The bundle contains the selected **review/summary archives** and presentation packages. It may not include full original LHE events and heavy external MG5 working directories. Preserve these on CERN EOS and AFS until the new project confirms the event-level files have been copied or regenerated.
