# FCC-μ⁺e⁻ Higgs-pair trilinear-coupling scan

The package implements Richard’s cross-section scan at fixed, unpolarized
beams. It reuses the validated HHVBF process exports and the four SM rates
from `FCCmue_HHVBF_SMClosure_v1_1`. The 2D polarization and coupling scan
is a subsequent calculation.

| √s | Beam 1 e⁻ | Beam 2 μ⁺ | Channels |
|---:|---:|---:|---|
| 1 TeV | 125 GeV | 2000 GeV | CC and NC |
| 2 TeV | 200 GeV | 5000 GeV | CC and NC |

The 22 new coupling values are

```text
-10, -5, -3, -2, -1, 0, 0.1, 0.5, 0.7, 0.8, 0.9,
1.1, 1.2, 1.3, 1.5, 1.9, 2, 3, 4, 5, 7, 10
```

The production grid contains **88 jobs** with 30,000 requested unweighted
events and an independent seed per job. The four validated κ₃=1 rates are
loaded by `collect` from `reference/SM_closure_report.json`. `scan.py grid`
prints all job IDs, coupling values and seeds.

## Prepare and submit at CERN

From Windows PowerShell, copy the downloaded ZIP to the CERN home directory.

```powershell
scp "$env:USERPROFILE\Downloads\FCCmue_HHVBF_Kappa3Scan_P000_v1.zip" hakhanpo@lxplus.cern.ch:
```

On lxplus, unpack into the AFS home directory and snapshot the existing
MadEvent exports. `prepare` defaults to the path shown below.

```bash
cd "$HOME"
unzip -n FCCmue_HHVBF_Kappa3Scan_P000_v1.zip
cd "$HOME/FCCmue_HHVBF_Kappa3Scan_P000_v1"
sha256sum -c SHA256SUMS
python3 scan.py prepare \
  --prepared "$HOME/FCCmue_HHVBF_ModelValidation_v1/prepared"
python3 scan.py submit-file
condor_submit -dry-run submissions/main.classad submissions/main.sub
```

The dry run should report 88 jobs. Then submit the batch once and record
the cluster ID printed by Condor.

```bash
condor_submit submissions/main.sub
condor_q "$USER"
```

The submission uses one CPU per job, 4 GB memory and 8 GB scratch, with
the `tomorrow` flavour. It transfers the verified process template and cards
into worker scratch. It writes each returned archive under `results/main/`
and each job log under `condor_logs/main/`, with the Condor cluster ID in
the filename. A full set of returned LHE archives is expected to use about
0.35–0.4 GB, based on the local verification runs.

### If the earlier CERN process exports are unavailable

The model and original preparation helper are included under `model_setup/`.
Use the existing CERN MadGraph5_aMC@NLO **3.6.4** installation and a fresh
output directory. Replace the path below if the installation was moved.

```bash
python3 model_setup/prepare_model.py \
  --mg5 /eos/user/h/hakhanpo/MG5_aMC_v3_6_4 \
  --output "$PWD/prepared_for_scan" --format madevent
python3 scan.py prepare --prepared "$PWD/prepared_for_scan"
```

Then generate the submit file and follow the dry-run and submit commands above.
The helper’s card is the original template card used to identify the exports.
The scan worker installs the corrected active runtime card with `MASS[24]`
when it starts a job.

## Collect, diagnose and plot

After the jobs return, collect from the scan package directory.

```bash
python3 scan.py collect
```

`reports/scan_report.json` lists the validated, missing, rejected and duplicate
attempts and any event-count shortfalls. `scan_points.csv` has the direct CC
and NC rates in fb and the four reused SM rows. `scan_totals.csv` adds the
channels at each shared point, with their independent MC errors combined in
quadrature. The collector verifies the embedded parameter and run cards, the
LHE checksum, all events and the cross section read from the LHE init block.
A complete, valid LHE with fewer events than requested retains its integrated
rate and carries an explicit shortfall field.

To retry specific missing or failed jobs, use their IDs from the report, with
a new batch tag. For example, if these two jobs were missing:

```bash
python3 scan.py submit-file --tag retry01 --only \
  kappa3_E1_CC_HH_kp019 kappa3_E2_NC_HH_km050
condor_submit -dry-run submissions/retry01.classad submissions/retry01.sub
condor_submit submissions/retry01.sub
```

Run `collect` again once the retry finishes. A valid retry can satisfy the
job even when an earlier failed archive is present. If two archives validate
for the same job, the report identifies both. Choose one and move the other
outside the `results/` tree before collecting again.

Plot after the report says `COMPLETE`. The generator and collector use the
Python standard library. Plotting uses NumPy and Matplotlib.

```bash
python3 plot_scan.py
```

If plotting on your own computer, download `reports/scan_report.json` and
run `plot_scan.py --report PATH_TO_SCAN_REPORT_JSON` from the unpacked package.
The script writes one PDF and PNG per energy, with a full-range panel and a
zoom near the SM. Direct MC points have error bars. The fitted CC+NC curve is
the sum of the two channel fits. `quadratic_fits.json` gives the weighted
quadratic fit and the independent checks at the 20 points held out of the
fit through κ₃=0, 1, 2. The shaded interval is the observed ATLAS+CMS
one-parameter 95% CL result, −0.71 < κ₃ < 6.1.
[ATLAS and CMS, arXiv:2602.23991](https://arxiv.org/abs/2602.23991)

## Physics settings

```text
import model HHVBF_UFO_FCCmue-fccmue
# CC
 generate e- mu+ > ve vm~ h h QCD=0 QED=4 CV=2 C2V=1 C3=1
# NC, separate process export
 generate e- mu+ > e- mu+ h h QCD=0 QED=4 CV=2 C2V=1 C3=1
```

The exported amplitudes use unitary gauge and four diagrams per channel.
The order tag `C3=1` retains the trilinear diagrams. The scanned numerical
value is set through runtime `NEW[3]`. The worker verifies `NEW[1]=NEW[2]=1`
and the unchanged electroweak inputs, including the derived W mass
`MASS[24]=80.41900244576 GeV`.

Both beams use `lpp1=lpp2=0`, `polbeam1=polbeam2=0` and no beam PDFs.
The runs use the validated inclusive settings, a fixed renormalization
scale of 125 GeV and stable Higgs bosons. The cross sections are LO
production rates without acceptance cuts or branching factors.
The source model and coupling convention are described in
`model_setup/MODEL_AUDIT.md`.

`VALIDATION.md` records the four real local MadEvent checks and the
software checks completed before delivery.
