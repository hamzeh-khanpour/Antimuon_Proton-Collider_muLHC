# Package validation

The four smoke tests used the production worker, MG5_aMC 3.6.4 and GNU Fortran
14.2.0 on local scratch. Each produced 30,000 unweighted events. The collector
reopened each archive, checked the actual seed, coupling and beam settings
recorded in the LHE, and accepted the integrated rate.

| √s [TeV] | Channel | κ₃ | Cross section [fb] | MC error [fb] |
|---:|---|---:|---:|---:|
| 1 | CC | −10 | 10.91293 | 0.01534495 |
| 1 | NC | 0 | 0.028547 | 0.00005094 |
| 2 | CC | 0.1 | 0.9271227 | 0.001258569 |
| 2 | NC | 10 | 1.88298 | 0.001867399 |

The checked rates and LHE hashes are recorded in
`validation/local_madevent_checks.json`. The local partial collection
correctly reported four valid new points and four reused SM inputs. The
88-job CERN batch has yet to be submitted.

The declared grid has 88 unique job IDs and seeds. Runtime cards for all
22 values were checked against the corrected SM card to verify that the
only numerical change is `NEW[3]`. The generated full and selected-job
submit descriptions were checked for their planned queue entries. The
CERN instructions include a Condor dry run for scheduler-side parsing.

A separate synthetic complete table was used to exercise the plotting and
quadratic-fit pipeline. The synthetic data and figures are temporary tests.
