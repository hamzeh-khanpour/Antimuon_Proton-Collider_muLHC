# FCC-mue HHVBF model validation v1

Read `MODEL_AUDIT.md` first. The model's C3 parameter is confirmed to be kappa3, and the matched copy passed source, algebra, diagram-count and fixed-phase-space SM-closure tests. Integrated-rate and angular validation are outstanding.

## Contents

- `HHVBF_UFO_FCCmue/`: original model sources unchanged, plus one new `restrict_fccmue.dat`.
- `param_card_SM.dat`: separately matched CV=C2V=C3=1 runtime card.
- `reference_SM_param_card.dat`: unchanged original CERN SM reference card.
- `prepare_model.py`: prepares two process directories without integration.
- `audit_ufo.py`: source/algebra checks using standard Python only.
- `reproduce_matrix_checks.py`, `phasepoint_driver.cpp`: independent SM/matched-model numerical comparison using MG5 and g++.
- JSON test summaries, evidence logs and unchanged original UFO archive.

## First CERN step: preparation only

Extract this package into your AFS home. From the extracted directory run:

```
python3 audit_ufo.py --out source_audit_CERN.json

python3 prepare_model.py \
  --mg5 /eos/user/h/hakhanpo/MG5_aMC_v3_6_4 \
  --output "$HOME/FCCmue_HHVBF_ModelValidation_v1/prepared" \
  --format madevent
```

The helper targets MG5 3.6.4. It adds a separate model directory under that installation's `models/` and preserves any existing different directory with that name by failing instead of overwriting. It refuses an existing output directory. It does not edit `models/sm` or CVMFS.

MadEvent preparation requires gfortran. It generates code/templates, not events. The generated run cards are NOT ready for physics production: the next package must explicitly configure beams, polarization, no-cut definition, seed, scale, statistics and HTCondor execution. Do not run `launch` with those default run cards.

After successful preparation, return the terminal output and `prepared/preparation_manifest.json` for the next integrated-rate pilot. The existing 48-run campaign is preserved and should not be repeated.

## Reproduce the numerical matrix checks

Requires MG5 3.6.4, g++ and fresh output directories:

```
python3 prepare_model.py \
  --mg5 /path/to/MG5_aMC_v3_6_4 \
  --output /path/to/new_cpp_templates \
  --format standalone_cpp

python3 reproduce_matrix_checks.py \
  --mg5 /path/to/MG5_aMC_v3_6_4 \
  --prepared /path/to/new_cpp_templates \
  --reference-output /path/to/new_reference_checks
```

The second command compiles four small C++ evaluators and compares deterministic phase-space points. It does not integrate cross sections. Placeholder paths in this optional reproduction example must be replaced; the CERN preparation commands above use the recorded project installation path.

## Critical parameter convention

During IMPORT, the custom restriction uses NEW=(1.1,1.2,1.3) to retain independent external knobs. During EVERY RUN, supply the matched runtime card with NEW=(1,1,kappa3). The preparation helper installs NEW=(1,1,1) automatically after export. Do not assume any upstream model default is the SM.

`set new 3 2` sets numerical kappa3=2. `C3=1` in a generation command is a coupling-order upper bound, not the parameter value.
