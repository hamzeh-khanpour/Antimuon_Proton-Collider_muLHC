#!/usr/bin/env python3
"""Recheck the bundled UFO and matched runtime card without MadGraph."""
import argparse
import ast
import cmath
import hashlib
import importlib
import json
import math
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parent


def read_card(path):
    block='';values={}
    for line in path.read_text().splitlines():
        s=line.split('#',1)[0].split()
        if not s:continue
        if s[0].lower()=='block':block=s[1].upper()
        elif s[0].lower()=='decay':
            block='DECAY';values[(block,int(s[1]))]=float(s[2])
        elif len(s)>1:
            try:values[(block,int(s[0]))]=float(s[1])
            except ValueError:pass
    return values


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out',type=Path)
    args=ap.parse_args()
    model=ROOT/'HHVBF_UFO_FCCmue'
    parsed=[]
    for p in model.glob('*.py'):
        ast.parse(p.read_text());parsed.append(p.name)
    sys.path.insert(0,str(model))
    p=importlib.import_module('parameters')
    c=importlib.import_module('couplings')
    v=importlib.import_module('vertices')
    f=importlib.import_module('function_library')
    importlib.import_module('decays')
    new={x.name:(x.nature,x.type,x.lhablock,x.lhacode) for x in p.all_parameters if x.name in ['CV','C2V','C3']}
    assert new['C3']==('external','real','NEW',[3])
    hhh=[x for x in v.all_vertices if [q.pdg_code for q in x.particles]==[25,25,25]]
    assert len(hhh)==1 and next(iter(hhh[0].couplings.values())).name=='GC_89'
    deps=[x.name for x in c.all_couplings if 'C3' in x.value]
    assert deps==['GC_89']
    physical={}
    for x in v.all_vertices:
        ids=sorted(q.pdg_code for q in x.particles)
        if ids in [[25,25,25],[-24,24,25],[-24,24,25,25],[23,23,25],[23,23,25,25],[-5,5,25],[25,25,25,25]]:
            physical[x.name]={'pdgs':[q.pdg_code for q in x.particles],
                'couplings':[{'name':z.name,'value':z.value,'order':z.order} for z in x.couplings.values()]}
    runtime=read_card(ROOT/'param_card_SM.dat')
    restriction=read_card(model/'restrict_fccmue.dat')
    assert [restriction[('NEW',i)] for i in [1,2,3]]==[1.1,1.2,1.3]
    assert [runtime[('NEW',i)] for i in [1,2,3]]==[1,1,1]
    for b in ['MASS','YUKAWA']:
        assert runtime[(b,11)]==runtime[(b,13)]==0
    assert runtime[('MASS',5)]==runtime[('YUKAWA',5)]==4.7

    def evaluate(k):
        scope={'cmath':cmath,'complex':complex,'abs':abs}
        scope.update({fn.name:fn for fn in f.all_functions})
        for par in p.all_parameters:
            if par.nature=='external':
                scope[par.name]=runtime[(par.lhablock.upper(),par.lhacode[0])]
                if par.name=='C3':scope[par.name]=k
            else:scope[par.name]=eval(str(par.value),{'__builtins__':{}},scope)
        coupling={z.name:complex(eval(z.value,{'__builtins__':{}},scope)) for z in c.all_couplings}
        for val in coupling.values():
            assert math.isfinite(val.real) and math.isfinite(val.imag)
        expected=-3j*k*scope['MH']**2/scope['vev']
        assert abs(coupling['GC_89']-expected)<1e-10
        # Independent SM vertex relations at CV=C2V=1.
        for name,mass,power in [('GC_93','MW',1),('GC_54','MW',2),('GC_101','MZ',1),('GC_85','MZ',2)]:
            expected=2j*scope[mass]**2/scope['vev']**power
            assert abs(coupling[name]-expected)<1e-10
        return scope,coupling
    sm_scope,sm=evaluate(1)
    checks=[]
    for k in [0,1,2,-2,5]:
        scope,co=evaluate(k)
        changed=[name for name in co if abs(co[name]-sm[name])>1e-12]
        assert changed==([] if k==1 else ['GC_89'])
        checks.append({'C3':k,'changed_couplings_relative_to_SM':changed,
                       'hhh_vertex_real':co['GC_89'].real,'hhh_vertex_imag':co['GC_89'].imag})
    manifest={str(x.relative_to(ROOT)):hashlib.sha256(x.read_bytes()).hexdigest()
              for x in sorted(model.iterdir()) if x.is_file() and x.suffix in ['.py','.dat','.log']}
    result={'status':'SOURCE_AND_ALGEBRA_CHECKS_PASSED_NOT_INTEGRATED_RATE_VALIDATED',
      'original_archive_sha256':'afe36ce9cc12008247d9147aeb93cbecfe7696f073f0b6725d2a649b70eb9599',
      'python_modules_parsed':sorted(parsed),'parameter_count':len(p.all_parameters),
      'coupling_count':len(c.all_couplings),'vertex_count':len(v.all_vertices),
      'NEW_parameters':new,'physical_vertices':physical,
      'vev_GeV':sm_scope['vev'].real,'C3_checks':checks,'file_sha256':manifest,
      'limitations':['Not an EFT-completed scalar potential or NLO validation.',
        'No cross-section integration, polarized-ME tests, HH decay generation or detector study in this audit.']}
    text=json.dumps(result,indent=2)+'\n'
    if args.out:args.out.write_text(text)
    print(text)


if __name__=='__main__':main()
