#include <iostream>
#include <iomanip>
#include <cmath>
#include "CPPProcess.h"
#include "rambo.h"

int main(int argc, char** argv) {
  if (argc != 2) return 2;
  CPPProcess process;
  process.initProc(argv[1]);
  std::cout << std::setprecision(17);
  for (double energy : {1000.0, 2000.0}) {
    for (int point = 0; point < 10; ++point) {
      double weight;
      auto p = get_momenta(process.ninitial, energy, process.getMasses(), weight);
      double residual = 0;
      for (int mu = 0; mu < 4; ++mu) {
        double sum = 0;
        for (int i = 0; i < process.nexternal; ++i)
          sum += (i < process.ninitial ? 1.0 : -1.0)*p[i][mu];
        residual = std::max(residual, std::abs(sum)/energy);
      }
      if (residual > 1e-10) return 3;
      process.setMomenta(p);
      process.sigmaKin();
      double value = process.getMatrixElements()[0];
      if (!std::isfinite(value) || value < 0) return 4;
      std::cout << "POINT " << energy << " " << point << " " << value
                << " " << residual;
      for (int i=0; i<process.nexternal; ++i)
        for (int mu=0; mu<4; ++mu) std::cout << " " << p[i][mu];
      std::cout << "\n";
      for (auto q : p) delete[] q;
    }
  }
  return 0;
}
