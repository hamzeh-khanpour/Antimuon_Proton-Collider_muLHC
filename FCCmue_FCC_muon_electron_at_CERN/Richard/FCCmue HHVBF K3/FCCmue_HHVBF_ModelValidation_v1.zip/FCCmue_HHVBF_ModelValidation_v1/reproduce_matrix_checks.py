#!/usr/bin/env python3
"""Reproduce standalone-C++ matrix checks; no rate integration or events.

Run prepare_model.py --format standalone_cpp first, and supply its output
directory here. This script exports the two reference SM C++ processes,
compiles a deterministic phase-space driver, and compares model hypotheses.
Requires g++, an existing MG5 3.6.4 installation and a fresh reference output.
"""
import argparse
import json
import math
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--mg5', type=Path, required=True)
    ap.add_argument('--prepared',type=Path,required=True)
    ap.add_argument('--reference-output',type=Path,required=True)
    args = ap.parse_args()
    mg=args.mg5.expanduser().resolve()
    prepared=args.prepared.expanduser().resolve()
    out=args.reference_output.expanduser().resolve()
    if out.exists():raise RuntimeError('Preserving existing output: '+str(out))
    out.mkdir(parents=True)
    sys.path.insert(0,str(mg))
    from madgraph.interface.master_interface import MasterCmd
    cmd=MasterCmd()
    cmd.exec_cmd('set automatic_html_opening False',printcmd=False)
    cmd.exec_cmd('set gauge unitary',printcmd=False)
    cmd.exec_cmd('import model sm',printcmd=False)
    report={}
    base=(ROOT/'param_card_SM.dat').read_text()

    def evaluate(proc,card,label):
        run=subprocess.run([str(proc/'matrix_check'),str(card)],cwd=proc,
                           capture_output=True,text=True,check=True)
        (out/(label+'.log')).write_text(run.stdout+run.stderr)
        points=[list(map(float,s.split()[1:])) for s in run.stdout.splitlines() if s.startswith('POINT ')]
        if len(points)!=20:raise RuntimeError('Expected 20 deterministic phase-space points')
        return points

    for ch,process in [('CC_HH','e- mu+ > ve vm~ h h'),('NC_HH','e- mu+ > e- mu+ h h')]:
        cmd.exec_cmd('generate '+process+' QCD=0 QED=4',printcmd=False)
        cmd.exec_cmd('output standalone_cpp '+str(out/ch),printcmd=False)
        procs={}
        for label,root in [('HHVBF',prepared/ch),('SM',out/ch)]:
            proc=next((root/'SubProcesses').glob('P*'))
            lib=next((root/'lib').glob('libmodel_*.a'))
            compile_cmd=['g++','-O2','-std=c++11','-I'+str(root/'src'),'-I'+str(proc),
                str(ROOT/'phasepoint_driver.cpp'),str(proc/'CPPProcess.cc'),
                '-L'+str(root/'lib'),'-l'+lib.stem[3:],'-o',str(proc/'matrix_check')]
            build=subprocess.run(compile_cmd,capture_output=True,text=True,check=True)
            (out/(ch+'_'+label+'_build.log')).write_text(build.stdout+build.stderr)
            procs[label]=proc
        sm=evaluate(procs['SM'],ROOT/'reference_SM_param_card.dat',ch+'_SM')
        scans={}
        for k in [0,1,2,-2,5]:
            card=out/(ch+'_k'+str(k)+'.dat')
            text=base.replace('3 1.000000000000e+00 # C3','3 %.12e # C3'%k)
            if k!=1 and text==base:raise RuntimeError('C3 runtime edit failed')
            card.write_text(text)
            scans[k]=evaluate(procs['HHVBF'],card,ch+'_k'+str(k))
            for a,b in zip(sm,scans[k]):
                if a[:2]!=b[:2] or max(abs(x-y) for x,y in zip(a[4:],b[4:]))>1e-11:
                    raise RuntimeError('Compared phase-space momenta differ')
        closure=max(abs(a[2]-b[2])/max(abs(a[2]),abs(b[2]),1e-100) for a,b in zip(sm,scans[1]))
        residuals=[]
        for j in range(20):
            f={k:scans[k][j][2] for k in scans}
            c0=f[0];c2=(f[2]-2*f[1]+f[0])/2;c1=f[1]-c0-c2
            if c2<0 or c1*c1>4*c0*c2*(1+1e-9):
                raise RuntimeError('Quadratic positivity check failed')
            for k in [-2,5]:
                pred=c0+c1*k+c2*k*k
                residuals.append(abs(pred-f[k])/max(abs(pred),abs(f[k]),1e-100))
        if closure>=1e-8 or max(residuals)>=1e-8:
            raise RuntimeError('Matrix validation tolerance exceeded')
        report[ch]={'points':20,'energies_GeV':[1000,2000],
            'SM_closure_max_relative_difference':closure,
            'quadratic_check_max_relative_difference':max(residuals),
            'kappa_values':[0,1,2,-2,5],
            'scope':'Unpolarized squared matrix elements only; no cross-section integration.'}
    (out/'matrix_checks.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':main()
