# Validation record — 10 November 2026 project continuation

## Scientific evidence already available

- The user-supplied latest CERN terminal log reports MG5 3.6.4 preparation of
  CC_HH and NC_HH, four diagrams per channel, unitary gauge, the dedicated
  `fccmue` restriction, and runtime parameter-card checksum
  `22a08b9317018acaa51ea7098c7a8d60e2b775c050cd44e0d798e40603f8737b`.
- That log explicitly states that no launch, integration, event generation,
  shower or batch submission was performed.
- The previous validation kit inspected the original archived CERN UFO and
  established the exact C3=κ₃ interaction. It also reported 40 deterministic
  phase-space comparisons against the original SM in the identified MG5 3.6.4
  C++ standalone implementation, with matching SM matrix elements. Those
  completed checks have not been unnecessarily repeated here.
- The four historical rates in this add-on are extracted directly from
  `audit/data/cross_sections_48.csv`, obtained from the supplied original source
  bundle. Their run cards are copied from the corresponding original reviewed
  CERN job archives. They are historical references, not new-model results.

## Additional checks completed for this add-on

- Python syntax compilation of the new production code.
- Twelve standard-library regression tests, including an end-to-end four-job
  synthetic prepare/worker/archive/collect cycle with 30000 artificial events
  per job, preserving original history and pre-run card snapshots.
- Failures exercised: missing essential run-card settings, optional CC `ptl`
  omission, NC `ptl` removal, changed runtime parameters, contradictory process
  history, wrong generated diagram count, unsafe external links, tar traversal,
  changed template/software hashes, failed generator exit, incomplete event
  count, a wrong final-state particle in event 30000, invalid incoming beam IDs
  or energies, negative/inconsistent weights, unsupported LHE normalization,
  incomplete LHE file, duplicate/misnamed archive, and an assigned rate mismatch.
- The matrix-header and exported trilinear-coupling inspection was additionally
  run on the actual locally exported MG5 HHVBF CC Fortran source, including
  repeated process headers and the generated `GC_89` expression. This source
  inspection does not constitute Fortran integration.
- The process-history omission was reproduced using the actual MG5 v3.6.4
  Python interface. Its `exec_cmd` defaults to `precmd=False`; the history
  recording occurs in `precmd`. The generated amplitude remains present, while
  the import/generate history can be absent. The add-on reconstructs missing
  history only after independent exported-source checks and only in the
  transferred archive; original files are preserved.

## Checks requiring CERN execution

The local runtime has no gfortran compiler or HTCondor scheduler. There has been
no local Fortran integration, no live CERN submission, and no new integrated
physics prediction. The required CERN checks are:

1. Run `prepare` against the actual successful CERN exports. This checks their
   generated source, manifest, cards, links and transferable template snapshots.
2. Run `submit-file`, then `condor_submit -dry-run` and verify four jobs.
3. Submit the four jobs once and inspect their logs and returned archives.
4. Run `collect` to validate all archived events/cards and compare the rates.
5. Review the result scientifically, including integration stability; do not
   equate a diagnostic compatibility flag with independent convergence proof.

No κ₃ departures, new polarized rates, HH→4b distributions, backgrounds or
triple-Higgs production have been computed by this add-on. Synthetic test
normalizations must never be quoted as physics predictions.
