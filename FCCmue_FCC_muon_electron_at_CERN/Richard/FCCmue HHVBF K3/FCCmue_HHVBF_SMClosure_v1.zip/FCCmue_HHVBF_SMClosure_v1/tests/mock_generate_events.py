#!/usr/bin/env python3
"""SYNTHETIC TEST FIXTURE. Performs no integration; never use for physics."""
import gzip
import pathlib
import re
import sys

root = pathlib.Path.cwd()
a = {}
for line in (root/'Cards/run_card.dat').read_text().splitlines():
    core = line.split('#', 1)[0].split('!', 1)[0]
    if '=' in core:
        v, k = core.split('=', 1)
        a[k.strip()] = v.strip()
seed = int(a['iseed'])
print('SYNTHETIC TEST FIXTURE: no physics integration.', flush=True)
print('Using random number seed offset =', seed, flush=True)
mode = (root/'fixture_mode.txt').read_text().strip() if (root/'fixture_mode.txt').exists() else ''
if mode == 'fail':
    sys.exit(7)
cc = '> ve vm~' in (root/'Cards/proc_card_mg5.dat').read_text()
e1, e2, n = float(a['ebeam1']), float(a['ebeam2']), int(a['nevents'])
# Deliberately assigned numbers for pipeline comparison tests, not computed.
rates = {(True, 125): .0743838, (False, 125): .00962012,
         (True, 200): .41851, (False, 200): .0547116}
xs = rates[cc, int(e1)]/1000
if mode == 'rate_mismatch':
    xs *= 1.2
final = [12, -14, 25, 25] if cc else [11, -13, 25, 25]
directory = root/'Events/run_01'
directory.mkdir(parents=True, exist_ok=True)
with gzip.open(directory/'unweighted_events.lhe.gz', 'wt') as f:
    f.write('<LesHouchesEvents version="3.0">\n<init>\n')
    f.write(f'11 -13 {e1} {e2} 0 0 0 0 -4 1\n{xs:.14g} {xs*.002:.14g} {xs:.14g} 1\n</init>\n')
    for i in range(n-(1 if mode == 'shortfall' else 0)):
        f.write('<event>\n'+f'6 1 {xs:.14g} 125 .007 .118\n')
        for pdg, status in [(11, -1), (-13, -1)]+[(x, 1) for x in final]:
            if mode == 'bad_late_topology' and i == n-1 and pdg == 25:
                pdg = 23
            f.write(f'{pdg} {status} 0 0 0 0 0 0 0 125 125 0 0\n')
        f.write('</event>\n')
    f.write('</LesHouchesEvents>\n')
# Reproduce MG5's intentional post-run seed reset.
p = root/'Cards/run_card.dat'
p.write_text(re.sub(r'^\d+ = iseed', '0 = iseed', p.read_text(), flags=re.M))
