# FCC-μ⁺e⁻: four-point integrated SM closure pilot

This version runs the four unpolarized SM closure points using the existing
CERN HHVBF templates. It corrects the runtime parameter card used by cluster
13387443. See `VALIDATION.md` for the archived failure and the local MadEvent
verification.

## Physics configuration

At runtime, NEW[1] = CV = 1, NEW[2] = C2V = 1, NEW[3] = C3 = κ₃ = 1.
The runtime card adds `MASS[24] = 80.41900244576 GeV`, derived from the UFO's
existing \(M_Z, G_F, \alpha_{\mathrm{EW}}\) inputs. The W mass is an internal
parameter in the UFO. MadEvent also needs its evaluated value in the runtime
card for its width-to-mass check. The worker installs the corrected card as
both the active card and the default card when the latter exists. The dedicated
import restriction keeps the three coupling modifiers external.

| Channel | Exact √s [GeV] | Beam 1: e⁻ [GeV] | Beam 2: μ⁺ [GeV] | Historical SM σ [fb] | Historical MC error [fb] |
|---|---:|---:|---:|---:|---:|
| CC HH | 1000 | 125 | 2000 | 0.0743838 | 0.0001273876 |
| NC HH | 1000 | 125 | 2000 | 0.00962012 | 0.00001455268 |
| CC HH | 2000 | 200 | 5000 | 0.418510 | 0.0006567856 |
| NC HH | 2000 | 200 | 5000 | 0.0547116 | 0.00008505412 |

The table gives the historical CERN SM rates. The four source job identifiers,
run cards and SHA-256 checksums are recorded in `reference/SM_benchmarks.json`.

All four jobs use unpolarized beams (`polbeam1=polbeam2=0`), 30000 requested
unweighted events, unique new seeds and the archived successful run-card settings.
Beam types are `lpp1=lpp2=0`. Higgs bosons are stable. No branching-ratio factor,
decay, shower or detector simulation is applied. The Higgs width remains the
historical 0.006382339 GeV solely to preserve benchmark closure; this pilot does
not redefine the later decay/branching convention.

Each exported process has four diagrams, including their internal interference:

```text
generate e- mu+ > ve vm~ h h QCD=0 QED=4 CV=2 C2V=1 C3=1
generate e- mu+ > e- mu+ h h QCD=0 QED=4 CV=2 C2V=1 C3=1
```

These coupling-order bounds retain the complete requested tree-level HH
amplitudes. They are not numerical assignments of the modifier values.
CC and NC have different external states and are compared separately; their
cross sections can later be summed without cross-channel interference.

## Run at CERN

Upload the ZIP to your CERN home directory and unzip it **once** into a new AFS
directory. Keep the existing validation kit and all old SM scan outputs.

```bash
cd "$HOME"
unzip -n FCCmue_HHVBF_SMClosure_v1_1.zip
cd "$HOME/FCCmue_HHVBF_SMClosure_v1_1"
sha256sum -c SHA256SUMS

python3 closure.py prepare \
  --prepared "$HOME/FCCmue_HHVBF_ModelValidation_v1/prepared"

python3 closure.py submit-file
cat submissions/closure.sub
condor_submit -dry-run submissions/closure.classad submissions/closure.sub
```

`prepare` reads and snapshots the two existing MadEvent exports. It does not run
MG5 generation or integration. It verifies the successful CERN manifest, version
3.6.4, four-diagram generated matrix headers, the exported C3 coupling, runtime
parameter checksum, and absence of previous runs or external file dependencies.
The worker uses the verified original export and the corrected runtime card.

`submit-file` writes a four-job HTCondor submit description. It requires the
package directory to be on AFS, transfers all inputs into worker scratch, requests
one CPU, 4 GB memory and 8 GB disk per job, and uses the `tomorrow` flavour as in
the original successful package. Each job has its own result archive. It does
not submit jobs. The HTCondor dry run above parses the description without
queuing jobs; check that it reports four jobs.

After successful preparation and the four-job dry run, submit **once**:

```bash
condor_submit submissions/closure.sub
condor_q "$USER"
```

Record the returned cluster identifier. To inspect only that cluster, replace
`CLUSTER_ID` below by the actual number returned by `condor_submit`:

```bash
condor_q CLUSTER_ID
condor_q CLUSTER_ID -hold
```

Do not resubmit jobs just because they have left the queue. Check the four
`results/*.tar.gz` files and Condor logs first. An execution or transfer failure
is a technical issue to inspect, not an integrated result. The worker preserves
a failure archive when it can catch the error; external termination or a failure
before Python starts may prevent that archive from being produced.

When all four jobs have finished:

```bash
python3 closure.py collect
cat reports/closure_report.json
```

The collector exits with status 0 only if all four required samples pass evidence
checks and the rate comparisons are within the diagnostic 3σ tolerance. Status
2 means results are missing, failed, malformed or require review. Existing result
archives are never rewritten by collection. Reports can be regenerated from them.

## Process-history correction included

The first validation kit's `prepare_model.py` called MG5's Python `exec_cmd`
without `precmd=True`. In MG5 3.6.4 that can omit the `import model` and `generate`
lines from exported `Cards/proc_card_mg5.dat`, even when the matrix is correctly
generated. Missing process history must be corrected before the MadEvent run so
its runtime bookkeeping and event banner identify the proper model and process.

This add-on checks the generated Fortran matrix process/order header, four-diagram
count and C3 coupling against the CERN preparation manifest. If the original
history lacks import/generate commands, it reconstructs those lines **only inside
the transferred template archive**. It retains the original history in
`process/FCCMUE_ORIGINAL_proc_card_mg5.dat` and records the reason and generated
source checksums in `process/FCCMUE_EXPORT_AUDIT.json`. Contradictory existing
model/process commands cause a hard failure instead of automatic rewriting.
Neither the generated amplitudes nor the original CERN preparation are modified.

For future fresh exports, the upstream preparation helper should use
`cmd.exec_cmd(..., printcmd=False, precmd=True)` for its import, generate, output
and setting commands. This pilot needs no regeneration of the existing exports.

## Validation and interpretation

Before launch, each worker replaces the UFO's default run card by the exact
archived historical run card for its channel and energy, then sets and verifies
the new seed and declared beam/event settings using the audited `card_utils.py`.
Optional `ptl` may be absent for CC. Essential beam/polarization/seed fields may
not be absent. The historical no-cut settings and fixed renormalization scale
125 GeV are preserved. All three runtime coupling modifiers must be 1.

The worker saves pre-run card snapshots, post-run cards, the original and corrected
process history, the exact pilot manifest, a card audit, log, event banner, and
the unweighted LHE sample. If MadEvent logs an interruption, the worker reports
the exception and archives any generated debug log. It verifies the actual seed printed by MadEvent,
allows MG5's documented post-run seed reset to 0, checks the post-run numerical
parameters/settings, and streams every event to check beam IDs, final-state PDGs,
weights, the LHE normalization and the complete requested count.

The collector independently reopens the archived LHE and checks its checksum,
event count and normalization, checks the archived cards, and compares each rate
with its historical reference using

\[
z=\frac{\sigma_{\mathrm{new}}-\sigma_{\mathrm{old}}}
{\sqrt{(\delta\sigma_{\mathrm{new}})^2+(\delta\sigma_{\mathrm{old}})^2}}.
\]

The two seeds differ. The denominator uses the reported MC integration errors;
it does not represent a theory or detector uncertainty. `|z|≤3` is a diagnostic
compatibility criterion, not a proof of convergence or a multiple-testing
discovery claim. If a comparison fails, examine cards, integration logs and
independent-seed convergence before any BSM production. Do not change cuts just
to force agreement with the old result.

Even four successful comparisons do not independently certify the convergence
of the original reference rates or the new integrals. Polarized new-model closure,
integration stability and pilot κ₃ points remain separate next checks. The
source/algebra/fixed-point tests in the earlier kit and this integrated-rate
check answer complementary questions.

After closure review, the next stage is a small κ₃ pilot, changing only the
external NEW[3] numerical value with CV=C2V=1, followed by the polarization map.
The model is a phenomenological LO κ₃ slice; this is not a completed SMEFT
operator analysis or an NLO validation. HH→4b generation, reconstruction,
Richard's raw cross-product observables and separately normalized plane-angle
observables, and signal/background selections remain outstanding.

## Local software tests

```bash
python3 -m unittest discover -s tests -v
```

`tests/mock_generate_events.py` is explicitly synthetic, with assigned test
normalizations and artificial four-vectors. It is **never transferred or selected
by the production worker**. These tests verify software control flow and failure
handling, not physics rates. See `VALIDATION.md` for the actual checks completed
before delivery and their limits.

## Technical references

- [HTCondor input/output file transfer](https://htcondor.readthedocs.io/en/latest/users-manual/file-transfer.html)
- [CERN batch submission documentation](https://batchdocs.web.cern.ch/local/submit.html)
- [MG5_aMC v3.6.4 source tag](https://github.com/mg5amcnlo/mg5amcnlo/tree/v3.6.4)

The existing successful project's AFS/file-transfer setup is the operational
starting point. The live CERN `condor_submit -dry-run` remains a required syntax
check because no HTCondor scheduler is available in the local validation runtime.
