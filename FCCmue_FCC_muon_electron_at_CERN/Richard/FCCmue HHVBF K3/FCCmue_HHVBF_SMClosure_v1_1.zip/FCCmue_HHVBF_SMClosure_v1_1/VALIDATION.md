# HHVBF unpolarized SM closure validation

## CERN cluster 13387443

All four uploaded CERN archives contain `run.log` and the pre-run parameter
card with SHA-256 `22a08b9317018acaa51ea7098c7a8d60e2b775c050cd44e0d798e40603f8737b`.
Every run stopped during setup of the MadEvent survey with

```text
WARNING: Missing mass in the lhef file (24)
KeyError : 'id (24,) is not in mass'
```

The active card supplied the W width in `DECAY 24` and omitted `MASS[24]`.
The original worker reported the absence of the seed line after MadEvent
returned control. The archives contain no final LHE files.

Version 1.1 adds the W mass evaluated from the existing UFO definition

\[
M_W=\sqrt{\frac{M_Z^2}{2}+\sqrt{\frac{M_Z^4}{4}-
\frac{\pi\alpha_{\mathrm{EW}} M_Z^2}{\sqrt{2}G_F}}}
=80.41900244576\ \mathrm{GeV}.
\]

This agrees with the rounded value in the historical SM card. The runtime
parameter card SHA-256 is
`1782870ce8b7f2744f8607e646fdaf77ce99c64175821c2a8e2e5280f995cbfe`.
The worker now surfaces logged MadEvent interruptions, checks for a final
LHE before seed validation and retains any MadEvent debug log.

## Local MadEvent integration

The corrected package ran all four points locally with MG5_aMC 3.6.4
(tag commit `bfd34580eb59c2a027a502c89995e682a70a95b9`) and GNU Fortran
14.2.0. The original model-validation helper produced fresh local exports.
The corrected worker unpacked them in four separate scratch directories
and applied the historical run cards and the planned closure seeds. These
seeds differ from the historical SM seeds. The failed CERN jobs stopped
before using the planned closure seeds for integration.

| √s [TeV] | Channel | σ new [fb] | MC error [fb] | σ historical [fb] | Pull |
|---:|---|---:|---:|---:|---:|
| 1 | CC | 0.0742573 | 0.0001340814 | 0.0743838 | −0.684 |
| 1 | NC | 0.0096359 | 0.00001504015 | 0.00962012 | +0.754 |
| 2 | CC | 0.419742 | 0.0006545875 | 0.418510 | +1.329 |
| 2 | NC | 0.0547123 | 0.00008026378 | 0.0547116 | +0.006 |

All four workers exited successfully with 30,000 unweighted events per point.
The collector reopened the archived LHE files and checked event counts,
weights, beam settings, final-state PDGs and provenance. Its status was
`FOUR_POINT_SM_RATE_CLOSURE_COMPATIBLE`. The pull uses the old and new
reported MC errors added in quadrature. The largest absolute pull is 1.329.
The 13 workflow regression tests also passed.

`local_validation/results/` holds the four complete result archives with
cards, logs, banners and LHE files. `local_validation/reports/` holds the
collector's JSON and CSV. The local `run_manifest.json` records the source
and worker input hashes. It belongs to the local results. Running `prepare`
for a CERN submission creates a separate manifest in the package root.

This establishes numerical compatibility for the four unpolarized stable-HH
SM rates with the historical inputs. An integration convergence study and
polarized or non-SM coupling points are separate checks. Execution of this
revised workflow on CERN HTCondor remains available through the README.
