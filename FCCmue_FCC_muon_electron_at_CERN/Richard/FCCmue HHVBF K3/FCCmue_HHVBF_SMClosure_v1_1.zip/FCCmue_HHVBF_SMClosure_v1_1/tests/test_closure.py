"""Workflow regression tests with explicitly synthetic generation fixtures."""
import argparse
import contextlib
import gzip
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import tempfile
import unittest

PACKAGE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PACKAGE))
import card_utils
import closure


def original_preparation_card():
    lines = (PACKAGE/'param_card_SM.dat').read_text().splitlines(keepends=True)
    return ''.join(line for line in lines if ' # MW, derived' not in line)


class PilotTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)
        self.pkg = self.base/'package'
        shutil.copytree(PACKAGE, self.pkg, ignore=shutil.ignore_patterns('__pycache__', 'templates',
                        'run_manifest.json', 'results', 'reports', 'submissions', 'condor_logs'))
        self.oldroot = closure.ROOT
        closure.ROOT = self.pkg
        self.prepared = self.base/'prepared'
        self.prepared.mkdir()
        entries = []
        for channel in closure.CHANNELS:
            p = self.prepared/channel
            for directory in ['Cards', 'bin', 'Events', 'SubProcesses/P0_test', 'Source/MODEL']:
                (p/directory).mkdir(parents=True)
            (p/'Cards/param_card.dat').write_text(original_preparation_card())
            shutil.copy2(self.pkg/f'reference/E1_{channel}_run_card.dat', p/'Cards/run_card.dat')
            (p/'Cards/proc_card_mg5.dat').write_text('set gauge unitary\n# Missing exec_cmd history fixture\n')
            matrix = ('C     Process: '+closure.CHANNELS[channel][0]+
                      ' C2V<=1 C3<=1 CV<=2 QCD=0 QED<=4\n'
                      '      PARAMETER (NGRAPHS=4)\n')
            (p/'SubProcesses/P0_test/template_matrix1.f').write_text(matrix)
            (p/'Source/MODEL/couplings1.f').write_text('      GC_89 = -6.000000D+00*MDL_C3*MDL_COMPLEXI*MDL_LAM*MDL_VEV\n')
            shutil.copy2(PACKAGE/'tests/mock_generate_events.py', p/'bin/generate_events')
            entries.append(dict(channel=channel, command=closure.COMMANDS[channel],
                                diagram_counts=[4], output=str(p)))
        closure.dump(dict(status='PREPARED_NOT_RATE_VALIDATED', mg5_version='version = 3.6.4\n',
                          restriction='fccmue', gauge='unitary', runtime_param_card_sha256=closure.PREPARED_PARAM_SHA,
                          channels=entries), self.prepared/'preparation_manifest.json')

    def tearDown(self):
        closure.ROOT = self.oldroot
        self.tmp.cleanup()

    def prepare(self, mode=''):
        if mode:
            for channel in closure.CHANNELS:
                (self.prepared/channel/'fixture_mode.txt').write_text(mode)
        with contextlib.redirect_stdout(io.StringIO()):
            closure.prepare(argparse.Namespace(prepared=str(self.prepared)))

    def run_job(self, j):
        work = self.base/j['job_id']
        work.mkdir()
        for name in ['closure.py', 'card_utils.py', 'worker.sh', 'param_card_SM.dat', 'run_manifest.json']:
            shutil.copy2(self.pkg/name, work/name)
        shutil.copytree(self.pkg/'reference', work/'reference')
        shutil.copy2(self.pkg/'templates'/j['archive'], work/j['archive'])
        result = subprocess.run([sys.executable, 'closure.py', 'worker', j['job_id']], cwd=work,
                                text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        self.assertTrue((work/'job_output.tar.gz').is_file(), result.stdout)
        return result, work

    def collect(self):
        with contextlib.redirect_stdout(io.StringIO()):
            ret = closure.collect(argparse.Namespace())
        return ret, json.loads((self.pkg/'reports/closure_report.json').read_text())

    def test_four_job_end_to_end_and_duplicate_rejection(self):
        self.prepare()
        self.assertEqual(len({j['seed'] for j in closure.jobs()}), 4)
        (self.pkg/'results').mkdir()
        for j in closure.jobs():
            p, work = self.run_job(j)
            self.assertEqual(p.returncode, 0, p.stdout)
            with tarfile.open(work/'job_output.tar.gz') as t:
                audit = json.load(t.extractfile('process/FCCMUE_EXPORT_AUDIT.json'))
                self.assertTrue(audit['history_status'].startswith('HISTORY_RECONSTRUCTED'))
                self.assertIn('process/FCCMUE_ORIGINAL_proc_card_mg5.dat', t.getnames())
                self.assertIn('snapshots/pre_run_card.dat', t.getnames())
            shutil.copy2(work/'job_output.tar.gz', self.pkg/'results'/(j['job_id']+'.tar.gz'))
        rc, report = self.collect()
        self.assertEqual(rc, 0, report)
        self.assertEqual(report['status'], 'FOUR_POINT_SM_RATE_CLOSURE_COMPATIBLE')
        self.assertEqual(len(report['comparisons']), 4)
        src = next((self.pkg/'results').glob('*.tar.gz'))
        shutil.copy2(src, self.pkg/'results/duplicate.tar.gz')
        rc, report = self.collect()
        self.assertEqual(rc, 2)
        self.assertEqual(len(report['problems']), 1)

    def test_generator_failure_preserves_diagnostics(self):
        self.prepare('fail')
        p, work = self.run_job(closure.jobs()[0])
        self.assertEqual(p.returncode, 1)
        with tarfile.open(work/'job_output.tar.gz') as t:
            r = json.load(t.extractfile('result.json'))
            self.assertEqual(r['status'], 'FAILED')
            self.assertIn('MadEvent exit 7', r['error'])
            self.assertIn('exception.txt', t.getnames())

    def test_zero_exit_madevent_error_reports_original_cause(self):
        self.prepare('logged_failure')
        p, work = self.run_job(closure.jobs()[0])
        self.assertEqual(p.returncode, 1)
        with tarfile.open(work/'job_output.tar.gz') as t:
            r = json.load(t.extractfile('result.json'))
            self.assertIn("KeyError : 'id (24,) is not in mass'", r['error'])
            self.assertIn('process/run_01_tag_1_debug.log', t.getnames())

    def test_late_topology_failure_is_detected(self):
        self.prepare('bad_late_topology')
        p, work = self.run_job(closure.jobs()[0])
        self.assertEqual(p.returncode, 1)
        self.assertIn('Incorrect particle topology in event 30000', p.stdout)

    def test_shortfall_is_not_success(self):
        self.prepare('shortfall')
        p, work = self.run_job(closure.jobs()[0])
        self.assertEqual(p.returncode, 1)
        self.assertIn('Event count 29999 differs from requested 30000', p.stdout)

    def test_rate_mismatch_is_not_accepted(self):
        self.prepare('rate_mismatch')
        (self.pkg/'results').mkdir()
        p, work = self.run_job(closure.jobs()[0])
        self.assertEqual(p.returncode, 0, p.stdout)
        j = closure.jobs()[0]
        shutil.copy2(work/'job_output.tar.gz', self.pkg/'results'/(j['job_id']+'.tar.gz'))
        rc, report = self.collect()
        self.assertEqual(rc, 2)
        self.assertEqual(report['comparisons'][0]['status'], 'REVIEW_RATE_MISMATCH')
        self.assertEqual(len(report['missing']), 3)

    def test_changed_parameter_and_external_link_rejected(self):
        p = self.prepared/'CC_HH/Cards/param_card.dat'
        p.write_text(p.read_text().replace('1.000000000000e+00 # C3', '2.000000000000e+00 # C3'))
        with self.assertRaisesRegex(ValueError, 'card changed'):
            self.prepare()
        p.write_text(original_preparation_card())
        (self.prepared/'CC_HH/outside').symlink_to(self.pkg/'param_card_SM.dat')
        with self.assertRaisesRegex(ValueError, 'external dependency'):
            self.prepare()

    def test_matrix_mismatch_and_contradictory_history_rejected(self):
        p = self.prepared/'CC_HH/SubProcesses/P0_test/template_matrix1.f'
        old = p.read_text()
        p.write_text(old.replace('NGRAPHS=4', 'NGRAPHS=3'))
        with self.assertRaisesRegex(ValueError, 'four diagrams'):
            self.prepare()
        p.write_text(old)
        (self.prepared/'CC_HH/Cards/proc_card_mg5.dat').write_text('import model sm\ngenerate e- mu+ > ve vm~ h h\n')
        with self.assertRaisesRegex(ValueError, 'Contradictory'):
            self.prepare()

    def test_audited_cards_optional_ptl_and_missing_required(self):
        p = self.base/'run.dat'
        shutil.copy2(self.pkg/'reference/E1_CC_HH_run_card.dat', p)
        a = card_utils.configure(p, 125, 2000, 0, 30000, 64110037)
        self.assertFalse(a['ptl_field_present'])
        p.write_text(p.read_text().replace('0 = polbeam2', '# removed = polbeam2'))
        with self.assertRaisesRegex(ValueError, 'critical'):
            card_utils.configure(p, 125, 2000, 0, 30000, 64110037)
        shutil.copy2(self.pkg/'reference/E1_NC_HH_run_card.dat', p)
        p.write_text(p.read_text().replace('0.0 = ptl', '1.0 = ptl'))
        a = card_utils.configure(p, 125, 2000, 0, 30000, 64110037)
        self.assertEqual(float(card_utils.parse(p.read_text())['ptl']), 0)

    def test_tar_path_traversal_rejected(self):
        p = self.base/'evil.tar.gz'
        with tarfile.open(p, 'w:gz') as t:
            info = tarfile.TarInfo('process/../../outside')
            info.size = 1
            t.addfile(info, io.BytesIO(b'x'))
        with self.assertRaisesRegex(ValueError, 'Unsafe'):
            closure.unpack_regular_archive(p, self.base)

    def test_manifest_and_template_changes_fail_closed(self):
        self.prepare()
        with (self.pkg/'templates/CC_HH.tar.gz').open('ab') as f:
            f.write(b'changed')
        p, work = self.run_job(closure.jobs()[0])
        self.assertEqual(p.returncode, 1)
        self.assertIn('Transferred template checksum mismatch', p.stdout)
        with (self.pkg/'card_utils.py').open('a') as f:
            f.write('\n# accidental edit\n')
        with self.assertRaisesRegex(ValueError, 'file changed'):
            closure.verified_manifest()

    def test_lhe_normalization_and_completeness_rejections(self):
        j = dict(closure.jobs()[0], nevents=1)
        header = '<LesHouchesEvents version="3.0">\n<init>\n11 -13 125 2000 0 0 0 0 -4 1\n.0001 .000001 .0001 1\n</init>\n'
        event = '<event>\n6 1 .0001 125 .007 .118\n'+''.join(
            f'{pdg} {status} 0 0 0 0 0 0 0 125 125 0 0\n'
            for pdg, status in [(11, -1), (-13, -1), (12, 1), (-14, 1), (25, 1), (25, 1)])+'</event>\n'
        original = header+event+'</LesHouchesEvents>\n'
        p = self.base/'sample.lhe'
        p.write_text(original)
        self.assertEqual(closure.read_lhe(p, j)['sigma_fb'], .1)
        for bad, message in [
            (original.replace('11 -13 125 2000', '-11 -13 125 2000'), 'beam IDs'),
            (original.replace('125 2000 0 0', '120 2000 0 0'), 'beam energies'),
            (original.replace('6 1 .0001', '6 1 -.0001'), 'Invalid weight'),
            (original.replace('6 1 .0001', '6 1 .0002'), 'weights inconsistent'),
            (original.replace('0 0 -4 1', '0 0 -1 1'), 'Unsupported'),
            (original.replace('</LesHouchesEvents>', ''), 'Malformed'),
        ]:
            with self.subTest(message=message):
                p.write_text(bad)
                with self.assertRaisesRegex(ValueError, message):
                    closure.read_lhe(p, j)

    def test_numeric_parameter_mismatch_even_without_format_requirement(self):
        p = self.base/'param.dat'
        shutil.copy2(self.pkg/'param_card_SM.dat', p)
        p.write_text(p.read_text().replace('1.000000000000e+00 # C3', '2.000000000000e+00 # C3'))
        with self.assertRaisesRegex(ValueError, 'Runtime parameter mismatch'):
            closure.validate_parameters(p)


if __name__ == '__main__':
    unittest.main()
