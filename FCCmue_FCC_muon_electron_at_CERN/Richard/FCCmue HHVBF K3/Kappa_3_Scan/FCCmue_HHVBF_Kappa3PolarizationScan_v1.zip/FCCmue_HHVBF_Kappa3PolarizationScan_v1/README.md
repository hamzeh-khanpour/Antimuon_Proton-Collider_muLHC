# FCC-μ⁺e⁻ Higgs-pair coupling and polarization scan

This is the direct CERN scan of σHH as a function of the antimuon polarization
and κ₃. It uses the validated HHVBF model, inclusive LO stable-Higgs production,
and the same beam energies and generation settings as the unpolarized scan.

| √s | Beam 1 e⁻ | Beam 2 μ⁺ | Channels |
|---:|---:|---:|---|
| 1 TeV | 125 GeV | 2000 GeV | CC and NC |
| 2 TeV | 200 GeV | 5000 GeV | CC and NC |

Beam 1 stays unpolarized. Beam 2 uses `polbeam2 = 0, 20, 40, 60, 80, 100`
in percent. Positive polarization selects the right-handed antimuon fraction.
The +100% point is an ideal helicity benchmark. CV and C2V stay at 1. The
runtime card varies `NEW[3] = κ₃` and includes the corrected derived W mass.

```text
κ3 = -10, -5, -3, -2, -1, 0, 0.1, 0.5, 0.7, 0.8, 0.9, 1,
      1.1, 1.2, 1.3, 1.5, 1.9, 2, 3, 4, 5, 7, 10
```

The queue contains 460 new jobs with 30,000 requested events and independent
seeds. Collection adds the 92 verified P=0 rates from the included CERN report.
The complete table contains 552 channel rates and 276 CC+NC sums. Use
`python3 scan.py grid` to inspect the production job IDs and cards.

## Upload and submit at CERN

In Windows PowerShell, upload the downloaded ZIP.

```powershell
scp "$env:USERPROFILE\Downloads\FCCmue_HHVBF_Kappa3PolarizationScan_v1.zip" hakhanpo@lxplus.cern.ch:
```

On lxplus, unpack the package and snapshot the existing verified exports.

```bash
cd "$HOME"
unzip -n FCCmue_HHVBF_Kappa3PolarizationScan_v1.zip
cd "$HOME/FCCmue_HHVBF_Kappa3PolarizationScan_v1"
sha256sum -c SHA256SUMS
python3 scan.py prepare
python3 scan.py submit-file
condor_submit -dry-run submissions/main.classad submissions/main.sub
```

`prepare` defaults to `$HOME/FCCmue_HHVBF_ModelValidation_v1/prepared`.
The dry run should report 460 jobs. Then submit once.

```bash
condor_submit submissions/main.sub
condor_q "$USER"
```

Each job uses one CPU, 4 GB memory, 8 GB scratch and CERN's `tomorrow`
flavour. The results are named by job and Condor cluster ID under
`results/main/`. The production LHE archives are expected to occupy around
1.8 GB in total, based on the earlier 30,000-event archives.

If you want to queue a single polarization group, a command such as
`python3 scan.py submit-file --tag p20 --polarization 20` creates a 92-job
submit description under `submissions/p20.sub`. Use the full batch or the
individual groups for the same grid to avoid duplicate integrations.

### Rebuild the process exports if needed

The model and preparation helper are bundled under `model_setup/`. If the
existing exports are unavailable, use your existing MadGraph5_aMC@NLO 3.6.4
installation to make fresh templates.

```bash
python3 model_setup/prepare_model.py \
  --mg5 /eos/user/h/hakhanpo/MG5_aMC_v3_6_4 \
  --output "$PWD/prepared_for_polarization" --format madevent
python3 scan.py prepare --prepared "$PWD/prepared_for_polarization"
```

Then generate the submit file and follow the dry-run and submit commands above.
The worker installs the corrected runtime card and verifies the scanned coupling
and polarization in both the working cards and the LHE header.

## Collect, retry and download the rates

After the jobs finish, run `python3 scan.py collect`. It checks the archived
seed, beams, polarization, couplings, LHE event contents and normalization.
It writes `reports/scan_points.csv`, `reports/scan_totals.csv` and
`reports/scan_report.json`. A valid LHE with an event-count shortfall retains
its integrated rate and is flagged in the report.

If some jobs are missing or failed after the queue has drained, use the report
to prepare a new submission for those job IDs.

```bash
python3 scan.py submit-file --tag retry01 --retry-report reports/scan_report.json
condor_submit -dry-run submissions/retry01.classad submissions/retry01.sub
condor_submit submissions/retry01.sub
```

Run `collect` again after the retry. It accepts a valid replacement for a
failed attempt. If two valid attempts exist for one job, move the unwanted
archive outside `results/` and collect again.

To download the rates and the validation report in one small ZIP, run

```bash
zip -j "$HOME/FCCmue_Kappa3Polarization_cross_sections.zip" \
  reports/scan_points.csv reports/scan_totals.csv reports/scan_report.json
```

From Windows PowerShell, download it with

```powershell
scp "hakhanpo@lxplus.cern.ch:/afs/cern.ch/user/h/hakhanpo/FCCmue_Kappa3Polarization_cross_sections.zip" "$env:USERPROFILE\Downloads"
```

## Plot the complete grid

From the scan folder, run `python3 plot_scan.py` after the collector reports
`COMPLETE`. Plotting requires NumPy and Matplotlib. To plot on your computer,
keep the unpacked package and run `plot_scan.py --report PATH_TO_REPORT_JSON`.

The script produces three PDF and PNG figures per energy.

- **3D surfaces** for CC, NC and CC+NC with axes κ₃ from −10 to 10,
  antimuon polarization from 0 to +100%, and σHH in fb. Markers show the
  simulated grid. The total markers sum the matching channel rates.
- **CC+NC contours** for the full scan and a window near the SM. Lines mark
  κ₃=1 and the observed ATLAS+CMS 95% CL boundaries.
- **Near-limit plots** of the fitted CC+NC rate versus polarization. They
  show κ₃ = −1.35, −1.2, −0.71, −0.5 at the lower side and
  κ₃ = 5.8, 6.1, 6.37, 7.2 at the upper side. The two nearby points sample
  the interior close to each combined bound. These curves evaluate the fits at
  the specified κ₃ values. `near_limit_predictions.csv` gives CC, NC and
  total predictions with fitted MC errors at all six polarization settings.

The six coefficients per channel describe
`σ(κ₃,P) = A + B κ₃ + C κ₃² + P (D + E κ₃ + F κ₃²)`, with P as a fraction.
The plot script checks intermediate polarization points against the independent
P=0 and P=100 endpoints and checks the CC factor `1+P`. It writes the fit
coefficients, covariance and diagnostics to `surface_fits.json`.

The observed one-parameter 95% intervals shown are ATLAS+CMS [−0.71, 6.1],
ATLAS [−1.2, 7.2] and CMS [−1.35, 6.37], with other Higgs couplings fixed to SM
values. These provide coupling-axis references for the FCC-mue predictions.
[ATLAS+CMS, arXiv:2602.23991](https://arxiv.org/abs/2602.23991) ·
[ATLAS, arXiv:2406.09971](https://arxiv.org/abs/2406.09971) ·
[CMS, arXiv:2510.07527](https://arxiv.org/abs/2510.07527)

The LO channels are `e- mu+ > ve vm~ h h` and `e- mu+ > e- mu+ h h`,
each with `QCD=0 QED=4 CV=2 C2V=1 C3=1` coupling-order bounds and the
`HHVBF_UFO_FCCmue-fccmue` import. Both use the matched electroweak inputs,
no beam PDFs, a 125 GeV fixed renormalization scale and inclusive generation.
`VALIDATION.md` records the package checks.
