# Polarized package validation

Six independent MadEvent 3.6.4 integrations used the same worker and analysis
path as production, with 4,000 requested events and a separate seed range.
They cover all five new polarizations, both energies and both channels.
Each produced its requested event count. The collector reopened all six
archives, verified the LHE headers and accepted the rates. The three CC
checks agree with (1+P) times the unpolarized rate within 1.2 combined MC
standard deviations. The E1 NC 40% point agrees with interpolation between
0% and 100% within 0.5 combined MC standard deviations.

The integration rates, error estimates, seeds and LHE hashes are recorded in
`validation/local_madevent_checks.json`. The production manifest uses
30,000 requested events per job and independent production seeds.

The production plan contains 460 unique job IDs and seeds. The verified
unpolarized input contributes 92 unique points, with disjoint seeds. Queue
construction was checked for the full batch, a single polarization group and a
report-selected retry. CERN's submit parser can check the generated file with
the dry-run command in the README. The production jobs await CERN submission.

A synthetic complete 552-point grid exercised the fit and rendering path for
both energies. The check produced all six figures and the 288 near-limit
prediction rows. The synthetic values and figures are test inputs and are
omitted from the production package.
