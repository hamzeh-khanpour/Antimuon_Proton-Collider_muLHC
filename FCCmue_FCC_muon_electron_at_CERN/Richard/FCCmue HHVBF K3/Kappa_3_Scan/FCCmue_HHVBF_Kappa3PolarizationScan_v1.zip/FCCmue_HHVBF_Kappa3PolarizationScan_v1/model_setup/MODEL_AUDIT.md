# HHVBF UFO source and matrix-element validation

Date: 10 November 2026 (project date).

## Finding

The CERN-provided HHVBF UFO contains a genuine adjustable trilinear Higgs parameter, C3, with C3=kappa3. A separate copy with an added FCC-mue restriction reproduces the original SM unpolarized squared matrix elements at the tested phase-space points. It is ready for the next CERN preparation/rate-validation stage, not yet a production-validated cross-section or angular campaign.

## Original source and integrity

Original user-uploaded archive: `HHVBF_UFO_source.tar.gz`.

SHA-256: `afe36ce9cc12008247d9147aeb93cbecfe7696f073f0b6725d2a649b70eb9599`, exactly matching the checksum printed at CERN.

CERN resolved source path:

`/cvmfs/atlas.cern.ch/repo/sw/Generators/madgraph/models/latest/Higgs/HHVBF_UFO`

The archive contains 22 regular files plus its root-directory entry, with no symbolic/hard links. The source metadata reports the old FeynRules SM model lineage (version 1.4.5) and generated-code dates in 2013; the files were staged in CVMFS with 2023 timestamps. These labels alone are not a validation of the anomalous-coupling extension.

The supplied original Python files are preserved byte-for-byte in the package's model copy. One new restriction file was added. The original source archive is retained unchanged under `original/`.

## Confirmed parameter mapping

| UFO parameter | Nature | Block | Index | Role |
|---|---|---|---:|---|
| CV | external, real | NEW | 1 | HVV modifier |
| C2V | external, real | NEW | 2 | HHVV modifier |
| C3 | external, real | NEW | 3 | hhh modifier, kappa3 |

`parameters.py` defines `lam=MH**2/(2*vev**2)`.

`vertices.py` defines V_9 with three PDG-25 Higgs particles, scalar Lorentz structure SSS1 and coupling GC_89.

`couplings.py` defines:

```
GC_89: -6*C3*complex(0,1)*lam*vev
```

Therefore the vertex is exactly `-i*C3*3*MH**2/vev`. Only GC_89 contains C3; varying C3 with the other external parameters fixed leaves the other 133 numerical couplings unchanged in the algebra checks.

The physical HWW/HZZ vertices are V_91/V_111 (GC_93/GC_101), and HHWW/HHZZ vertices are V_90/V_110 (GC_54/GC_85). The Hbb vertex is V_52 (GC_103), and is present. The physical HHHH vertex, V_6/GC_51, is unchanged by C3.

## Important non-SM defaults

| Source configuration | CV | C2V | C3 | Other notable settings |
|---|---:|---:|---:|---|
| parameters.py and supplied param_card.dat | 0.1 | 0.1 | 0.1 | Nonzero electron/muon masses and Yukawas |
| restrict_vbf_hh.dat | 1.1 | 1.2 | 1.3 | MB=0, ymb=3.117; nonzero lepton masses, zero e/mu Yukawas |
| restrict_4FSZeroYukawa.dat | 1.1 | 1.2 | 1.3 | Despite its name, not all Yukawas are zero |
| restrictions ending kl0 | 1 | 0 or 1 | 0 | May remove the trilinear interaction during import |

There is no supplied restrict_default.dat. A plain model import must not be assumed to give an SM run point. There is also no reason to assume a named restriction is suitable just from its filename.

Restriction cards are import-time definitions: zero/one values may be fixed, and equal parameters/couplings may be merged. A removed interaction cannot be restored by editing a later runtime card. Official MadGraph documentation: https://cp3.irmp.ucl.ac.be/projects/madgraph/wiki/Models/USERMOD .

## Matched restriction and runtime card

The package adds `HHVBF_UFO_FCCmue/restrict_fccmue.dat` and supplies a separate `param_card_SM.dat`.

The import restriction uses distinct non-special values CV=1.1, C2V=1.2, C3=1.3 to preserve three independent external parameters. They are NOT intended production values. The preparation script explicitly installs the separate SM runtime card with CV=C2V=C3=1 into every prepared process.

The restriction and SM runtime card use the old inclusive campaign's input convention:

- aEWM1=132.507, GF=1.16639e-5 GeV^-2, alphaS=0.118, MZ=91.188 GeV, MH=125 GeV.
- Zero u,d,s,c,e,mu masses and corresponding Yukawa inputs; cabi=0.
- MB=ymb=4.7 GeV; MT=ymt=173 GeV; MTA=ymtau=1.777 GeV.
- WT=1.4915, WZ=2.441404, WW=2.0476, WH=0.006382339 GeV.

Matching the old width/Yukawa convention is a reproducibility choice, not a new endorsement of its physical Hbb branching fraction. No branching factors are applied to stable-Higgs matrix elements.

Import by model name, after the preparation helper installs the independent model copy:

```
import model HHVBF_UFO_FCCmue-fccmue
```

At the run-card/parameter-card editing prompt, unambiguous block commands are:

```
set new 1 1
set new 2 1
set new 3 2
```

These set CV=C2V=1 and kappa3=2. Changing NEW entry 3 to 0, -2 or 5 implements the corresponding coupling hypotheses. This has been validated at the matrix-element/card-reading level, not yet through full CERN MadEvent integration.

## Coupling orders and process generation

This UFO assigns separate coupling-order tags CV, C2V and C3. They are not the same thing as the numerical parameters of the same names. The templates use explicit upper bounds:

```
generate e- mu+ > ve vm~ h h QCD=0 QED=4 CV=2 C2V=1 C3=1
generate e- mu+ > e- mu+ h h QCD=0 QED=4 CV=2 C2V=1 C3=1
```

The bounds permit the contact, separate-emission and trilinear amplitudes. `C3=1` in a generate command limits the coupling order to at most one trilinear insertion; it does NOT set numerical kappa3=1. Use `set new 3 VALUE` in the runtime card for the numerical value. No diagram removal or VBF-only propagator filter was used.

## Actual tests performed

1. All 13 Python files parse under Python 3; the modules import successfully with 98 parameters, 134 couplings and 163 vertices. All internal parameter and coupling expressions evaluate.
2. Source/algebra checks at C3=[0,1,2,-2,5] establish the trilinear normalization, unchanged other couplings and SM HVV/HHVV vertex relations.
3. Official MG5 source tag v3.6.4 was obtained from the upstream repository, tag commit bfd34580eb59c2a027a502c89995e682a70a95b9. Downloaded source archive SHA-256: f92a02c56029d6ee2f6ddf0b67bac23e2afac7565b54541c8565c27a5d59457d.
4. MG5 3.6.4 imports the matched restriction with all NEW entries still external. In unitary gauge, each intended channel produces four diagrams.
5. Standalone C++ matrix elements were generated and compiled with g++. The matched model and stock restricted SM were evaluated on identical deterministic on-shell phase-space four-vectors: 10 points at sqrt(s)=1 TeV and 10 at 2 TeV, separately for CC and NC. These are numerical matrix tests, not collider event samples.
6. At C3=1 the squared matrix elements agree with the SM to printed 17-digit precision at all 40 tested channel-points. C3=[0,1,2,-2,5] was evaluated at each point. The values at 0,1,2 define the quadratic; -2 and 5 test it independently. Maximum relative residuals are 8.41e-13 (CC) and 2.44e-14 (NC). The corresponding quadratic positivity/Cauchy-Schwarz checks also pass.
7. The distributed preparation and matrix-check scripts were rerun end-to-end in fresh directories, reproducing the checks. No event generation or integration was launched.

The stock-SM matrix-element reference used the unchanged original CERN parameter card, retained as `reference_SM_param_card.dat`. The new model's same-input runtime card is different in format/block content, but the relevant physical inputs match.

Detailed evidence is in `source_audit.json`, `fixed_phase_space_checks.json`, and `evidence/`. The upstream GitHub tag source emits a development-build notice; these tests concern that identifiable v3.6.4 source and do not replace checks on the user's installed CERN release.

## Scope and remaining checks

- These are unpolarized, unitary-gauge, tree-level squared-matrix-element tests. They do not establish polarized rates, integration convergence, detector performance, or a broad gauge-consistency validation of arbitrary CV/C2V deformations.
- The model rescales physical hhh while leaving quartic and Goldstone scalar interactions unchanged. Treat this as the intended phenomenological LO kappa3 slice with CV=C2V=1, not as a complete O6 SMEFT potential or a model validated for HHH/NLO predictions. A later SMEFT interpretation needs its own mapping, correlated vertices and truncation prescription.
- A local MadEvent export attempt encountered the absence of a Fortran compiler in this environment. The successful numerical checks used standalone C++. The user's CERN MadEvent export still needs to pass with the installed compiler and runtime.
- The provided prepare_model.py exports processes and installs the SM runtime parameter cards. It intentionally does NOT configure production run cards, generate events or submit jobs.
- Next: CERN preparation, followed by four unpolarized integrated C3=1 HH anchors at exact E1/E2. Match the old no-cut run cards and preserve independent seeds. Then the coupling/polarization pilot and HH decay/angular checks.

No new integrated kappa3 cross sections, angular distributions, HH->4b samples or HHH samples have been calculated in this audit.
